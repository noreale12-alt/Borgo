# Guida: texture, visi e modelli 3D (NomadSculpt)

## 1. Texture PNG (cartella `textures/`)

Puoi ridisegnare qualsiasi PNG con un'app di pixel art (Pixel Studio, Dotpict, Aseprite...).
Tieni **lo stesso nome file**. La dimensione è libera (16×16 è quella di partenza, va bene anche 32×32).

| Cartella | Cosa contiene | Note |
|---|---|---|
| `mappa/` | erba, fiori, sentiero, sabbia, acqua, pietra, legno, foglie, tronco, roccia, muro, tetto | **muro** e **tetto** vengono colorati col colore di ogni casa: disegnali in bianco/grigio |
| `oggetti/` | icone degli oggetti (mela, fiore, conchiglia...) e la lanterna del festival | sfondo trasparente |
| `icone/` | simboli sopra la testa (cuore, nota, rabbia, zzz...) | sfondo trasparente |
| `personaggi/ombra.png` | ombra sotto i piedi | |
| `viso/` | occhi, bocche, guance (vedi sotto) | **32×32**, sfondo trasparente |

Se cancelli un PNG, il gioco usa quello disegnato dal codice.

## 2. Visi (`textures/viso/`, 32×32)

- Il **colore magenta puro `#FF00FF`** negli occhi viene sostituito dal colore occhi scelto nell'editor.
- Il **bordo esterno di 1 pixel deve restare trasparente**.
- Gli occhi stanno più o meno tra le righe 12 e 19, la bocca intorno alla riga 22.
- File riconosciuti:
  - occhi normali per stile: `occhi_tondi.png`, `occhi_dolci.png`, `occhi_vivaci.png` (puoi aggiungerne altri, es. `occhi_gatto.png`, e scriverli in `data/modelli.json` alla voce "occhi")
  - espressioni comuni a tutti: `occhi_felice`, `occhi_triste`, `occhi_arrabbiato`, `occhi_sorpreso`, `occhi_chiusi`
  - espressioni per uno stile specifico (facoltative): `occhi_dolci_felice.png`, `occhi_vivaci_triste.png`...
  - bocche: `bocca_normale`, `bocca_felice`, `bocca_triste`, `bocca_arrabbiato`, `bocca_sorpreso`
  - `guance.png`: rossore sempre presente (cancellalo se non lo vuoi)
- Nel gioco, **Disegna sul viso** aggiunge sopra trucco, nei, cicatrici, tatuaggi; "Nascondi pixel" toglie pezzi di occhi o bocca.

## 3. Personaggi 3D con NomadSculpt

Finché non c'è il tuo modello, il gioco usa un corpo provvisorio in stile Nendoroid.
Appena aggiungi `models/corpo.glb`, **tutti** i personaggi usano il tuo corpo.

### Corpo base (`models/corpo.glb`)
Senza capelli, vestiti e viso. Deve essere diviso in **oggetti separati** con questi nomi
(*sx* = sinistra del personaggio):

`testa` · `busto` · `braccio_sx` · `braccio_dx` · `gamba_sx` · `gamba_dx`

- Il personaggio guarda verso la vista **frontale** di Nomad. Se nel gioco appare girato di spalle,
  in `data/modelli.json` metti `"ruota_y": 180`.
- Dimensione e posizione non importano: il gioco lo ridimensiona da solo (piedi a terra).
- I perni (spalle, anche, collo) sono calcolati in automatico.
- La pelle viene colorata dal gioco col colore scelto nell'editor.
- **Il viso**: il gioco lo "avvolge" sulla parte frontale della testa. Funziona meglio con una testa
  tonda/ovale e un viso abbastanza piatto, senza naso/bocca scolpiti in rilievo.
  (Avanzato: puoi aggiungere un oggetto `faccia`, sottile e con UV, e il viso verrà disegnato lì.)

### ⚠️ Poligoni
Le sculture di Nomad hanno milioni di poligoni: un telefono con 7 personaggi non le regge.
Prima di esportare usa **Decimate** (o Remesh basso) e resta intorno a **2.000-5.000 triangoli
per tutto il corpo**, e 1.000-3.000 per capelli o vestiti. Lo stile Nendoroid è liscio, quindi
si perde poco.

### Capelli, vestiti, accessori
Scolpiscili **nello stesso file del corpo, sopra il corpo**, poi esporta **solo quei pezzi**
(nascondi il corpo) senza spostarli. Esporta in **glTF binario (.glb)**.

- **Capelli** → `models/capelli/nome.glb`. Seguono la testa. Vengono colorati col colore capelli.
- **Vestiti** → `models/vestiti/nome.glb`. Dai a ogni pezzo un nome che contenga la parte che deve
  seguire, così si muove con lei: `maglia_busto`, `manica_braccio_sx`, `manica_braccio_dx`,
  `pantaloni_gamba_sx`, `gonna_busto`...
  Colori: i pezzi con "pantaloni"/"gonna" nel nome o sulle gambe prendono il colore pantaloni,
  gli altri il colore maglia.
- **Accessori** → `models/accessori/nome.glb`. Seguono la testa (oppure metti una parte nel nome).
  Tengono i colori dipinti in Nomad; se il nome contiene "colore" prendono il colore maglia,
  se contiene "capelli" il colore capelli.
- In qualsiasi pezzo, se il nome contiene **`fisso`**, il gioco **non** lo ricolora e tiene la
  pittura di Nomad (ricordati di esportare con i colori dei vertici).

### Registrarli nel gioco (`data/modelli.json`)
Aggiungi una riga nella lista giusta, per esempio:

```json
{"id": "caschetto", "nome": "Caschetto", "file": "res://models/capelli/caschetto.glb"}
```

Nel file ci sono già degli esempi `esempio_mio` da copiare. Le voci il cui file non esiste
vengono semplicemente nascoste nell'editor.

Se preferisci, mandami i .glb e i PNG e li sistemo io nel progetto.
