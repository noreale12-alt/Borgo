# Borgo Lanterna 🏮

Gioco di vita di villaggio per Android: personaggi chibi 3D, mappa modificabile, case arredabili,
relazioni, regali, appuntamenti, eventi casuali, una trama a scelte e chiacchiere libere con l'IA.
Stile grafico ispirato ai giochi DS (pixel art su mondo 3D, telecamera dall'alto inclinata).

Motore: **Godot 4.3** (gratuito e open source). Nessun costo: niente pubblicità, niente acquisti,
l'IA usa la chiave gratuita di ogni giocatore.

---

## 1. Ottenere l'APK (gratis, senza installare nulla sul PC)

Il progetto contiene già una "ricetta" che fa compilare l'APK ai server di GitHub, gratuitamente.

1. Crea un account gratuito su **github.com** (anche dal telefono).
2. Tocca **+ → New repository**, chiamalo ad esempio `borgo-lanterna`, lascialo **Public**
   (le Actions sono illimitate e gratuite sui repository pubblici) e crealo.
3. Nella pagina del repository tocca **"uploading an existing file"** e carica **tutto il contenuto**
   della cartella `borgo` (estratta dallo zip), comprese le cartelle nascoste `.github` e `.ci`.
   *Dal PC è più semplice: trascina le cartelle nella pagina.*
   > Se il caricamento web non prende le cartelle che iniziano col punto, usa GitHub Desktop
   > oppure crea a mano il file `.github/workflows/build-apk.yml` con "Add file → Create new file"
   > e incolla il contenuto.
4. Vai nella scheda **Actions**: parte da sola la procedura "Crea APK Android" (circa 3-5 minuti).
5. Quando c'è la spunta verde, vai su **Releases → Borgo Lanterna (ultima versione)** e scarica
   `BorgoLanterna.apk` dal telefono.
6. Apri il file: Android ti chiederà di consentire l'installazione da "origini sconosciute"
   per il browser o il gestore file. Conferma e installa.

Ogni volta che modifichi un file nel repository, viene compilato un nuovo APK automaticamente.
La chiave di firma è sempre la stessa (`.ci/borgo.keystore`), quindi gli aggiornamenti si installano
sopra la versione precedente **senza perdere il salvataggio**.

### In alternativa: dal PC con Godot
Scarica Godot 4.3 da godotengine.org, apri `project.godot`, premi F5 per giocare sul PC.
Per l'APK: *Editor → Gestisci modelli di esportazione* → scarica, poi *Progetto → Esporta → Android*
(serve l'Android SDK; vedi la guida ufficiale "Exporting for Android").

---

## 2. Attivare l'IA (gratis)

Le chiacchiere libere funzionano anche senza IA (risposte semplici), ma con l'IA gli abitanti
rispondono davvero, ricordano cosa vi siete detti e reagiscono in base a carattere e relazione.

1. Nel gioco: **Menu → Intelligenza artificiale**.
2. Scegli **Google Gemini** (consigliato) e tocca **Ottieni chiave**: si apre Google AI Studio.
3. Accedi con un account Google, crea una chiave API, copiala.
4. Incollala nel gioco, tocca **Prova connessione** e poi **Salva**.

Alternative gratuite già supportate: **Groq** e **OpenRouter** (modelli con `:free`).
I piani gratuiti hanno un limite di messaggi giornaliero; la chiave resta solo sul telefono.

---

## 3. Cosa c'è nel gioco

| Funzione | Dove |
|---|---|
| Crea il tuo personaggio (capelli, colori, vestiti, accessori) | All'avvio, poi Menu → Il tuo personaggio |
| 6 abitanti con personalità, gusti, storia, lavoro | `data/npcs.json` |
| Relazioni con te (amicizia, amore) e **tra loro** (amicizie, litigi, coppie) | automatico |
| Domande a scelta che piacciono o no in base al carattere | Parla |
| Regali (ogni abitante ama/odia certe cose) | Fai un regalo |
| Appuntamenti in 3 luoghi, dichiarazioni, fidanzamenti | Appuntamento / Dichiarati |
| Abitanti che si dichiarano da soli se l'amore è alto | automatico |
| Ciclo giorno/notte, pioggia, abitanti che dormono a casa | automatico |
| Eventi casuali: litigi, malattie, oggetti persi, feste | ogni nuovo giorno |
| Trama "Il Festival delle Lanterne" con bivi | parla con Nonna Rosa |
| Chat libera con IA e memoria | Chiacchiera libera |
| Gazzetta del villaggio generata dall'IA | Notizie (con IA attiva) |
| Editor mappa (erba, fiori, sentieri, acqua, alberi, recinti, lampioni...) | Menu → Modifica mappa |
| Arredamento di casa tua (10 mobili) | entra in casa → Menu → Arreda casa |
| Crea nuovi abitanti / modifica / fai traslocare | Menu → Abitanti |

Comandi: joystick a sinistra, tasto **A** a destra (Parla / Entra / Esci / Dormi).
Su PC: WASD o frecce, Spazio/E per l'azione.

---

## 4. Come espandere il gioco

Quasi tutto è nei file JSON della cartella `data/`, modificabili senza programmare:

- `npcs.json` – abitanti: aspetto, tratti (0-100), gusti, storia, luogo preferito, chi possono amare.
- `items.json` – oggetti: nome, icona, colore, tag (i gusti degli abitanti usano i tag).
- `talk.json` – frasi, saluti, pettegolezzi, domande con le risposte e i tratti che premiano.
- `events.json` – testi degli eventi casuali.
- `story.json` – trama: *trigger* (quando parte un dialogo) e *nodi* (testo, scelte, effetti, flag).
- `map.json` – mappa a caselle (32×24) e case con i loro mobili.

### Verso un sistema stile The Sims / Tomodachi Life
Il codice è già organizzato per crescere in questa direzione:
- **Bisogni** (fame, energia, divertimento, socialità): aggiungere valori in `Game.status` e farli
  scendere in `advance_time`; in `npc_desire()` (main.gd) scegliere la meta in base al bisogno più basso.
- **Personalizzazione profonda**: nuovi campi in `aspetto` (forma occhi, altezza, abiti) e nuove parti
  in `chibi.gd → build()`; l'editor in `ui.gd → open_editor()` li mostra con `_choice_row`/`_swatch_row`.
- **Lavori e orari**: un campo `orari` per NPC letto da `npc_desire()`.
- **Negozio e soldi**, **case visitabili da arredare per tutti**, **matrimoni e figli**,
  **eventi generati dall'IA con scelte** (l'IA può restituire JSON con opzioni).

---

## 5. Struttura del codice

```
scripts/game.gd       stato globale, relazioni, eventi, trama, salvataggi, prompt IA (autoload "Game")
scripts/ai_chat.gd    client IA compatibile OpenAI: Gemini, Groq, OpenRouter (autoload "Ai")
scripts/main.gd       mondo 3D, caselle, case e interni, percorsi A*, giorno/notte, editor
scripts/npc.gd        IA di movimento e routine degli abitanti
scripts/chibi.gd      costruzione dei personaggi chibi 3D
scripts/pixel_tex.gd  texture e icone pixel art generate dal codice
scripts/ui.gd         HUD, dialoghi, menu, chat, profili, editor personaggi
.github/workflows/    compilazione automatica dell'APK
```

Il salvataggio è automatico (ogni nuovo giorno, ogni 90 secondi e quando chiudi l'app).
