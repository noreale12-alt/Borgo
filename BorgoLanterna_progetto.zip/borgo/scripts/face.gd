extends RefCounted
## Viso in pixel art 32x32: occhi + bocca (preset PNG con espressioni) + disegni del giocatore.
## Nei PNG degli occhi il colore magenta (#ff00ff) viene sostituito dal colore occhi scelto.

const PixelTex = preload("res://scripts/pixel_tex.gd")
const SIZE := 32
const EXPRESSIONS := ["normale", "felice", "triste", "arrabbiato", "sorpreso", "chiusi"]
const EXPR_LABELS := ["Normale", "Felice", "Triste", "Arrabbiato", "Sorpreso", "Occhi chiusi"]

static var _tex_cache: Dictionary = {}


static func _first_png(names: Array) -> Image:
	for n in names:
		var img := PixelTex.load_png("viso/%s.png" % n)
		if img != null:
			return img
	return null


static func _blit(dst: Image, src: Image, eye_col: Color) -> void:
	if src == null:
		return
	var w := mini(SIZE, src.get_width())
	var h := mini(SIZE, src.get_height())
	for y in h:
		for x in w:
			var c := src.get_pixel(x, y)
			if c.a <= 0.01:
				continue
			if c.r > 0.95 and c.g < 0.05 and c.b > 0.95:
				c = Color(eye_col.r, eye_col.g, eye_col.b, c.a)
			if c.a < 0.99:
				c = dst.get_pixel(x, y).blend(c)
			dst.set_pixel(x, y, c)


## Come _blit, ma colora tutti i pixel con un colore (sopracciglia = colore capelli più scuro).
static func _blit_tint(dst: Image, src: Image, col: Color) -> void:
	if src == null:
		return
	var w := mini(SIZE, src.get_width())
	var h := mini(SIZE, src.get_height())
	for y in h:
		for x in w:
			var c := src.get_pixel(x, y)
			if c.a <= 0.01:
				continue
			var t := Color(col.r, col.g, col.b, c.a)
			if t.a < 0.99:
				t = dst.get_pixel(x, y).blend(t)
			dst.set_pixel(x, y, t)


static var _eye_box_cache: Dictionary = {}


## Riquadri (in pixel della texture) dell'occhio sinistro e destro di uno stile, per gli occhiali.
static func eye_boxes(style: String) -> Array:
	if _eye_box_cache.has(style):
		return _eye_box_cache[style]
	var img := _first_png(["occhi_%s" % style, "occhi_tondi"])
	var out: Array = [Rect2(7, 12, 6, 8), Rect2(19, 12, 6, 8)]
	if img != null:
		var boxes: Array = []
		for half in 2:
			var x0 := 99
			var y0 := 99
			var x1 := -1
			var y1 := -1
			for y in mini(SIZE, img.get_height()):
				for x in range(half * 16, mini((half + 1) * 16, img.get_width())):
					if img.get_pixel(x, y).a > 0.5:
						x0 = mini(x0, x)
						y0 = mini(y0, y)
						x1 = maxi(x1, x)
						y1 = maxi(y1, y)
			if x1 >= 0:
				boxes.append(Rect2(x0, y0, x1 - x0 + 1, y1 - y0 + 1))
		if boxes.size() == 2:
			out = boxes
	_eye_box_cache[style] = out
	return out


## Disegno di riserva se mancano i PNG.
static func _fallback(img: Image, eye_col: Color) -> void:
	var k := Color.html("#262030")
	for ex in [9, 20]:
		for y in range(12, 19):
			for x in range(ex, ex + 4):
				img.set_pixel(x, y, k if (y == 12 or y == 18 or x == ex or x == ex + 3) else eye_col)
	for x in range(14, 18):
		img.set_pixel(x, 22, k)


static func compose(app: Dictionary, expr: String = "normale") -> ImageTexture:
	var style := str(app.get("occhi", "tondi"))
	var eye_hex := str(app.get("colore_occhi", "#5a3c8c"))
	var px: Variant = app.get("pixel", {})
	if typeof(px) != TYPE_DICTIONARY:
		px = {}
	var brow_style := str(app.get("sopracciglia", "nessuna"))
	var brow_col := Color.html(str(app.get("capelli", "#503020"))).darkened(0.3)
	var key := "%s|%s|%s|%s|%s|%s" % [style, eye_hex, expr, brow_style, brow_col.to_html(), JSON.stringify(px)]
	if _tex_cache.has(key):
		return _tex_cache[key]
	if _tex_cache.size() > 300:
		_tex_cache.clear()
	var img := Image.create(SIZE, SIZE, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var eye_col := Color.html(eye_hex)
	var eyes: Image
	var brows: Image = null
	if expr == "normale":
		eyes = _first_png(["occhi_%s" % style, "occhi_tondi"])
	else:
		# 1) occhi specifici dello stile per questa espressione
		eyes = PixelTex.load_png("viso/occhi_%s_%s.png" % [style, expr])
		if eyes == null:
			# 2) sopracciglia da sovrapporre agli occhi normali (es. triste, arrabbiato)
			brows = PixelTex.load_png("viso/sopracciglia_%s.png" % expr)
			if brows != null:
				eyes = _first_png(["occhi_%s" % style, "occhi_tondi"])
			else:
				# 3) occhi dell'espressione uguali per tutti (es. felice, chiusi, sorpreso)
				eyes = _first_png(["occhi_%s" % expr, "occhi_%s" % style, "occhi_tondi"])
	# sopracciglia: quelle dell'espressione (triste, arrabbiato...) oppure lo stile scelto
	if brows == null and brow_style != "nessuna":
		brows = PixelTex.load_png("viso/sopracciglia_%s.png" % brow_style)
	var mouth := _first_png(["bocca_%s" % expr, "bocca_normale"])
	if eyes == null and mouth == null:
		_fallback(img, eye_col)
	else:
		_blit(img, PixelTex.load_png("viso/guance.png"), eye_col)
		_blit(img, eyes, eye_col)
		_blit_tint(img, brows, brow_col)
		_blit(img, mouth, eye_col)
	for k in px:
		var parts := str(k).split(",")
		if parts.size() != 2:
			continue
		var x := int(parts[0])
		var y := int(parts[1])
		if x < 0 or y < 0 or x >= SIZE or y >= SIZE:
			continue
		img.set_pixel(x, y, Color.html(str(px[k])))
	# il bordo deve restare trasparente (la texture del viso non si ripete)
	for i in SIZE:
		img.set_pixel(i, 0, Color(0, 0, 0, 0))
		img.set_pixel(i, SIZE - 1, Color(0, 0, 0, 0))
		img.set_pixel(0, i, Color(0, 0, 0, 0))
		img.set_pixel(SIZE - 1, i, Color(0, 0, 0, 0))
	var tex := ImageTexture.create_from_image(img)
	_tex_cache[key] = tex
	return tex
