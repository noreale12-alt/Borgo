extends RefCounted
## Viso in pixel art 32x32: occhi + bocca (preset PNG con espressioni) + disegni del giocatore.
## Nei PNG degli occhi il colore magenta (#ff00ff) viene sostituito dal colore occhi scelto.

const PixelTex = preload("res://scripts/pixel_tex.gd")
const SIZE := 32
const EXPRESSIONS := ["normale", "felice", "triste", "arrabbiato", "sorpreso", "chiusi"]
const EXPR_LABELS := ["Normale", "Felice", "Triste", "Arrabbiato", "Sorpreso", "Occhi chiusi"]

static var _tex_cache: Dictionary = {}


static func _first_png(names: Array) -> Image:
	for n in names:
		var img := PixelTex.load_png("viso/%s.png" % n)
		if img != null:
			return img
	return null


static func _blit(dst: Image, src: Image, eye_col: Color) -> void:
	if src == null:
		return
	var w := mini(SIZE, src.get_width())
	var h := mini(SIZE, src.get_height())
	for y in h:
		for x in w:
			var c := src.get_pixel(x, y)
			if c.a <= 0.01:
				continue
			if c.r > 0.95 and c.g < 0.05 and c.b > 0.95:
				c = Color(eye_col.r, eye_col.g, eye_col.b, c.a)
			if c.a < 0.99:
				c = dst.get_pixel(x, y).blend(c)
			dst.set_pixel(x, y, c)


## Disegno di riserva se mancano i PNG.
static func _fallback(img: Image, eye_col: Color) -> void:
	var k := Color.html("#262030")
	for ex in [9, 20]:
		for y in range(12, 19):
			for x in range(ex, ex + 4):
				img.set_pixel(x, y, k if (y == 12 or y == 18 or x == ex or x == ex + 3) else eye_col)
	for x in range(14, 18):
		img.set_pixel(x, 22, k)


static func compose(app: Dictionary, expr: String = "normale") -> ImageTexture:
	var style := str(app.get("occhi", "tondi"))
	var eye_hex := str(app.get("colore_occhi", "#5a3c8c"))
	var px: Variant = app.get("pixel", {})
	if typeof(px) != TYPE_DICTIONARY:
		px = {}
	var key := "%s|%s|%s|%s" % [style, eye_hex, expr, JSON.stringify(px)]
	if _tex_cache.has(key):
		return _tex_cache[key]
	if _tex_cache.size() > 300:
		_tex_cache.clear()
	var img := Image.create(SIZE, SIZE, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	var eye_col := Color.html(eye_hex)
	var eyes: Image
	if expr == "normale":
		eyes = _first_png(["occhi_%s" % style, "occhi_tondi"])
	else:
		eyes = _first_png(["occhi_%s_%s" % [style, expr], "occhi_%s" % expr, "occhi_%s" % style, "occhi_tondi"])
	var mouth := _first_png(["bocca_%s" % expr, "bocca_normale"])
	if eyes == null and mouth == null:
		_fallback(img, eye_col)
	else:
		_blit(img, PixelTex.load_png("viso/guance.png"), eye_col)
		_blit(img, eyes, eye_col)
		_blit(img, mouth, eye_col)
	for k in px:
		var parts := str(k).split(",")
		if parts.size() != 2:
			continue
		var x := int(parts[0])
		var y := int(parts[1])
		if x < 0 or y < 0 or x >= SIZE or y >= SIZE:
			continue
		img.set_pixel(x, y, Color.html(str(px[k])))
	# il bordo deve restare trasparente (la texture del viso non si ripete)
	for i in SIZE:
		img.set_pixel(i, 0, Color(0, 0, 0, 0))
		img.set_pixel(i, SIZE - 1, Color(0, 0, 0, 0))
		img.set_pixel(0, i, Color(0, 0, 0, 0))
		img.set_pixel(SIZE - 1, i, Color(0, 0, 0, 0))
	var tex := ImageTexture.create_from_image(img)
	_tex_cache[key] = tex
	return tex
