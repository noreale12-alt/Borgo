extends Control
## Pulsante tondo multitouch (si può premere mentre si usa il joystick).

signal tapped

var text: String = "A"
var held: bool = false
var touch_index: int = -1
var color: Color = Color(0.88, 0.3, 0.32)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func _input(event) -> void:
	if not is_visible_in_tree():
		held = false
		touch_index = -1
		return
	if event is InputEventScreenTouch:
		if event.pressed and touch_index == -1 and get_global_rect().has_point(event.position):
			touch_index = event.index
			held = true
			queue_redraw()
			tapped.emit()
		elif not event.pressed and event.index == touch_index:
			touch_index = -1
			held = false
			queue_redraw()


func set_text(t: String) -> void:
	text = t
	queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	var r := minf(size.x, size.y) / 2.0 - 4.0
	draw_circle(c, r, Color(color.r, color.g, color.b, 0.95 if held else 0.8))
	draw_arc(c, r, 0.0, TAU, 48, Color(1, 1, 1, 0.9), 4.0)
	var f := get_theme_default_font()
	var fs := 26
	var ts := f.get_string_size(text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs)
	draw_string(f, Vector2(c.x - ts.x / 2.0, c.y + fs / 3.0), text, HORIZONTAL_ALIGNMENT_LEFT, -1, fs, Color.WHITE)
