extends Node3D
## Mondo di gioco: mappa a caselle modificabile, case con interni, giocatore, abitanti, ciclo giorno/notte.

const Chibi = preload("res://scripts/chibi.gd")
const Npc = preload("res://scripts/npc.gd")
const PixelTex = preload("res://scripts/pixel_tex.gd")
const UIScript = preload("res://scripts/ui.gd")

const W := 32
const H := 24
const ROOM_W := 7
const ROOM_D := 6
const EXIT_CELL := Vector2i(3, 5)
const WALKABLE := {".": true, "*": true, "=": true, "S": true, "P": true, "B": true}
const TILE_NAMES := {".": "Erba", "*": "Fiori", "=": "Sentiero", "S": "Sabbia", "P": "Pietra", "~": "Acqua", "B": "Ponte", "T": "Albero", "F": "Recinto", "L": "Lampione", "N": "Panchina", "R": "Roccia"}
const DECOR := ["T", "F", "L", "N", "R"]
## tipo: [larghezza, profondità, blocca il passaggio]
const FURN := {
	"letto": [1, 2, true], "tavolo": [1, 1, true], "sedia": [1, 1, true], "tappeto": [2, 2, false],
	"libreria": [1, 1, true], "pianta": [1, 1, true], "tv": [1, 1, true], "lampada": [1, 1, true],
	"cucina": [1, 1, true], "divano": [2, 1, true],
}

var tiles: Array = []
var houses: Array = []
var house_by_id: Dictionary = {}
var house_nodes: Dictionary = {}
var house_labels: Dictionary = {}
var interiors: Dictionary = {}
var room_origins: Dictionary = {}
var blocked_extra: Dictionary = {}
var front_tiles: Dictionary = {}
var astar := AStarGrid2D.new()
var tile_root: Node3D
var cam: Camera3D
var sun: DirectionalLight3D
var env: Environment
var water_mat: StandardMaterial3D
var sea_mat: StandardMaterial3D
var lamp_mat: StandardMaterial3D
var rain: CPUParticles3D
var player: Chibi
var player_zone: String = "out"
var npc_nodes: Dictionary = {}
var pickups: Array = []
var lanterns: Array = []
var ui = null
var cam_target := Vector3.ZERO
var input_locked: bool = false
var near_npc: Npc = null
var interaction: String = ""
var interaction_house: String = ""
var talk_target: Npc = null
var editor_mode: bool = false
var editor_brush: String = "."
var _door_cd: float = 0.0
var _mesh_cache: Dictionary = {}
var _mat_cache: Dictionary = {}


func _ready() -> void:
	_setup_input()
	_build_environment()
	tile_root = Node3D.new()
	add_child(tile_root)
	_load_map()
	_build_houses()
	_build_tiles()
	_build_fountain()
	_build_player()
	_spawn_npcs()
	_build_rain()
	ui = UIScript.new()
	ui.main = self
	add_child(ui)
	Game.day_changed.connect(_on_day_changed)
	_respawn_pickups()
	if not Game.is_started():
		ui.open_editor("player", true)
	else:
		ui.toast("Bentornat%s, %s! Giorno %d." % [Game.g("player"), Game.name_of("player"), Game.day])


func _setup_input() -> void:
	var keys := {"su": [KEY_W, KEY_UP], "giu": [KEY_S, KEY_DOWN], "sx": [KEY_A, KEY_LEFT], "dx": [KEY_D, KEY_RIGHT], "azione": [KEY_SPACE, KEY_E, KEY_ENTER]}
	for a in keys:
		if InputMap.has_action(a):
			continue
		InputMap.add_action(a)
		for k in keys[a]:
			var ev := InputEventKey.new()
			ev.physical_keycode = k
			InputMap.action_add_event(a, ev)


# ================================================================ costruzione

func _tex_mat(tex: Texture2D, tint: Color = Color.WHITE) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_texture = tex
	m.albedo_color = tint
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.roughness = 1.0
	return m


func _build_environment() -> void:
	var we := WorldEnvironment.new()
	env = Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.55, 0.8, 1.0)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.ambient_light_energy = 0.6
	we.environment = env
	add_child(we)
	sun = DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-58.0, -28.0, 0.0)
	sun.shadow_enabled = false
	add_child(sun)
	cam = Camera3D.new()
	cam.fov = 38.0
	add_child(cam)
	cam.current = true
	# prato infinito e mare oltre i bordi della mappa
	var under := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(300, 300)
	under.mesh = pm
	under.material_override = Chibi.mat(Color.html("#3f8a3a"))
	under.position = Vector3(W / 2.0, -0.14, H / 2.0)
	add_child(under)
	water_mat = _tex_mat(PixelTex.tile("~"))
	lamp_mat = StandardMaterial3D.new()
	lamp_mat.albedo_color = Color.html("#fff0b0")
	lamp_mat.emission_enabled = true
	lamp_mat.emission = Color.html("#ffd870")
	lamp_mat.emission_energy_multiplier = 0.0
	sea_mat = _tex_mat(PixelTex.tile("~"))
	sea_mat.uv1_scale = Vector3(300, 80, 1)
	var sea := MeshInstance3D.new()
	var sp := PlaneMesh.new()
	sp.size = Vector2(300, 80)
	sea.mesh = sp
	sea.material_override = sea_mat
	sea.position = Vector3(W / 2.0, -0.075, 21.0 + 40.0)
	add_child(sea)


func _load_map() -> void:
	var md: Dictionary = Game.map_data
	tiles = []
	for row in md.get("tiles", []):
		tiles.append(str(row))
	while tiles.size() < H:
		tiles.append(".".repeat(W))
	houses = md.get("case", [])
	house_by_id = {}
	for h in houses:
		house_by_id[str(h["id"])] = h


func tile_at(x: int, y: int) -> String:
	if x < 0 or y < 0 or x >= W or y >= H:
		return "T"
	var row: String = tiles[y]
	if x >= row.length():
		return "."
	return row[x]


func set_tile(x: int, y: int, ch: String) -> void:
	var row: String = tiles[y]
	tiles[y] = row.substr(0, x) + ch + row.substr(x + 1)
	Game.map_data["tiles"] = tiles


func is_walkable_tile(x: int, y: int) -> bool:
	if x < 0 or y < 0 or x >= W or y >= H:
		return false
	if blocked_extra.has(Vector2i(x, y)):
		return false
	return WALKABLE.has(tile_at(x, y))


func _mesh(key: String) -> Mesh:
	if _mesh_cache.has(key):
		return _mesh_cache[key]
	var m: Mesh
	match key:
		"plane":
			var p := PlaneMesh.new()
			p.size = Vector2(1, 1)
			m = p
		"trunk":
			var c := CylinderMesh.new()
			c.top_radius = 0.09
			c.bottom_radius = 0.12
			c.height = 0.45
			c.radial_segments = 8
			c.rings = 1
			m = c
		"leaf":
			var s := SphereMesh.new()
			s.radius = 0.46
			s.height = 0.8
			s.radial_segments = 10
			s.rings = 5
			m = s
		"leaftop":
			var s2 := SphereMesh.new()
			s2.radius = 0.3
			s2.height = 0.5
			s2.radial_segments = 8
			s2.rings = 4
			m = s2
		"post":
			var b := BoxMesh.new()
			b.size = Vector3(0.1, 0.45, 0.1)
			m = b
		"rail":
			var b2 := BoxMesh.new()
			b2.size = Vector3(1.0, 0.07, 0.05)
			m = b2
		"lamppost":
			var c2 := CylinderMesh.new()
			c2.top_radius = 0.04
			c2.bottom_radius = 0.06
			c2.height = 1.2
			c2.radial_segments = 6
			c2.rings = 1
			m = c2
		"lamphead":
			var b3 := BoxMesh.new()
			b3.size = Vector3(0.2, 0.22, 0.2)
			m = b3
		"seat":
			var b4 := BoxMesh.new()
			b4.size = Vector3(0.9, 0.08, 0.35)
			m = b4
		"back":
			var b5 := BoxMesh.new()
			b5.size = Vector3(0.9, 0.3, 0.06)
			m = b5
		"rock":
			var s3 := SphereMesh.new()
			s3.radius = 0.32
			s3.height = 0.4
			s3.radial_segments = 7
			s3.rings = 3
			m = s3
	_mesh_cache[key] = m
	return m


func _mat_for(key: String) -> Material:
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m: Material
	if key.begins_with("g"):
		var k := key.substr(1)
		if k == "~":
			m = water_mat
		else:
			m = _tex_mat(PixelTex.tile(k))
	else:
		match key:
			"trunk":
				m = _tex_mat(PixelTex.tile("tronco"))
			"leaf":
				m = _tex_mat(PixelTex.tile("foglie"))
			"leaftop":
				m = _tex_mat(PixelTex.tile("foglie"), Color(1.15, 1.2, 1.0))
			"post", "rail":
				m = Chibi.mat(Color.html("#f8f4ec"))
			"lamppost":
				m = Chibi.mat(Color.html("#40485a"))
			"lamphead":
				m = lamp_mat
			"seat", "back":
				m = Chibi.mat(Color.html("#a8703c"))
			"rock":
				m = _tex_mat(PixelTex.tile("roccia"))
			_:
				m = Chibi.mat(Color.MAGENTA)
	_mat_cache[key] = m
	return m


func _add(groups: Dictionary, key: String, xf: Transform3D) -> void:
	if not groups.has(key):
		groups[key] = []
	groups[key].append(xf)


func _tree_at(groups: Dictionary, p: Vector3, s: float) -> void:
	var b := Basis().scaled(Vector3(s, s, s))
	_add(groups, "trunk", Transform3D(b, p + Vector3(0, 0.22 * s, 0)))
	_add(groups, "leaf", Transform3D(b, p + Vector3(0, 0.75 * s, 0)))
	_add(groups, "leaftop", Transform3D(b, p + Vector3(0, 1.08 * s, 0)))


func _build_tiles() -> void:
	for ch in tile_root.get_children():
		ch.queue_free()
	var groups := {}
	for y in H:
		for x in W:
			var t := tile_at(x, y)
			var base := "." if DECOR.has(t) else t
			var p := Vector3(x + 0.5, 0.0, y + 0.5)
			if base == "B":
				_add(groups, "g~", Transform3D(Basis(), p + Vector3(0, -0.06, 0)))
				_add(groups, "gB", Transform3D(Basis(), p + Vector3(0, 0.02, 0)))
			elif base == "~":
				_add(groups, "g~", Transform3D(Basis(), p + Vector3(0, -0.06, 0)))
			else:
				_add(groups, "g" + base, Transform3D(Basis(), p))
			match t:
				"T":
					_tree_at(groups, p, 1.0)
				"F":
					_add(groups, "post", Transform3D(Basis(), p + Vector3(0, 0.22, 0)))
					_add(groups, "rail", Transform3D(Basis(), p + Vector3(0, 0.32, 0)))
					_add(groups, "rail", Transform3D(Basis(), p + Vector3(0, 0.16, 0)))
				"L":
					_add(groups, "lamppost", Transform3D(Basis(), p + Vector3(0, 0.6, 0)))
					_add(groups, "lamphead", Transform3D(Basis(), p + Vector3(0, 1.28, 0)))
				"N":
					_add(groups, "seat", Transform3D(Basis(), p + Vector3(0, 0.25, 0)))
					_add(groups, "back", Transform3D(Basis(), p + Vector3(0, 0.42, -0.16)))
					_add(groups, "post", Transform3D(Basis().scaled(Vector3(1, 0.5, 1)), p + Vector3(-0.35, 0.11, 0)))
					_add(groups, "post", Transform3D(Basis().scaled(Vector3(1, 0.5, 1)), p + Vector3(0.35, 0.11, 0)))
				"R":
					_add(groups, "rock", Transform3D(Basis(), p + Vector3(0, 0.08, 0)))
	# alberi fuori dalla mappa, per dare l'idea di un bosco tutto intorno
	for y in range(-5, 19):
		for x in range(-5, W + 5):
			if x >= 0 and x < W and y >= 0:
				continue
			if (x * 7 + y * 13) % 5 == 0:
				continue
			_tree_at(groups, Vector3(x + 0.5, 0, y + 0.5), 1.1)
	for key in groups:
		var arr: Array = groups[key]
		var mm := MultiMesh.new()
		mm.transform_format = MultiMesh.TRANSFORM_3D
		mm.mesh = _mesh("plane" if key.begins_with("g") else key)
		mm.instance_count = arr.size()
		for i in arr.size():
			mm.set_instance_transform(i, arr[i])
		var mmi := MultiMeshInstance3D.new()
		mmi.multimesh = mm
		mmi.material_override = _mat_for(key)
		tile_root.add_child(mmi)
	_rebuild_astar()


func _rebuild_astar() -> void:
	astar.region = Rect2i(0, 0, W, H)
	astar.cell_size = Vector2(1, 1)
	astar.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_NEVER
	astar.update()
	for y in H:
		for x in W:
			astar.set_point_solid(Vector2i(x, y), not is_walkable_tile(x, y))


func _build_fountain() -> void:
	var f: Array = Game.map_data.get("fontana", [15, 10])
	var fx := int(f[0])
	var fy := int(f[1])
	for c in [Vector2i(fx, fy), Vector2i(fx + 1, fy), Vector2i(fx, fy + 1), Vector2i(fx + 1, fy + 1)]:
		blocked_extra[c] = true
	var n := Node3D.new()
	n.position = Vector3(fx + 1.0, 0, fy + 1.0)
	add_child(n)
	var stone := _tex_mat(PixelTex.tile("P"))
	_prim(n, _cyl_mesh(0.95, 1.0, 0.32), Vector3(0, 0.16, 0), stone)
	_prim(n, _cyl_mesh(0.82, 0.82, 0.04), Vector3(0, 0.31, 0), water_mat)
	_prim(n, _cyl_mesh(0.14, 0.18, 0.75), Vector3(0, 0.55, 0), stone)
	_prim(n, _cyl_mesh(0.42, 0.3, 0.12), Vector3(0, 0.92, 0), stone)
	_prim(n, _cyl_mesh(0.34, 0.34, 0.03), Vector3(0, 0.98, 0), water_mat)
	_rebuild_astar()


func _cyl_mesh(top: float, bottom: float, h: float) -> CylinderMesh:
	var c := CylinderMesh.new()
	c.top_radius = top
	c.bottom_radius = bottom
	c.height = h
	c.radial_segments = 14
	c.rings = 1
	return c


func _prim(parent: Node3D, mesh: Mesh, pos: Vector3, m: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = m
	parent.add_child(mi)
	return mi


func _bx(parent: Node3D, size: Vector3, pos: Vector3, col: Variant) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	var m: Material = col if col is Material else Chibi.mat(col)
	return _prim(parent, b, pos, m)


func _build_houses() -> void:
	blocked_extra = {}
	front_tiles = {}
	for i in houses.size():
		var h: Dictionary = houses[i]
		var hid := str(h["id"])
		var hx := int(h["x"])
		var hy := int(h["y"])
		for dy in 3:
			for dx in 3:
				blocked_extra[Vector2i(hx + dx, hy + dy)] = true
		front_tiles[Vector2i(hx + 1, hy + 3)] = hid
		room_origins[hid] = Vector3(300.0 + i * 12.0, 0.0, 300.0)
		_build_house_exterior(h)
		_build_interior(h)


func house_title(h: Dictionary) -> String:
	var o := str(h.get("owner", ""))
	if o == "player":
		return "Casa tua"
	if o == "" or not Game.npcs.has(o):
		return "Casa libera"
	return "Casa di " + Game.name_of(o)


func refresh_house_labels() -> void:
	for hid in house_labels:
		house_labels[hid].text = house_title(house_by_id[hid])


func _build_house_exterior(h: Dictionary) -> void:
	var hid := str(h["id"])
	if house_nodes.has(hid):
		house_nodes[hid].queue_free()
	var n := Node3D.new()
	n.position = Vector3(float(h["x"]) + 1.5, 0, float(h["y"]) + 1.5)
	add_child(n)
	house_nodes[hid] = n
	var wall := _tex_mat(PixelTex.tile("muro"), Color.html(str(h.get("muro", "#f8f0e0"))))
	var roof := _tex_mat(PixelTex.tile("tetto"), Color.html(str(h.get("tetto", "#d84848"))))
	_bx(n, Vector3(2.7, 1.3, 2.5), Vector3(0, 0.65, 0), wall)
	var pr := PrismMesh.new()
	pr.size = Vector3(2.9, 0.95, 3.1)
	var roof_mi := _prim(n, pr, Vector3(0, 1.3 + 0.475, 0), roof)
	roof_mi.rotation_degrees.y = 90.0
	_bx(n, Vector3(0.28, 0.55, 0.28), Vector3(0.75, 2.0, -0.45), Color.html("#b05040"))
	_bx(n, Vector3(0.6, 0.9, 0.06), Vector3(0, 0.45, 1.25), Color.html("#f8f4ec"))
	_bx(n, Vector3(0.5, 0.82, 0.07), Vector3(0, 0.41, 1.26), Color.html("#8a5a2c"))
	_bx(n, Vector3(0.05, 0.05, 0.03), Vector3(0.16, 0.42, 1.3), Color.html("#f8d030"))
	for sxv in [-0.85, 0.85]:
		var sx := float(sxv)
		_bx(n, Vector3(0.52, 0.46, 0.05), Vector3(sx, 0.8, 1.25), Color.html("#f8f4ec"))
		_bx(n, Vector3(0.42, 0.36, 0.06), Vector3(sx, 0.8, 1.26), Color.html("#a8d8f8"))
		_bx(n, Vector3(0.42, 0.04, 0.07), Vector3(sx, 0.8, 1.27), Color.html("#f8f4ec"))
	var lbl := Label3D.new()
	lbl.text = house_title(h)
	lbl.font_size = 40
	lbl.pixel_size = 0.004
	lbl.outline_size = 10
	lbl.modulate = Color.html("#303848")
	lbl.outline_modulate = Color.WHITE
	lbl.position = Vector3(0, 1.08, 1.32)
	n.add_child(lbl)
	house_labels[hid] = lbl


func room_origin(hid: String) -> Vector3:
	return room_origins.get(hid, Vector3(300, 0, 300))


func _furn_cells(h: Dictionary, only_blocking: bool = true) -> Dictionary:
	var cells := {}
	for f in h.get("arredi", []):
		var fp: Array = FURN.get(str(f["tipo"]), [1, 1, true])
		if only_blocking and not fp[2]:
			continue
		for dy in int(fp[1]):
			for dx in int(fp[0]):
				cells[Vector2i(int(f["x"]) + dx, int(f["y"]) + dy)] = f
	return cells


func is_walkable_room(hid: String, cx: int, cy: int) -> bool:
	if cx < 0 or cy < 0 or cx >= ROOM_W or cy >= ROOM_D:
		return false
	return not _furn_cells(house_by_id[hid]).has(Vector2i(cx, cy))


func bed_spot(hid: String) -> Vector3:
	var h: Dictionary = house_by_id[hid]
	var o := room_origin(hid)
	for f in h.get("arredi", []):
		if str(f["tipo"]) == "letto":
			var bx := int(f["x"])
			var by := int(f["y"])
			for c in [Vector2i(bx + 1, by + 1), Vector2i(bx - 1, by + 1), Vector2i(bx, by + 2)]:
				if is_walkable_room(hid, c.x, c.y):
					return o + Vector3(c.x + 0.5, 0, c.y + 0.5)
	return o + Vector3(1.5, 0, 3.5)


func _build_interior(h: Dictionary) -> void:
	var hid := str(h["id"])
	if interiors.has(hid):
		interiors[hid].queue_free()
	var root := Node3D.new()
	root.position = room_origin(hid)
	add_child(root)
	interiors[hid] = root
	var pm := PlaneMesh.new()
	pm.size = Vector2(ROOM_W, ROOM_D)
	var fm := _tex_mat(PixelTex.tile("legno"))
	fm.uv1_scale = Vector3(ROOM_W, ROOM_D, 1)
	_prim(root, pm, Vector3(ROOM_W / 2.0, 0, ROOM_D / 2.0), fm)
	var wm := _tex_mat(PixelTex.tile("muro"), Color.html(str(h.get("muro", "#f8f0e0"))))
	var trim := Chibi.mat(Color.html(str(h.get("tetto", "#d84848"))))
	_bx(root, Vector3(ROOM_W + 0.4, 2.0, 0.2), Vector3(ROOM_W / 2.0, 1.0, -0.1), wm)
	_bx(root, Vector3(ROOM_W + 0.4, 0.15, 0.22), Vector3(ROOM_W / 2.0, 0.07, -0.1), trim)
	_bx(root, Vector3(0.2, 2.0, ROOM_D), Vector3(-0.1, 1.0, ROOM_D / 2.0), wm)
	_bx(root, Vector3(0.2, 2.0, ROOM_D), Vector3(ROOM_W + 0.1, 1.0, ROOM_D / 2.0), wm)
	_bx(root, Vector3(3.0, 0.3, 0.2), Vector3(1.5, 0.15, ROOM_D + 0.1), wm)
	_bx(root, Vector3(3.0, 0.3, 0.2), Vector3(5.5, 0.15, ROOM_D + 0.1), wm)
	_bx(root, Vector3(0.9, 0.02, 0.7), Vector3(3.5, 0.01, 5.5), Color.html("#c84848"))
	_bx(root, Vector3(0.8, 0.6, 0.05), Vector3(5.2, 1.2, 0.02), Color.html("#a8d8f8"))
	var light := OmniLight3D.new()
	light.position = Vector3(ROOM_W / 2.0, 1.8, ROOM_D / 2.0)
	light.omni_range = 7.0
	light.light_energy = 0.7
	light.light_color = Color(1.0, 0.92, 0.78)
	root.add_child(light)
	var furn := Node3D.new()
	furn.name = "Arredi"
	root.add_child(furn)
	_build_furniture(h, furn)


func rebuild_furniture(hid: String) -> void:
	var root: Node3D = interiors[hid]
	var old := root.get_node_or_null("Arredi")
	if old:
		root.remove_child(old)
		old.queue_free()
	var furn := Node3D.new()
	furn.name = "Arredi"
	root.add_child(furn)
	_build_furniture(house_by_id[hid], furn)


func _build_furniture(h: Dictionary, parent: Node3D) -> void:
	var accent := Color.html(str(h.get("tetto", "#d84848")))
	var wood := Color.html("#a8703c")
	for f in h.get("arredi", []):
		var t := str(f["tipo"])
		var fp: Array = FURN.get(t, [1, 1, true])
		var w := float(fp[0])
		var d := float(fp[1])
		var n := Node3D.new()
		n.position = Vector3(int(f["x"]) + w / 2.0, 0, int(f["y"]) + d / 2.0)
		parent.add_child(n)
		match t:
			"letto":
				_bx(n, Vector3(0.9, 0.3, 1.9), Vector3(0, 0.15, 0), wood)
				_bx(n, Vector3(0.84, 0.1, 1.2), Vector3(0, 0.34, 0.3), accent)
				_bx(n, Vector3(0.6, 0.12, 0.35), Vector3(0, 0.35, -0.65), Color.WHITE)
				_bx(n, Vector3(0.9, 0.55, 0.08), Vector3(0, 0.28, -0.92), wood)
			"tavolo":
				_bx(n, Vector3(0.8, 0.07, 0.8), Vector3(0, 0.5, 0), wood)
				_bx(n, Vector3(0.12, 0.5, 0.12), Vector3(0, 0.25, 0), wood.darkened(0.2))
			"sedia":
				_bx(n, Vector3(0.42, 0.06, 0.42), Vector3(0, 0.28, 0), wood)
				_bx(n, Vector3(0.42, 0.38, 0.06), Vector3(0, 0.5, -0.19), wood)
				_bx(n, Vector3(0.08, 0.28, 0.08), Vector3(0, 0.14, 0), wood.darkened(0.2))
			"tappeto":
				_bx(n, Vector3(1.8, 0.02, 1.8), Vector3(0, 0.012, 0), accent.lightened(0.3))
				_bx(n, Vector3(1.4, 0.022, 1.4), Vector3(0, 0.014, 0), accent)
			"libreria":
				_bx(n, Vector3(0.9, 1.5, 0.4), Vector3(0, 0.75, -0.28), wood.darkened(0.15))
				var cols := ["#d84848", "#4878d8", "#58a858", "#f8d030", "#9868c8"]
				for row in 3:
					for k in 5:
						_bx(n, Vector3(0.13, 0.28, 0.05), Vector3(-0.32 + k * 0.16, 0.35 + row * 0.42, -0.07), Color.html(cols[(k + row) % 5]))
			"pianta":
				_prim(n, _cyl_mesh(0.18, 0.13, 0.3), Vector3(0, 0.15, 0), Chibi.mat(Color.html("#c86838")))
				var s := SphereMesh.new()
				s.radius = 0.3
				s.height = 0.55
				s.radial_segments = 8
				s.rings = 4
				_prim(n, s, Vector3(0, 0.55, 0), _tex_mat(PixelTex.tile("foglie")))
			"tv":
				_bx(n, Vector3(0.85, 0.32, 0.4), Vector3(0, 0.16, -0.2), wood)
				_bx(n, Vector3(0.72, 0.48, 0.08), Vector3(0, 0.58, -0.25), Color.html("#303038"))
				_bx(n, Vector3(0.62, 0.38, 0.02), Vector3(0, 0.58, -0.2), Color.html("#68a8d8"))
			"lampada":
				_prim(n, _cyl_mesh(0.03, 0.03, 1.1), Vector3(0, 0.55, 0), Chibi.mat(Color.html("#505868")))
				_prim(n, _cyl_mesh(0.12, 0.22, 0.25), Vector3(0, 1.2, 0), lamp_mat)
				_prim(n, _cyl_mesh(0.16, 0.18, 0.05), Vector3(0, 0.025, 0), Chibi.mat(Color.html("#505868")))
			"cucina":
				_bx(n, Vector3(0.9, 0.8, 0.6), Vector3(0, 0.4, -0.15), Color.html("#f0f0f0"))
				_bx(n, Vector3(0.8, 0.03, 0.5), Vector3(0, 0.815, -0.15), Color.html("#404048"))
				_bx(n, Vector3(0.6, 0.35, 0.02), Vector3(0, 0.4, 0.16), Color.html("#d8d8d8"))
			"divano":
				_bx(n, Vector3(1.85, 0.32, 0.7), Vector3(0, 0.2, 0), accent)
				_bx(n, Vector3(1.85, 0.42, 0.18), Vector3(0, 0.45, -0.27), accent.darkened(0.15))
				_bx(n, Vector3(0.16, 0.45, 0.7), Vector3(-0.85, 0.25, 0), accent.darkened(0.15))
				_bx(n, Vector3(0.16, 0.45, 0.7), Vector3(0.85, 0.25, 0), accent.darkened(0.15))


func _build_player() -> void:
	player = Chibi.new()
	add_child(player)
	player.build(Game.player.get("aspetto", {}))
	var home: Dictionary = house_by_id.get("casa_tua", houses[0])
	player.position = Vector3(float(home["x"]) + 1.5, 0, float(home["y"]) + 3.5)
	player.face_now(Vector3(0, 0, 1))
	cam_target = player.position


func rebuild_player() -> void:
	player.build(Game.player.get("aspetto", {}))


func _spawn_npcs() -> void:
	for id in npc_nodes:
		npc_nodes[id].queue_free()
	npc_nodes = {}
	for id in Game.npc_order:
		spawn_npc(id)


func spawn_npc(id: String) -> void:
	var n: Npc = Npc.new()
	n.id = id
	n.main = self
	add_child(n)
	n.build(Game.npcs[id].get("aspetto", {}))
	var c: Vector2i = npc_desire(id).get("centro", house_front(id))
	var t := random_walkable_near(c, 3)
	n.position = Vector3(t.x + 0.5, 0, t.y + 0.5)
	n.face_now(Vector3(0, 0, 1))
	npc_nodes[id] = n


func despawn_npc(id: String) -> void:
	if npc_nodes.has(id):
		npc_nodes[id].queue_free()
		npc_nodes.erase(id)


func _build_rain() -> void:
	rain = CPUParticles3D.new()
	rain.amount = 260
	rain.lifetime = 0.7
	rain.emitting = false
	rain.local_coords = false
	rain.emission_shape = CPUParticles3D.EMISSION_SHAPE_BOX
	rain.emission_box_extents = Vector3(9, 0.5, 7)
	rain.direction = Vector3(0, -1, 0)
	rain.spread = 4.0
	rain.gravity = Vector3(0, -20, 0)
	rain.initial_velocity_min = 8.0
	rain.initial_velocity_max = 10.0
	var qm := QuadMesh.new()
	qm.size = Vector2(0.03, 0.35)
	var m := StandardMaterial3D.new()
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	m.albedo_color = Color(0.85, 0.9, 1.0, 0.6)
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.billboard_mode = BaseMaterial3D.BILLBOARD_FIXED_Y
	qm.material = m
	rain.mesh = qm
	add_child(rain)


# ================================================================ percorsi e posti

func house_front(id: String) -> Vector2i:
	var hid := str(Game.npcs.get(id, {}).get("casa", ""))
	if house_by_id.has(hid):
		var h: Dictionary = house_by_id[hid]
		return Vector2i(int(h["x"]) + 1, int(h["y"]) + 3)
	return piazza_center()


func piazza_center() -> Vector2i:
	var p: Array = Game.map_data.get("piazza", [13, 12])
	return Vector2i(int(p[0]), int(p[1]))


func random_walkable_near(c: Vector2i, r: int) -> Vector2i:
	for i in 25:
		var t := c + Vector2i(randi_range(-r, r), randi_range(-r, r))
		if is_walkable_tile(t.x, t.y):
			return t
	if is_walkable_tile(c.x, c.y):
		return c
	for i in 200:
		var t2 := Vector2i(randi_range(1, W - 2), randi_range(1, H - 2))
		if is_walkable_tile(t2.x, t2.y):
			return t2
	return c


func find_path(from: Vector3, to: Vector2i) -> Array:
	var a := Vector2i(floori(from.x), floori(from.z))
	if not is_walkable_tile(a.x, a.y) or not is_walkable_tile(to.x, to.y):
		return []
	var ids: Array[Vector2i] = astar.get_id_path(a, to)
	var out: Array = []
	for v in ids:
		out.append(Vector3(v.x + 0.5, 0.0, v.y + 0.5))
	return out


func tile_near_player() -> Vector2i:
	var p := Vector2i(floori(player.position.x), floori(player.position.z))
	for d in [Vector2i(0, 1), Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, -1)]:
		if is_walkable_tile(p.x + d.x, p.y + d.y):
			return p + d
	return p


func npc_desire(id: String) -> Dictionary:
	var h := Game.hour()
	var d: Dictionary = Game.npcs.get(id, {})
	var has_house := house_by_id.has(str(d.get("casa", "")))
	if str(Game.status.get(id, "")) == "malato" and has_house:
		return {"tipo": "casa"}
	var festa: bool = Game.flags.get("festival_oggi", false) or int(Game.flags.get("festa_giorno", -1)) == Game.day
	if festa and h >= 18.5 and h < 22.5:
		return {"tipo": "fuori", "centro": piazza_center(), "raggio": 3}
	if (h >= 21.0 or h < 7.0) and has_house:
		return {"tipo": "casa"}
	if Game.pending_confession == id and player_zone == "out" and not input_locked and h >= 8.0 and h < 20.0:
		return {"tipo": "giocatore"}
	var c := house_front(id)
	var raggio := 5
	var luogo: Variant = d.get("luogo", null)
	if luogo is Array and luogo.size() == 2:
		c = Vector2i(int(luogo[0]), int(luogo[1]))
	if Game.weather == "pioggia" and has_house and Game.trait_val(id, "energico") < 70.0:
		c = house_front(id)
		raggio = 2
	return {"tipo": "fuori", "centro": c, "raggio": raggio}


## Descrizione a parole di dove si trova un abitante, per l'IA.
func situation_for(id: String) -> String:
	var n: Npc = npc_nodes.get(id)
	if n == null:
		return ""
	var h := Game.hour()
	var momento := "notte"
	if h >= 5.0 and h < 12.0:
		momento = "mattina"
	elif h >= 12.0 and h < 18.0:
		momento = "pomeriggio"
	elif h >= 18.0 and h < 22.0:
		momento = "sera"
	var dove := "per le stradine del villaggio"
	if n.zone != "out":
		var h_owner := str(house_by_id.get(n.zone, {}).get("owner", ""))
		if h_owner == id:
			dove = "a casa tua: {player} è venut%s a trovarti" % Game.g("player")
			if n.is_sleeping():
				dove += " e ti ha svegliat{o} (sei mezz{o} addormentat{o})"
		elif h_owner == "player":
			dove = "a casa di {player}"
		else:
			dove = "in casa di qualcun altro"
	else:
		var t := Vector2i(floori(n.position.x), floori(n.position.z))
		var ch := tile_at(t.x, t.y)
		if ch == "S" or ch == "B":
			dove = "sulla spiaggia, davanti al mare"
		elif ch == "P":
			dove = "in piazza, vicino alla fontana"
		elif ch == "*":
			dove = "in mezzo ai fiori"
		else:
			for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
				if tile_at(t.x + d.x, t.y + d.y) == "T":
					dove = "vicino agli alberi del bosco"
					break
	return "È %s. Siete %s." % [momento, dove]


func try_npc_social(n: Npc) -> void:
	for oid in npc_nodes:
		var o: Npc = npc_nodes[oid]
		if o == n or o.zone != "out" or n.zone != "out" or o.state != "idle" or not o.path.is_empty() or o.social_cd > 0.0:
			continue
		if o.position.distance_to(n.position) > 2.2:
			continue
		var res := Game.npc_interact(n.id, o.id)
		for x in [n, o]:
			x.state = "talk"
			x.talk_time = 3.5
			x.social_cd = randf_range(25.0, 45.0)
		n.face_dir(o.position - n.position)
		o.face_dir(n.position - o.position)
		var icon_name: String = {"bene": "nota", "male": "rabbia", "amore": "cuore"}.get(res, "puntini")
		n.show_icon(icon_name, 3.0)
		o.show_icon(icon_name, 3.0)
		return


# ================================================================ ciclo di gioco

func _process(delta: float) -> void:
	var blocking: bool = ui.is_blocking()
	Game.time_paused = blocking
	Game.advance_time(delta)
	_update_lights()
	water_mat.uv1_offset.x += delta * 0.04
	sea_mat.uv1_offset.x += delta * 0.04
	_door_cd -= delta
	var dir := Vector2.ZERO
	if not input_locked and not blocking:
		dir = Input.get_vector("sx", "dx", "su", "giu")
		var jv: Vector2 = ui.joystick_vector()
		if jv.length() > 0.0:
			dir = jv
		if Input.is_action_just_pressed("azione"):
			do_action()
	if dir.length() > 1.0:
		dir = dir.normalized()
	if dir.length() > 0.05:
		var v := Vector3(dir.x, 0, dir.y) * 3.6 * delta
		var np := player.position + Vector3(v.x, 0, 0)
		if can_stand(player_zone, np):
			player.position = np
		np = player.position + Vector3(0, 0, v.z)
		if can_stand(player_zone, np):
			player.position = np
		player.face_dir(Vector3(dir.x, 0, dir.y))
		player.moving = true
	else:
		player.moving = false
	_check_doors(dir)
	_check_pickups(delta)
	for id in npc_nodes:
		npc_nodes[id].update_npc(delta)
	_update_interaction()
	_update_lanterns(delta)
	_update_camera(delta)


func can_stand(zone: String, p: Vector3) -> bool:
	var r := 0.2
	for off in [Vector2(-r, -r), Vector2(r, -r), Vector2(-r, r), Vector2(r, r)]:
		var qx: float = p.x + off.x
		var qz: float = p.z + off.y
		if zone == "out":
			if not is_walkable_tile(floori(qx), floori(qz)):
				return false
		else:
			var o := room_origin(zone)
			if not is_walkable_room(zone, floori(qx - o.x), floori(qz - o.z)):
				return false
	return true


func _player_tile() -> Vector2i:
	return Vector2i(floori(player.position.x), floori(player.position.z))


func _player_cell() -> Vector2i:
	var o := room_origin(player_zone)
	return Vector2i(floori(player.position.x - o.x), floori(player.position.z - o.z))


func _check_doors(dir: Vector2) -> void:
	if _door_cd > 0.0 or editor_mode:
		return
	if player_zone == "out":
		var t := _player_tile()
		if front_tiles.has(t) and dir.y < -0.6:
			enter_house(front_tiles[t])
	else:
		if _player_cell() == EXIT_CELL and dir.y > 0.6:
			exit_house()


func enter_house(hid: String) -> void:
	player_zone = hid
	player.position = room_origin(hid) + Vector3(3.5, 0, 4.5)
	player.face_now(Vector3(0, 0, -1))
	cam_target = player.position
	_door_cd = 0.6
	ui.toast(house_title(house_by_id[hid]))
	if editor_mode:
		ui.refresh_editor_bar()


func exit_house() -> void:
	if player_zone == "out":
		return
	var h: Dictionary = house_by_id[player_zone]
	player_zone = "out"
	player.position = Vector3(int(h["x"]) + 1.5, 0, int(h["y"]) + 3.5)
	player.face_now(Vector3(0, 0, 1))
	cam_target = player.position
	_door_cd = 0.6
	if editor_mode:
		ui.refresh_editor_bar()


func _update_camera(delta: float) -> void:
	var t := player.position
	if player_zone == "out":
		t.x = clampf(t.x, 6.5, W - 6.5)
		t.z = clampf(t.z, 3.0, H - 2.5)
	else:
		var o := room_origin(player_zone)
		t = o + Vector3(ROOM_W / 2.0, 0, ROOM_D / 2.0 + 0.3)
	cam_target = cam_target.lerp(t, minf(1.0, delta * 6.0))
	cam.position = cam_target + Vector3(0, 7.6, 6.8)
	cam.look_at(cam_target + Vector3(0, 0.3, 0), Vector3.UP)


func _update_lights() -> void:
	var h := Game.hour()
	var day_c := Color(1.0, 0.98, 0.93)
	var dusk_c := Color(1.0, 0.72, 0.5)
	var night_c := Color(0.5, 0.55, 0.9)
	var col: Color
	var en: float
	var amb: float
	var sky: Color
	if h < 5.0 or h >= 21.0:
		col = night_c
		en = 0.25
		amb = 0.38
		sky = Color(0.08, 0.1, 0.25)
	elif h < 7.0:
		var k := (h - 5.0) / 2.0
		col = night_c.lerp(dusk_c, k)
		en = lerpf(0.25, 0.8, k)
		amb = lerpf(0.38, 0.55, k)
		sky = Color(0.08, 0.1, 0.25).lerp(Color(0.95, 0.7, 0.6), k)
	elif h < 17.0:
		var k2 := clampf((h - 7.0) / 1.5, 0.0, 1.0)
		col = dusk_c.lerp(day_c, k2)
		en = lerpf(0.8, 1.0, k2)
		amb = 0.6
		sky = Color(0.95, 0.7, 0.6).lerp(Color(0.55, 0.8, 1.0), k2)
	elif h < 19.0:
		var k3 := (h - 17.0) / 2.0
		col = day_c.lerp(dusk_c, k3)
		en = lerpf(1.0, 0.75, k3)
		amb = lerpf(0.6, 0.5, k3)
		sky = Color(0.55, 0.8, 1.0).lerp(Color(1.0, 0.62, 0.45), k3)
	else:
		var k4 := (h - 19.0) / 2.0
		col = dusk_c.lerp(night_c, k4)
		en = lerpf(0.75, 0.25, k4)
		amb = lerpf(0.5, 0.38, k4)
		sky = Color(1.0, 0.62, 0.45).lerp(Color(0.08, 0.1, 0.25), k4)
	var raining := Game.weather == "pioggia"
	if raining:
		col = col.lerp(Color(0.7, 0.75, 0.85), 0.5)
		en *= 0.7
		sky = sky.lerp(Color(0.5, 0.55, 0.62), 0.6)
	if player_zone != "out":
		col = Color(1.0, 0.94, 0.84)
		en = 0.55
		amb = 0.7
		sky = Color(0.06, 0.05, 0.08)
	sun.light_color = col
	sun.light_energy = en
	env.ambient_light_energy = amb
	env.ambient_light_color = col.lerp(Color.WHITE, 0.5)
	env.background_color = sky
	lamp_mat.emission_energy_multiplier = 2.2 if (h >= 18.5 or h < 6.5) else 0.0
	rain.emitting = raining and player_zone == "out"
	rain.position = player.position + Vector3(0, 6, 0)


# ================================================================ interazioni

func _update_interaction() -> void:
	var label := ""
	var best: Npc = null
	var bd := 1.35
	for id in npc_nodes:
		var n: Npc = npc_nodes[id]
		if n.zone != player_zone:
			continue
		var dd := n.position.distance_to(player.position)
		if dd < bd:
			bd = dd
			best = n
	near_npc = best
	interaction = ""
	if best != null:
		interaction = "npc"
		label = "Parla"
	elif player_zone == "out":
		var t := _player_tile()
		if front_tiles.has(t):
			interaction = "entra"
			interaction_house = front_tiles[t]
			label = "Entra"
	else:
		var c := _player_cell()
		if c == EXIT_CELL or c == EXIT_CELL + Vector2i(0, -1):
			interaction = "esci"
			label = "Esci"
		if str(house_by_id[player_zone].get("owner", "")) == "player":
			var cells := _furn_cells(house_by_id[player_zone])
			for cell in cells:
				var f: Dictionary = cells[cell]
				if str(f["tipo"]) == "letto" and Vector2(cell - c).length() <= 1.5:
					interaction = "dormi"
					label = "Dormi"
					break
	if editor_mode:
		label = ""
	ui.set_action_label(label)


func do_action() -> void:
	if input_locked or ui.is_blocking():
		return
	match interaction:
		"npc":
			if near_npc:
				start_talk(near_npc)
		"entra":
			enter_house(interaction_house)
		"esci":
			exit_house()
		"dormi":
			ui.confirm("Vuoi dormire fino a domattina?", _sleep)


func _sleep() -> void:
	ui.fade(Game.sleep_until_morning)


func start_talk(n: Npc) -> void:
	talk_target = n
	n.state = "busy"
	n.path = []
	n.face_dir(player.position - n.position)
	player.face_dir(n.position - player.position)
	input_locked = true
	ui.open_npc(n.id)


func end_talk() -> void:
	if talk_target and is_instance_valid(talk_target):
		talk_target.state = "idle"
		talk_target.wait = 2.0
		talk_target.social_cd = 10.0
	talk_target = null
	input_locked = false


func start_confession(n: Npc) -> void:
	if input_locked or ui.is_blocking():
		return
	talk_target = n
	n.state = "busy"
	n.face_dir(player.position - n.position)
	player.face_dir(n.position - player.position)
	n.show_icon("cuore", 4.0)
	input_locked = true
	Game.pending_confession = ""
	ui.run_node("conf_1", n.id, end_talk)


func start_date(id: String, place: Dictionary) -> void:
	var n: Npc = npc_nodes[id]
	var pos: Array = place["pos"]
	var p := Vector2i(int(pos[0]), int(pos[1]))
	player_zone = "out"
	player.position = Vector3(p.x + 0.5, 0, p.y + 0.5)
	n.zone = "out"
	n.path = []
	n.hide_icon()
	n.position = Vector3(p.x + 1.5, 0, p.y + 0.5)
	n.face_now(Vector3(-1, 0, 0))
	player.face_now(Vector3(1, 0, 0))
	cam_target = player.position
	n.show_icon("cuore", 3.0)


# ================================================================ oggetti

func _respawn_pickups() -> void:
	for p in pickups:
		if is_instance_valid(p["node"]):
			p["node"].queue_free()
	pickups = []
	var pool: Array = []
	for k in Game.items:
		if Game.items[k].get("spawn", false):
			pool.append(k)
	if pool.is_empty():
		return
	for i in 7:
		var it: String = pool.pick_random()
		var want: String = {"erba": ".", "fiori": "*", "sabbia": "S"}.get(str(Game.items[it].get("dove", "erba")), ".")
		var t := _random_tile_of(want)
		if t.x >= 0:
			_spawn_pickup(it, t)
	for q in Game.quests:
		if not q["done"] and int(Game.inventory.get(str(q["item"]), 0)) == 0:
			var t2 := _random_tile_of(".")
			if t2.x >= 0:
				_spawn_pickup(str(q["item"]), t2)


func _random_tile_of(ch: String) -> Vector2i:
	for i in 300:
		var t := Vector2i(randi_range(1, W - 2), randi_range(1, H - 2))
		if tile_at(t.x, t.y) == ch and is_walkable_tile(t.x, t.y) and not front_tiles.has(t):
			return t
	return Vector2i(-1, -1)


func _spawn_pickup(item_id: String, t: Vector2i) -> void:
	var s := Sprite3D.new()
	s.texture = PixelTex.item_icon_for(Game.items.get(item_id, {}))
	s.pixel_size = 0.035
	s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	s.position = Vector3(t.x + 0.5, 0.35, t.y + 0.5)
	add_child(s)
	var sp := Sprite3D.new()
	sp.texture = PixelTex.status_icon("stella")
	sp.pixel_size = 0.025
	sp.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sp.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	sp.position = Vector3(0.18, 0.2, 0)
	s.add_child(sp)
	pickups.append({"node": s, "item": item_id, "t": randf() * 6.0})


func _check_pickups(delta: float) -> void:
	for i in range(pickups.size() - 1, -1, -1):
		var p: Dictionary = pickups[i]
		var s: Sprite3D = p["node"]
		p["t"] = float(p["t"]) + delta
		s.position.y = 0.35 + sin(float(p["t"]) * 3.0) * 0.06
		s.get_child(0).visible = int(float(p["t"]) * 2.0) % 3 == 0
		if player_zone == "out" and Vector2(s.position.x - player.position.x, s.position.z - player.position.z).length() < 0.55:
			var it := str(p["item"])
			Game.add_item(it, 1)
			ui.toast("Hai trovato: %s!" % Game.item_name(it))
			s.queue_free()
			pickups.remove_at(i)


func _on_day_changed(_d: int) -> void:
	_respawn_pickups()
	for l in lanterns:
		l["node"].queue_free()
	lanterns = []
	if Ai.is_configured():
		Ai.gazette()


func _update_lanterns(delta: float) -> void:
	var active := int(Game.flags.get("lanterne_giorno", -1)) == Game.day and (Game.hour() >= 19.0 or Game.hour() < 5.0)
	if active and lanterns.is_empty():
		var c := piazza_center()
		for i in 40:
			var s := Sprite3D.new()
			s.texture = PixelTex.item_icon("lanterna", Color.html("#f8a040"))
			s.pixel_size = 0.03
			s.billboard = BaseMaterial3D.BILLBOARD_ENABLED
			s.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
			s.position = Vector3(c.x + randf_range(-6, 7), randf_range(0.5, 9.0), c.y + randf_range(-4, 4))
			add_child(s)
			lanterns.append({"node": s, "v": randf_range(0.25, 0.6)})
	elif not active and not lanterns.is_empty():
		for l in lanterns:
			l["node"].queue_free()
		lanterns = []
	for l in lanterns:
		var s2: Sprite3D = l["node"]
		s2.position.y += float(l["v"]) * delta
		s2.position.x += sin(s2.position.y * 1.3) * delta * 0.15
		if s2.position.y > 10.0:
			s2.position.y = 0.5


# ================================================================ editor

func set_editor(on: bool) -> void:
	editor_mode = on
	if on:
		editor_brush = "." if player_zone == "out" else "letto"


func _unhandled_input(event) -> void:
	if not editor_mode or ui.is_blocking():
		return
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_editor_tap(event.position)


func _editor_tap(pos: Vector2) -> void:
	var o := cam.project_ray_origin(pos)
	var d := cam.project_ray_normal(pos)
	if absf(d.y) < 0.001:
		return
	var hit := o + d * (-o.y / d.y)
	if player_zone == "out":
		var tx := floori(hit.x)
		var ty := floori(hit.z)
		if tx < 1 or ty < 1 or tx >= W - 1 or ty >= H - 1:
			ui.toast("Il bordo del villaggio non si può modificare.")
			return
		var tv := Vector2i(tx, ty)
		if blocked_extra.has(tv):
			ui.toast("Lì c'è una costruzione.")
			return
		var walk := WALKABLE.has(editor_brush)
		if front_tiles.has(tv) and not walk:
			ui.toast("Non bloccare l'ingresso di una casa!")
			return
		if tv == _player_tile() and not walk:
			ui.toast("Ci sei sopra tu!")
			return
		if tile_at(tx, ty) == editor_brush:
			return
		set_tile(tx, ty, editor_brush)
		_build_tiles()
		_relocate_stuck_npcs()
	else:
		if str(house_by_id[player_zone].get("owner", "")) != "player":
			ui.toast("Puoi arredare solo casa tua.")
			return
		var ro := room_origin(player_zone)
		var cx := floori(hit.x - ro.x)
		var cy := floori(hit.z - ro.z)
		if cx < 0 or cy < 0 or cx >= ROOM_W or cy >= ROOM_D:
			return
		var h: Dictionary = house_by_id[player_zone]
		var arr: Array = h["arredi"]
		var all := _furn_cells(h, false)
		if all.has(Vector2i(cx, cy)):
			arr.erase(all[Vector2i(cx, cy)])
			rebuild_furniture(player_zone)
			return
		if editor_brush == "rimuovi":
			return
		var fp: Array = FURN[editor_brush]
		var pc := _player_cell()
		for dy in int(fp[1]):
			for dx in int(fp[0]):
				var cc := Vector2i(cx + dx, cy + dy)
				if cc.x >= ROOM_W or cc.y >= ROOM_D or all.has(cc):
					ui.toast("Non c'è abbastanza spazio.")
					return
				if fp[2] and (cc == EXIT_CELL or cc == EXIT_CELL + Vector2i(0, -1) or cc == pc):
					ui.toast("Lascia libero il passaggio!")
					return
		arr.append({"tipo": editor_brush, "x": cx, "y": cy})
		rebuild_furniture(player_zone)


func _relocate_stuck_npcs() -> void:
	for id in npc_nodes:
		var n: Npc = npc_nodes[id]
		if n.zone != "out":
			continue
		n.path = []
		var t := Vector2i(floori(n.position.x), floori(n.position.z))
		if not is_walkable_tile(t.x, t.y):
			var nt := random_walkable_near(t, 2)
			n.position = Vector3(nt.x + 0.5, 0, nt.y + 0.5)
