extends RefCounted
## Genera al volo tutte le texture in pixel art (niente file immagine esterni).

static var _cache: Dictionary = {}

const ICONS := {
	"cuore": [".rr..rr.", "rwrrrrrr", "rwrrrrrr", "rrrrrrrr", ".rrrrrr.", "..rrrr..", "...rr...", "........"],
	"esclamazione": ["..kyyk..", "..kyyk..", "..kyyk..", "..kyyk..", "..kyyk..", "...kk...", "..kyyk..", "...kk..."],
	"nota": ["....uuuu", "....u..u", "....u..u", "....u..u", "..uuu.uu", ".uuuuuuu", ".uuu.uuu", "........"],
	"rabbia": ["rr....rr", "rr....rr", "..r..r..", "........", "........", "..r..r..", "rr....rr", "rr....rr"],
	"puntini": ["........", "........", "........", "kk.kk.kk", "kk.kk.kk", "........", "........", "........"],
	"zzz": ["uuuuu...", "...u....", "..u.....", ".u......", "uuuuu...", ".....uuu", "......u.", ".....uuu"],
	"stella": ["...y....", "...y....", "..yyy...", "yyywyyy.", "..yyy...", "...y....", "...y....", "........"],
}

const ITEM_ICONS := {
	"mela": ["....gg....", "...gn.....", "..kkkkkk..", ".kaaacaak.", "kaaaaccaak", "kaaaaaaaak", "kaaaaaaaak", "kbaaaaaabk", ".kbbaabbk.", "..kkkkkk.."],
	"fiore": ["..aa.aa...", ".aaaaaaa..", "aaaayaaaa.", ".aayyyaa..", "aaaayaaaa.", ".aaaaaaa..", "..aa.aa...", "....g.....", "...ggg....", "....g....."],
	"conchiglia": ["...kkkk...", "..kacack..", ".kacacack.", "kacacacack", "kacacacack", "kacacacack", ".kacacack.", "..kbbbbk..", "...kbbk...", "....kk...."],
	"pesce": ["..........", "...kkkk...", ".kkaaaak.k", "kaaaaaaakk", "kawaaaaaak", "kaaaaaaaak", "kbbaaaaakk", ".kkbbbbk.k", "...kkkk...", ".........."],
	"gemma": ["....kk....", "...kcck...", "..kccaak..", ".kcaaaaak.", "kcaaaaaabk", ".kaaaaabk.", "..kaaabk..", "...kabk...", "....kk....", ".........."],
	"insetto": ["...k..k...", "....kk....", "...kkkk...", "..kakkak..", ".kaakkaak.", ".kkakkakk.", ".kaakkaak.", "..kakkak..", "...kkkk...", ".........."],
	"trifoglio": ["..gg..gg..", ".gccggccg.", ".gggggggg.", "..gggggg..", ".gggggggg.", ".gccggccg.", "..gg.ngg..", ".....n....", "....n.....", ".........."],
	"torta": ["....y.....", "....a.....", "..kkkkkk..", ".kwwwwwwk.", ".kaaaaaak.", ".kwwwwwwk.", ".kaaaaaak.", ".kbbbbbbk.", "..kkkkkk..", ".........."],
	"tazza": ["..w..w....", "...w..w...", ".kkkkkkk..", ".kaaaaakkk", ".kaaaaak.k", ".kaaaaakkk", "..kaaak...", ".kkkkkkk..", "..........", ".........."],
	"libro": [".kkkkkkk..", ".kaaaaawk.", ".kaaaaawk.", ".kacccawk.", ".kaaaaawk.", ".kaaaaawk.", ".kaaaaawk.", ".kbbbbbwk.", ".kkkkkkk..", ".........."],
	"nota": [".....kk...", ".....kak..", ".....k.ak.", ".....k..k.", ".....k....", ".....k....", "..kkkk....", ".kaaak....", ".kaaak....", "..kkk....."],
	"pennello": ["........kk", ".......kak", "......kak.", ".....kak..", "....kak...", "...knk....", "..kwwk....", ".kwwk.....", "kaak......", "kk........"],
	"pallone": ["..kkkkkk..", ".kwwaawwk.", "kwwaaaawwk", "kwwwaawwwk", "kawwwwwwak", "kaawwwwaak", "kwwwaawwwk", "kwwaaaawwk", ".kwwaawwk.", "..kkkkkk.."],
	"lanterna": ["...kkkk...", "....kk....", "..kkkkkk..", ".kayyyyak.", ".kyyyyyyk.", ".kyywwyyk.", ".kyyyyyyk.", ".kayyyyak.", "..kkkkkk..", "...k..k..."],
}


static func _done(key: String, img: Image) -> ImageTexture:
	var t := ImageTexture.create_from_image(img)
	_cache[key] = t
	return t


static func _noise(img: Image, base: Color, alt: Color, chance: float, seed_val: int) -> RandomNumberGenerator:
	var r := RandomNumberGenerator.new()
	r.seed = seed_val
	for y in img.get_height():
		for x in img.get_width():
			img.set_pixel(x, y, alt if r.randf() < chance else base)
	return r


static func c(hex: String) -> Color:
	return Color.html(hex)


## Texture 16x16 per ogni tipo di casella della mappa.
static func tile(kind: String) -> ImageTexture:
	var key := "tile_" + kind
	if _cache.has(key):
		return _cache[key]
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	match kind:
		".", "*":
			var r := _noise(img, c("#78c858"), c("#6cbc4c"), 0.25, 11)
			for i in 7:
				var x := r.randi_range(1, 14)
				var y := r.randi_range(2, 14)
				img.set_pixel(x, y, c("#50a038"))
				img.set_pixel(x - 1, y - 1, c("#50a038"))
				img.set_pixel(x + 1, y - 1, c("#50a038"))
			if kind == "*":
				var spots := [Vector2i(3, 3), Vector2i(11, 4), Vector2i(6, 10), Vector2i(12, 12), Vector2i(2, 13)]
				var cols := [c("#f05068"), c("#f8e048"), c("#ffffff"), c("#f888c0"), c("#f8e048")]
				for i in spots.size():
					var p: Vector2i = spots[i]
					var col: Color = cols[i]
					img.set_pixel(p.x, p.y - 1, col)
					img.set_pixel(p.x - 1, p.y, col)
					img.set_pixel(p.x + 1, p.y, col)
					img.set_pixel(p.x, p.y + 1, col)
					img.set_pixel(p.x, p.y, c("#f8b030"))
		"=":
			var r := _noise(img, c("#e8d098"), c("#dcc084"), 0.3, 5)
			for i in 9:
				img.set_pixel(r.randi_range(0, 15), r.randi_range(0, 15), c("#bc9c68"))
		"S":
			var r := _noise(img, c("#f4e4a8"), c("#ead494"), 0.25, 7)
			for i in 5:
				img.set_pixel(r.randi_range(0, 15), r.randi_range(0, 15), c("#fff8dc"))
		"~":
			var r := _noise(img, c("#4890e0"), c("#5298e6"), 0.2, 3)
			for i in 4:
				var x := r.randi_range(0, 12)
				var y := r.randi_range(1, 14)
				for k in 3:
					img.set_pixel(x + k, y, c("#a8d0f8"))
		"P":
			_noise(img, c("#d4d0c4"), c("#cac6ba"), 0.2, 9)
			for y in 16:
				for x in 16:
					var sx := x + (4 if y >= 8 else 0)
					if y % 8 == 0 or sx % 8 == 0:
						img.set_pixel(x, y, c("#aca898"))
		"B", "legno":
			for y in 16:
				for x in 16:
					var col := c("#c08850") if (y / 4) % 2 == 0 else c("#b47c46")
					if y % 4 == 3 or (x == (y / 4) * 5 % 16):
						col = c("#8a5a30")
					img.set_pixel(x, y, col)
		"foglie":
			var r := _noise(img, c("#3c9a44"), c("#48ac50"), 0.3, 13)
			for i in 10:
				img.set_pixel(r.randi_range(0, 15), r.randi_range(0, 15), c("#2c7a34"))
			for i in 6:
				img.set_pixel(r.randi_range(0, 15), r.randi_range(0, 15), c("#78d070"))
		"tronco":
			for y in 16:
				for x in 16:
					img.set_pixel(x, y, c("#8a5a30") if x % 4 != 0 else c("#6e4424"))
		"muro":
			_noise(img, c("#ffffff"), c("#f0ece4"), 0.15, 17)
			for y in range(13, 16):
				for x in 16:
					img.set_pixel(x, y, c("#d0c8b8"))
		"tetto":
			for y in 16:
				for x in 16:
					var off := 2 if (y / 4) % 2 == 0 else 0
					var col := c("#ffffff")
					if y % 4 == 3 or (x + off) % 4 == 0:
						col = c("#c4c4c4")
					img.set_pixel(x, y, col)
		"roccia":
			_noise(img, c("#a8a8b0"), c("#9898a0"), 0.3, 21)
		_:
			img.fill(c("#ff00ff"))
	return _done(key, img)


## Ombra rotonda sotto i personaggi.
static func shadow() -> ImageTexture:
	if _cache.has("shadow"):
		return _cache["shadow"]
	var img := Image.create(16, 16, false, Image.FORMAT_RGBA8)
	for y in 16:
		for x in 16:
			var d := Vector2(x - 7.5, y - 7.5).length() / 7.5
			img.set_pixel(x, y, Color(0, 0, 0, 0.35 if d < 1.0 else 0.0))
	return _done("shadow", img)


static func _pattern(key: String, rows: Array, pal: Dictionary) -> ImageTexture:
	if _cache.has(key):
		return _cache[key]
	var h := rows.size()
	var w := str(rows[0]).length()
	var img := Image.create(w, h, false, Image.FORMAT_RGBA8)
	img.fill(Color(0, 0, 0, 0))
	for y in h:
		var row: String = rows[y]
		for x in mini(w, row.length()):
			var ch := row[x]
			if pal.has(ch):
				img.set_pixel(x, y, pal[ch])
	return _done(key, img)


## Icone sopra la testa: cuore, esclamazione, nota, rabbia, puntini, zzz, stella.
static func status_icon(name: String) -> ImageTexture:
	var rows: Array = ICONS.get(name, ICONS["puntini"])
	var pal := {"r": c("#e83848"), "w": c("#ffffff"), "y": c("#f8d030"), "k": c("#303030"), "u": c("#4878e0")}
	return _pattern("icon_" + name, rows, pal)


## Icona di un oggetto, colorata con il suo colore.
static func item_icon(icon: String, col: Color) -> ImageTexture:
	var rows: Array = ITEM_ICONS.get(icon, ITEM_ICONS["gemma"])
	var pal := {
		"a": col, "b": col.darkened(0.35), "c": col.lightened(0.45),
		"k": c("#303030"), "w": c("#ffffff"), "g": c("#48a848"), "n": c("#8a5a30"), "y": c("#f8d030"),
	}
	return _pattern("item_%s_%s" % [icon, col.to_html()], rows, pal)


static func item_icon_for(it: Dictionary) -> ImageTexture:
	return item_icon(str(it.get("icona", "gemma")), Color.html(str(it.get("colore", "#888888"))))
