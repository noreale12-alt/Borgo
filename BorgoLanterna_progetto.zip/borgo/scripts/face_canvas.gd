extends Control
## Tela 32x32 per disegnare sul viso: trucco, nei, cicatrici, tatuaggi, ritocchi a occhi e bocca.

signal changed

const Face = preload("res://scripts/face.gd")
const SIZE := 32

var app: Dictionary = {}
var expr: String = "normale"
var brush: String = "matita"   # matita, gomma, nascondi, contagocce
var color: Color = Color.html("#262030")
var _painting: bool = false
var _last := Vector2i(-1, -1)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	custom_minimum_size = Vector2(448, 448)


func _cell() -> float:
	return minf(size.x, size.y) / SIZE


func _gui_input(event) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		_painting = event.pressed
		_last = Vector2i(-1, -1)
		if event.pressed:
			_paint(event.position)
		accept_event()
	elif event is InputEventMouseMotion and _painting:
		_paint(event.position)
		accept_event()


func _paint(p: Vector2) -> void:
	var c := _cell()
	var x := int(p.x / c)
	var y := int(p.y / c)
	if x < 1 or y < 1 or x > SIZE - 2 or y > SIZE - 2:
		return
	var cell := Vector2i(x, y)
	if cell == _last:
		return
	_last = cell
	if not app.has("pixel") or typeof(app["pixel"]) != TYPE_DICTIONARY:
		app["pixel"] = {}
	var px: Dictionary = app["pixel"]
	var k := "%d,%d" % [x, y]
	match brush:
		"matita":
			px[k] = "#" + color.to_html(false)
		"gomma":
			px.erase(k)
		"nascondi":
			px[k] = "#00000000"
		"contagocce":
			var img := Face.compose(app, expr).get_image()
			var picked := img.get_pixel(x, y)
			if picked.a > 0.0:
				color = picked
			changed.emit()
			return
	queue_redraw()
	changed.emit()


func clear_all() -> void:
	app["pixel"] = {}
	queue_redraw()
	changed.emit()


func _draw() -> void:
	var c := _cell()
	var full := Rect2(Vector2.ZERO, Vector2(SIZE, SIZE) * c)
	draw_rect(full, Color.html(str(app.get("pelle", "#f8d8b8"))))
	draw_texture_rect(Face.compose(app, expr), full, false)
	var grid := Color(0, 0, 0, 0.08)
	for i in range(SIZE + 1):
		draw_line(Vector2(i * c, 0), Vector2(i * c, SIZE * c), grid, 1.0)
		draw_line(Vector2(0, i * c), Vector2(SIZE * c, i * c), grid, 1.0)
	var border := Color(0.2, 0.25, 0.45, 0.25)
	draw_rect(Rect2(0, 0, SIZE * c, c), border)
	draw_rect(Rect2(0, (SIZE - 1) * c, SIZE * c, c), border)
	draw_rect(Rect2(0, 0, c, SIZE * c), border)
	draw_rect(Rect2((SIZE - 1) * c, 0, c, SIZE * c), border)
	draw_rect(full, Color(0.2, 0.25, 0.45), false, 3.0)
