extends CanvasLayer
## Interfaccia: HUD, joystick, dialoghi con scelte, menu, chat IA, profili ed editor dei personaggi.

const Chibi = preload("res://scripts/chibi.gd")
const PixelTex = preload("res://scripts/pixel_tex.gd")
const JoystickScript = preload("res://scripts/joystick.gd")
const TouchButtonScript = preload("res://scripts/touch_button.gd")
const FaceCanvasScript = preload("res://scripts/face_canvas.gd")
const Face = preload("res://scripts/face.gd")

const SKIN := ["#fde3cc", "#f8d8b8", "#f0c8a0", "#e0b088", "#c89068", "#a87048", "#805030", "#5a3820"]
const HAIR := ["#202020", "#503020", "#8a5a30", "#b04830", "#f0d060", "#d8d8e0", "#f080b0", "#4870c8", "#58a858", "#9868c8"]
const CLOTH := ["#e04848", "#f0a0c0", "#f8a040", "#f0d050", "#58a858", "#38a8a8", "#3878d8", "#3048a0", "#9868c8", "#303850", "#f8f0f8", "#4a3a2a"]
const EYES := ["#5a3c8c", "#3a2a20", "#7a4a28", "#2c5aa8", "#3a8a5a", "#a83848", "#c89028", "#282830", "#7090a8"]
const PALETTE := ["#262030", "#5a3a2a", "#8a5a30", "#c83848", "#e86878", "#f8a0a8", "#f8c8c8", "#ffffff", "#f8d030", "#58a858", "#3878d8", "#9868c8", "#a0a0a8", "#d8b090", "#a06850", "#603828"]
const GENDERS := ["ragazzo", "ragazza", "altro"]
const GENDER_LABELS := ["Ragazzo", "Ragazza", "Altro"]
const OUT_BRUSHES := [".", "*", "=", "S", "P", "~", "B", "T", "F", "L", "N", "R"]
const IN_BRUSHES := ["letto", "tavolo", "sedia", "tappeto", "libreria", "pianta", "tv", "lampada", "cucina", "divano"]
const TILE_NAMES := {".": "Erba", "*": "Fiori", "=": "Sentiero", "S": "Sabbia", "P": "Pietra", "~": "Acqua", "B": "Ponte", "T": "Albero", "F": "Recinto", "L": "Lampione", "N": "Panchina", "R": "Roccia"}
const TRAIT_NAMES := {"socievole": "Socievole", "gentile": "Gentile", "romantico": "Romantico", "energico": "Energico", "creativo": "Creativo", "serio": "Serio"}
const REACT_ICON := {"bene": "cuore", "male": "puntini", "neutro": "nota"}

var main = null
var root: Control
var panel_layer: Control
var hud_label: Label
var joystick
var action_btn
var menu_btn: Button
var dialog_panel: PanelContainer
var dialog_name: Label
var dialog_text: Label
var choice_box: VBoxContainer
var toast_box: VBoxContainer
var fade_rect: ColorRect
var editor_bar: PanelContainer = null
var panel: Control = null
var _panel_top: HBoxContainer
var preview: Chibi = null
var _action_label: String = ""
var _dq: Array = []
var _cur: Dictionary = {}
var _typing: bool = false
var _chars: float = 0.0
var _unblock_frame: int = -10
var _chat_id: String = ""
var _chat_msgs: Array = []
var _chat_log: RichTextLabel = null
var _chat_input: LineEdit = null
var _chat_send: Button = null
var _chat_count: int = 0
var _date_score: int = 0
var _ed: Dictionary = {}
var _ed_mode: String = ""
var _ed_first: bool = false
var _news_cb: Callable


func _ready() -> void:
	layer = 10
	root = Control.new()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.theme = _make_theme()
	add_child(root)
	_build_hud()
	_build_dialog()
	panel_layer = Control.new()
	panel_layer.set_anchors_preset(Control.PRESET_FULL_RECT)
	panel_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(panel_layer)
	toast_box = VBoxContainer.new()
	_anchor(toast_box, 0.5, 0.0, 0.5, 0.0, -340.0, 84.0, 340.0, 84.0)
	toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(toast_box)
	fade_rect = ColorRect.new()
	fade_rect.color = Color.BLACK
	fade_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	fade_rect.modulate.a = 0.0
	root.add_child(fade_rect)
	_news_cb = func(t: String) -> void:
		toast(t, 3.5)
	Game.news_added.connect(_news_cb)


func _exit_tree() -> void:
	if Game.news_added.is_connected(_news_cb):
		Game.news_added.disconnect(_news_cb)


# ================================================================ stile

func _sb(bg: Color, border: Color, bw: int = 3, radius: int = 10, margin: int = 12) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(bw)
	s.set_corner_radius_all(radius)
	s.set_content_margin_all(margin)
	return s


func _make_theme() -> Theme:
	var t := Theme.new()
	t.default_font_size = 24
	t.set_stylebox("panel", "PanelContainer", _sb(Color(1, 1, 1, 0.97), Color.html("#3a4a7a"), 4, 14, 16))
	t.set_stylebox("normal", "Button", _sb(Color.html("#f2f5ff"), Color.html("#5a6aa8"), 3, 10, 10))
	t.set_stylebox("hover", "Button", _sb(Color.html("#e6ecff"), Color.html("#5a6aa8"), 3, 10, 10))
	t.set_stylebox("pressed", "Button", _sb(Color.html("#c6d2ff"), Color.html("#2a3a7a"), 4, 10, 10))
	t.set_stylebox("hover_pressed", "Button", _sb(Color.html("#c6d2ff"), Color.html("#2a3a7a"), 4, 10, 10))
	t.set_stylebox("disabled", "Button", _sb(Color.html("#e4e4e4"), Color.html("#a8a8a8"), 3, 10, 10))
	t.set_stylebox("focus", "Button", StyleBoxEmpty.new())
	for k in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "font_hover_pressed_color"]:
		t.set_color(k, "Button", Color.html("#203058"))
	t.set_color("font_disabled_color", "Button", Color.html("#909090"))
	t.set_color("font_color", "Label", Color.html("#283040"))
	t.set_stylebox("normal", "LineEdit", _sb(Color.WHITE, Color.html("#8090c0"), 2, 8, 10))
	t.set_stylebox("focus", "LineEdit", _sb(Color.WHITE, Color.html("#3a4a8a"), 3, 8, 10))
	t.set_color("font_color", "LineEdit", Color.html("#202020"))
	t.set_color("font_placeholder_color", "LineEdit", Color.html("#9098a8"))
	t.set_stylebox("normal", "TextEdit", _sb(Color.WHITE, Color.html("#8090c0"), 2, 8, 10))
	t.set_stylebox("focus", "TextEdit", _sb(Color.WHITE, Color.html("#3a4a8a"), 3, 8, 10))
	t.set_color("font_color", "TextEdit", Color.html("#202020"))
	t.set_color("default_color", "RichTextLabel", Color.html("#283040"))
	t.set_stylebox("background", "ProgressBar", _sb(Color.html("#e0e4f0"), Color.html("#9098b8"), 2, 6, 0))
	t.set_stylebox("fill", "ProgressBar", _sb(Color.html("#60c070"), Color.html("#60c070"), 0, 6, 0))
	t.set_stylebox("scroll", "VScrollBar", _sb(Color(0, 0, 0, 0.06), Color(0, 0, 0, 0), 0, 6, 7))
	t.set_stylebox("grabber", "VScrollBar", _sb(Color.html("#8090c0"), Color.html("#8090c0"), 0, 6, 7))
	t.set_stylebox("grabber_highlight", "VScrollBar", _sb(Color.html("#5a6aa8"), Color.html("#5a6aa8"), 0, 6, 7))
	t.set_stylebox("grabber_pressed", "VScrollBar", _sb(Color.html("#3a4a8a"), Color.html("#3a4a8a"), 0, 6, 7))
	t.set_constant("separation", "VBoxContainer", 10)
	t.set_constant("separation", "HBoxContainer", 10)
	t.set_constant("h_separation", "HFlowContainer", 8)
	t.set_constant("v_separation", "HFlowContainer", 8)
	return t


func _anchor(c: Control, al: float, at: float, ar: float, ab: float, ol: float, ot: float, or_: float, ob: float) -> void:
	c.anchor_left = al
	c.anchor_top = at
	c.anchor_right = ar
	c.anchor_bottom = ab
	c.offset_left = ol
	c.offset_top = ot
	c.offset_right = or_
	c.offset_bottom = ob


func _btn(text: String, cb: Callable, min_w: float = 0.0) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(min_w, 58)
	b.pressed.connect(cb)
	return b


func _btnw(text: String, min_w: float, cb: Callable) -> Button:
	return _btn(text, cb, min_w)


func _lbl(t: String, fs: int = 22, accent: bool = false) -> Label:
	var l := Label.new()
	l.text = t
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.add_theme_font_size_override("font_size", fs)
	if accent:
		l.add_theme_color_override("font_color", Color.html("#3a4a8a"))
	return l


func _icon(it: Dictionary, s: float) -> TextureRect:
	var trait_map := TextureRect.new()
	trait_map.texture = PixelTex.item_icon_for(it)
	trait_map.custom_minimum_size = Vector2(s, s)
	trait_map.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	trait_map.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
	trait_map.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	return trait_map


func _scroll(parent: Control) -> VBoxContainer:
	var sc := ScrollContainer.new()
	sc.size_flags_vertical = Control.SIZE_EXPAND_FILL
	sc.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	parent.add_child(sc)
	var vb := VBoxContainer.new()
	vb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sc.add_child(vb)
	return vb


# ================================================================ HUD

func _build_hud() -> void:
	var hp := PanelContainer.new()
	hp.add_theme_stylebox_override("panel", _sb(Color(1, 1, 1, 0.9), Color.html("#3a4a7a"), 3, 10, 10))
	hp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_anchor(hp, 0, 0, 0, 0, 16, 12, 16, 12)
	hud_label = Label.new()
	hud_label.add_theme_font_size_override("font_size", 22)
	hp.add_child(hud_label)
	root.add_child(hp)
	menu_btn = _btn("Menu", open_menu, 150)
	_anchor(menu_btn, 1, 0, 1, 0, -166, 12, -16, 70)
	root.add_child(menu_btn)
	joystick = JoystickScript.new()
	_anchor(joystick, 0, 1, 0, 1, 24, -324, 324, -24)
	root.add_child(joystick)
	action_btn = TouchButtonScript.new()
	_anchor(action_btn, 1, 1, 1, 1, -220, -240, -44, -64)
	action_btn.tapped.connect(func() -> void:
		main.do_action()
	)
	root.add_child(action_btn)


func set_action_label(t: String) -> void:
	if t == _action_label:
		return
	_action_label = t
	action_btn.set_text(t if t != "" else "A")


func joystick_vector() -> Vector2:
	if joystick.visible:
		return joystick.output
	return Vector2.ZERO


func is_blocking() -> bool:
	return dialog_panel.visible or panel != null or fade_rect.modulate.a > 0.01 or Engine.get_process_frames() - _unblock_frame < 3


func _mark_unblock() -> void:
	_unblock_frame = Engine.get_process_frames()


func _process(delta: float) -> void:
	if _typing:
		_chars += delta * 55.0
		dialog_text.visible_characters = int(_chars)
		if _chars >= dialog_text.text.length():
			_finish_typing()
	var can_move: bool = not is_blocking() and not main.input_locked
	joystick.visible = can_move
	menu_btn.visible = can_move
	action_btn.visible = can_move and _action_label != ""
	var extra := ""
	if Game.partner != "" and Game.npcs.has(Game.partner):
		extra = "  ·  ♥ " + Game.name_of(Game.partner)
	hud_label.text = "Giorno %d  ·  %s  ·  %s%s" % [Game.day, Game.clock_text(), "Pioggia" if Game.weather == "pioggia" else "Sole", extra]
	if preview != null and is_instance_valid(preview):
		preview._target_yaw += delta * 0.9


func toast(text: String, secs: float = 2.5) -> void:
	var pc := PanelContainer.new()
	pc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	pc.add_theme_stylebox_override("panel", _sb(Color(0.13, 0.16, 0.28, 0.9), Color(1, 1, 1, 0.6), 2, 10, 10))
	var l := Label.new()
	l.text = text
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	l.add_theme_color_override("font_color", Color.WHITE)
	l.add_theme_font_size_override("font_size", 20)
	pc.add_child(l)
	toast_box.add_child(pc)
	while toast_box.get_child_count() > 3:
		var old := toast_box.get_child(0)
		toast_box.remove_child(old)
		old.queue_free()
	get_tree().create_timer(secs).timeout.connect(func() -> void:
		if is_instance_valid(pc):
			pc.queue_free()
	)


func fade(mid: Callable) -> void:
	var tw := create_tween()
	tw.tween_property(fade_rect, "modulate:a", 1.0, 0.35)
	tw.tween_callback(mid)
	tw.tween_interval(0.2)
	tw.tween_property(fade_rect, "modulate:a", 0.0, 0.35)


# ================================================================ dialoghi

func _build_dialog() -> void:
	dialog_panel = PanelContainer.new()
	_anchor(dialog_panel, 0, 1, 1, 1, 110, -226, -110, -16)
	dialog_panel.add_theme_stylebox_override("panel", _sb(Color(1, 1, 1, 0.98), Color.html("#d04848"), 5, 14, 18))
	dialog_panel.mouse_filter = Control.MOUSE_FILTER_STOP
	dialog_panel.gui_input.connect(_on_dialog_input)
	var vb := VBoxContainer.new()
	vb.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dialog_panel.add_child(vb)
	dialog_name = Label.new()
	dialog_name.add_theme_color_override("font_color", Color.html("#c03838"))
	dialog_name.add_theme_font_size_override("font_size", 24)
	vb.add_child(dialog_name)
	dialog_text = Label.new()
	dialog_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	dialog_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	dialog_text.add_theme_font_size_override("font_size", 27)
	vb.add_child(dialog_text)
	root.add_child(dialog_panel)
	dialog_panel.visible = false
	choice_box = VBoxContainer.new()
	_anchor(choice_box, 1, 1, 1, 1, -560, -236, -120, -236)
	choice_box.grow_vertical = Control.GROW_DIRECTION_BEGIN
	root.add_child(choice_box)


func _on_dialog_input(event) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		_advance()


func _unhandled_input(event) -> void:
	if dialog_panel.visible and event.is_action_pressed("azione"):
		_advance()
		get_viewport().set_input_as_handled()


func _push(entries: Array) -> void:
	_dq.append_array(entries)
	if not dialog_panel.visible:
		_next()


func _next() -> void:
	_clear_choices()
	if _dq.is_empty():
		dialog_panel.visible = false
		_cur = {}
		_mark_unblock()
		return
	_cur = _dq.pop_front()
	dialog_panel.visible = true
	dialog_name.text = str(_cur.get("chi", ""))
	dialog_name.visible = dialog_name.text != ""
	dialog_text.text = str(_cur.get("testo", ""))
	dialog_text.visible_characters = 0
	_chars = 0.0
	_typing = true


func _finish_typing() -> void:
	_typing = false
	dialog_text.visible_characters = -1
	if _cur.has("scelte"):
		_show_choices()


func _advance() -> void:
	if _cur.is_empty():
		return
	if _typing:
		_finish_typing()
		return
	if _cur.has("scelte"):
		return
	var e := _cur
	_cur = {}
	if e.has("cb"):
		var cb: Callable = e["cb"]
		cb.call(-1)
	_next()


func _show_choices() -> void:
	_clear_choices()
	var arr: Array = _cur["scelte"]
	for i in arr.size():
		var idx := i
		var b := _btnw(str(arr[i]), 420, func() -> void:
			_choose(idx)
		)
		b.add_theme_font_size_override("font_size", 22)
		choice_box.add_child(b)


func _choose(i: int) -> void:
	var e := _cur
	_clear_choices()
	_cur = {}
	if e.has("cb"):
		var cb: Callable = e["cb"]
		cb.call(i)
	_next()


func _clear_choices() -> void:
	for c in choice_box.get_children():
		choice_box.remove_child(c)
		c.queue_free()


## Mostra una o più battute. "then" viene chiamata alla fine.
func say(chi: String, lines: Array, then: Callable = Callable()) -> void:
	var entries: Array = []
	for l in lines:
		if str(l) != "":
			entries.append({"chi": chi, "testo": str(l)})
	if entries.is_empty():
		if then.is_valid():
			then.call()
		return
	if then.is_valid():
		entries[entries.size() - 1]["cb"] = func(_i: int) -> void:
			then.call()
	_push(entries)


func _speaker(chi: String, npc_id: String) -> String:
	match chi:
		"narratore":
			return ""
		"npc":
			return Game.name_of(npc_id)
		"player":
			return Game.name_of("player")
	return Game.name_of(chi)


## Esegue un nodo della trama (data/story.json) con scelte ed effetti.
func run_node(node_id: String, npc_id: String, done: Callable) -> void:
	var nodes: Dictionary = Game.story.get("nodi", {})
	if not nodes.has(node_id):
		if done.is_valid():
			done.call()
		return
	var nd: Dictionary = nodes[node_id]
	Game.apply_effects(nd.get("effetti", []), npc_id)
	var chi := _speaker(str(nd.get("chi", "npc")), npc_id)
	var testo := Game.fmt(str(nd.get("testo", "")), npc_id)
	if nd.get("scegli_npc", false):
		var ids: Array = Game.npc_order.duplicate()
		var names: Array = []
		for x in ids:
			names.append(Game.name_of(x))
		var cb_npc := func(i: int) -> void:
			var chosen: String = ids[i]
			Game.apply_effects(nd.get("effetti_scelta", []), chosen)
			if main.npc_nodes.has(chosen):
				main.npc_nodes[chosen].show_icon("cuore", 4.0)
			_after_node(nd, npc_id, done)
		_push([{"chi": chi, "testo": testo, "scelte": names, "cb": cb_npc}])
		return
	var sc: Array = nd.get("scelte", [])
	if sc.size() > 0:
		var labels: Array = []
		for s in sc:
			labels.append(Game.fmt(str(s["testo"]), npc_id))
		var cb := func(i: int) -> void:
			var s: Dictionary = sc[i]
			Game.apply_effects(s.get("effetti", []), npc_id)
			var nx := str(s.get("next", ""))
			if nx != "":
				run_node(nx, npc_id, done)
			elif done.is_valid():
				done.call()
		_push([{"chi": chi, "testo": testo, "scelte": labels, "cb": cb}])
	else:
		var cb2 := func(_i: int) -> void:
			_after_node(nd, npc_id, done)
		_push([{"chi": chi, "testo": testo, "cb": cb2}])


func _after_node(nd: Dictionary, npc_id: String, done: Callable) -> void:
	for cond in nd.get("next_se", []):
		if Game.flags.get(str(cond["flag"]), false):
			run_node(str(cond["next"]), npc_id, done)
			return
	var nx := str(nd.get("next", ""))
	if nx != "":
		run_node(nx, npc_id, done)
	elif done.is_valid():
		done.call()


# ================================================================ pannelli

func _open_panel(title: String, size_mode: String = "big") -> VBoxContainer:
	close_panel()
	var pc := PanelContainer.new()
	match size_mode:
		"big":
			_anchor(pc, 0.06, 0.04, 0.94, 0.96, 0, 0, 0, 0)
		"small":
			_anchor(pc, 0.5, 0.5, 0.5, 0.5, -330, -300, 330, 300)
		_:
			_anchor(pc, 0.5, 0.5, 0.5, 0.5, -300, -150, 300, 150)
	panel_layer.add_child(pc)
	panel = pc
	var vb := VBoxContainer.new()
	pc.add_child(vb)
	_panel_top = HBoxContainer.new()
	var tl := Label.new()
	tl.text = title
	tl.add_theme_font_size_override("font_size", 30)
	tl.add_theme_color_override("font_color", Color.html("#2a3a7a"))
	tl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	tl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_panel_top.add_child(tl)
	vb.add_child(_panel_top)
	return vb


func close_panel() -> void:
	if panel != null and is_instance_valid(panel):
		panel_layer.remove_child(panel)
		panel.queue_free()
	panel = null
	preview = null
	_mark_unblock()


func _add_close() -> void:
	_panel_top.add_child(_btn("Chiudi", close_panel, 150))


func confirm(text: String, yes: Callable) -> void:
	var vb := _open_panel("Conferma", "tiny")
	vb.add_child(_lbl(text, 24))
	var hb := HBoxContainer.new()
	hb.alignment = BoxContainer.ALIGNMENT_CENTER
	hb.add_child(_btnw("Sì", 180, func() -> void:
		close_panel()
		yes.call()
	))
	hb.add_child(_btn("No", close_panel, 180))
	vb.add_child(hb)


func open_menu() -> void:
	if main.input_locked:
		return
	var vb := _open_panel("Menu", "small")
	_add_close()
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 12)
	grid.add_theme_constant_override("v_separation", 12)
	vb.add_child(grid)
	var ed_label := "Arreda casa" if main.player_zone != "out" else "Modifica mappa"
	if main.editor_mode:
		ed_label = "Chiudi editor"
	var entries := [
		["Abitanti", open_people], ["Zaino", open_bag],
		["Notizie", open_news], [ed_label, toggle_editor],
		["Il tuo personaggio", _open_my_char], ["Intelligenza artificiale", open_ai_settings],
		["Salva partita", _save_now], ["Nuova partita", _ask_new_game],
	]
	for e in entries:
		var b := _btn(str(e[0]), e[1], 280)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		grid.add_child(b)


func _open_my_char() -> void:
	open_editor("player", false)


func _save_now() -> void:
	Game.save_game()
	close_panel()
	toast("Partita salvata!")


func _ask_new_game() -> void:
	confirm("Vuoi davvero ricominciare da capo? La partita attuale verrà cancellata.", func() -> void:
		Game.new_game()
		Game.save_game()
		get_tree().reload_current_scene()
	)


func open_news() -> void:
	var vb := _open_panel("Notizie del villaggio")
	_add_close()
	var list := _scroll(vb)
	if Game.news.is_empty():
		list.add_child(_lbl("Ancora nessuna notizia."))
	for i in range(Game.news.size() - 1, -1, -1):
		var n: Dictionary = Game.news[i]
		list.add_child(_lbl("Giorno %d  —  %s" % [int(n.get("giorno", 0)), str(n.get("testo", ""))], 21))


func open_bag() -> void:
	var vb := _open_panel("Zaino")
	_add_close()
	var list := _scroll(vb)
	if Game.inventory.is_empty():
		list.add_child(_lbl("Lo zaino è vuoto. Cerca gli oggetti luccicanti in giro per il villaggio!"))
	for k in Game.inventory:
		var it: Dictionary = Game.items.get(k, {})
		var hb := HBoxContainer.new()
		hb.add_child(_icon(it, 60))
		var l := _lbl("%s  x%d\n%s" % [str(it.get("nome", k)), int(Game.inventory[k]), str(it.get("desc", ""))], 21)
		l.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		hb.add_child(l)
		list.add_child(hb)


func open_people() -> void:
	var vb := _open_panel("Abitanti di Borgo Lanterna")
	_add_close()
	var list := _scroll(vb)
	for id in Game.npc_order:
		var r := Game.get_rel(id)
		var love := ""
		if float(r["amore"]) >= 1.0:
			love = "  ·  ♥ %d" % int(r["amore"])
		var sid: String = id
		var b := _btnw("%s  —  %s  ·  amicizia %d%s" % [Game.name_of(sid), Game.status_label(sid), int(r["amicizia"]), love], 280, func() -> void:
			open_profile(sid, open_people)
		)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		list.add_child(b)
	var free_h := Game.free_house()
	var add := _btn("+ Nuovo abitante" + ("" if free_h != "" else " (nessuna casa libera)"), func() -> void:
		open_editor("nuovo", false)
	)
	add.disabled = free_h == ""
	list.add_child(add)


func _bar(parent: Control, title: String, v: float, mn: float, mx: float, col: Color) -> void:
	var hb := HBoxContainer.new()
	var l := _lbl(title, 20)
	l.custom_minimum_size.x = 150
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	hb.add_child(l)
	var pb := ProgressBar.new()
	pb.min_value = mn
	pb.max_value = mx
	pb.value = v
	pb.show_percentage = false
	pb.custom_minimum_size = Vector2(0, 22)
	pb.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	pb.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	pb.add_theme_stylebox_override("fill", _sb(col, col, 0, 6, 0))
	hb.add_child(pb)
	var vl := _lbl(str(int(v)), 20)
	vl.custom_minimum_size.x = 56
	vl.autowrap_mode = TextServer.AUTOWRAP_OFF
	hb.add_child(vl)
	parent.add_child(hb)


func _make_preview(app: Dictionary, sz: Vector2) -> Control:
	var svc := SubViewportContainer.new()
	svc.stretch = true
	svc.custom_minimum_size = sz
	svc.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	var sv := SubViewport.new()
	sv.own_world_3d = true
	sv.transparent_bg = true
	svc.add_child(sv)
	var we := WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_CLEAR_COLOR
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color.WHITE
	e.ambient_light_energy = 0.65
	we.environment = e
	sv.add_child(we)
	var l := DirectionalLight3D.new()
	l.rotation_degrees = Vector3(-35, 25, 0)
	sv.add_child(l)
	var cam3 := Camera3D.new()
	cam3.fov = 30.0
	cam3.position = Vector3(0, 0.62, 2.7)
	cam3.rotation_degrees = Vector3(-4, 0, 0)
	sv.add_child(cam3)
	cam3.current = true
	preview = Chibi.new()
	sv.add_child(preview)
	preview.build(app)
	preview.scale = Vector3(1.2, 1.2, 1.2)
	return svc


func open_profile(id: String, back: Callable) -> void:
	if not Game.npcs.has(id):
		open_people()
		return
	var d: Dictionary = Game.npcs[id]
	var r := Game.get_rel(id)
	var vb := _open_panel(Game.name_of(id))
	_panel_top.add_child(_btn("Indietro", back, 160))
	var hb := HBoxContainer.new()
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)
	var left := VBoxContainer.new()
	left.add_child(_make_preview(d.get("aspetto", {}), Vector2(280, 360)))
	left.add_child(_btn("Modifica", func() -> void:
		open_editor(id, false)
	))
	left.add_child(_btnw("Fai traslocare", 280, func() -> void:
		confirm("%s lascerà Borgo Lanterna per sempre. Sei sicur%s?" % [Game.name_of(id), Game.g("player")], func() -> void:
			_remove_npc(id)
		)
	))
	hb.add_child(left)
	var body := _scroll(hb)
	var job := str(d.get("lavoro", ""))
	var job_txt := (job.left(1).to_upper() + job.substr(1)) if job != "" else "Abitante"
	body.add_child(_lbl("%s  ·  %s" % [job_txt, Game.status_label(id)], 22, true))
	_bar(body, "Amicizia", float(r["amicizia"]), -100, 100, Color.html("#58b868"))
	_bar(body, "Amore", float(r["amore"]), 0, 100, Color.html("#f06890"))
	_bar(body, "Umore", float(Game.moods.get(id, 60)), 0, 100, Color.html("#f0b840"))
	if str(Game.status.get(id, "")) == "malato":
		body.add_child(_lbl("Oggi è malat%s: un tè caldo l'aiuterebbe." % Game.g(id), 20))
	body.add_child(_lbl("Carattere", 22, true))
	for t in Game.traits():
		_bar(body, TRAIT_NAMES.get(t, t), Game.trait_val(id, t), 0, 100, Color.html("#7088d8"))
	body.add_child(_lbl("Ama: %s" % ", ".join(d.get("ama", [])), 20))
	body.add_child(_lbl("Non sopporta: %s" % ", ".join(d.get("odia", [])), 20))
	if str(d.get("storia", "")) != "":
		body.add_child(_lbl(str(d["storia"]), 20))
	body.add_child(_lbl("Rapporti con gli altri", 22, true))
	var others: Array = []
	for o in Game.npc_order:
		if o != id:
			others.append([o, float(Game.get_pair(id, o)["amicizia"]), Game.get_pair(id, o).get("coppia", false)])
	others.sort_custom(func(a, b): return a[1] > b[1])
	for o in others:
		var tag := "  ♥ fidanzati" if o[2] else ""
		body.add_child(_lbl("%s: amicizia %d%s" % [Game.name_of(o[0]), int(o[1]), tag], 20))
	var mem: Array = Game.memories.get(id, [])
	if mem.size() > 0:
		body.add_child(_lbl("Ricordi", 22, true))
		for i in range(mem.size() - 1, maxi(-1, mem.size() - 7), -1):
			body.add_child(_lbl("• " + str(mem[i]), 19))


func _remove_npc(id: String) -> void:
	if main.talk_target != null and main.talk_target.id == id:
		main.end_talk()
	main.despawn_npc(id)
	Game.remove_npc(id)
	main.refresh_house_labels()
	Game.save_game()
	open_people()


# ================================================================ editor mappa

func toggle_editor() -> void:
	close_panel()
	main.set_editor(not main.editor_mode)
	refresh_editor_bar()
	if main.editor_mode:
		toast("Editor attivo: scegli un elemento in alto e tocca il terreno.")


func refresh_editor_bar() -> void:
	if editor_bar != null and is_instance_valid(editor_bar):
		editor_bar.queue_free()
	editor_bar = null
	if not main.editor_mode:
		return
	var inside: bool = main.player_zone != "out"
	if inside and not IN_BRUSHES.has(main.editor_brush):
		main.editor_brush = "letto"
	if not inside and not OUT_BRUSHES.has(main.editor_brush):
		main.editor_brush = "."
	editor_bar = PanelContainer.new()
	_anchor(editor_bar, 0.2, 0, 0.8, 0, 0, 8, 0, 8)
	var vb := VBoxContainer.new()
	editor_bar.add_child(vb)
	var info := "Arreda: tocca il pavimento per mettere un mobile, toccane uno per toglierlo." if inside else "Modifica mappa: scegli un elemento e tocca il terreno."
	vb.add_child(_lbl(info, 18))
	var flow := HFlowContainer.new()
	vb.add_child(flow)
	var grp := ButtonGroup.new()
	var list: Array = IN_BRUSHES if inside else OUT_BRUSHES
	for b in list:
		var key: String = b
		var bt := Button.new()
		bt.text = key.capitalize() if inside else str(TILE_NAMES.get(key, key))
		bt.toggle_mode = true
		bt.button_group = grp
		bt.button_pressed = key == main.editor_brush
		bt.custom_minimum_size = Vector2(0, 46)
		bt.add_theme_font_size_override("font_size", 18)
		bt.pressed.connect(func() -> void:
			main.editor_brush = key
		)
		flow.add_child(bt)
	var fine := _btn("Fine", toggle_editor)
	fine.custom_minimum_size = Vector2(0, 46)
	flow.add_child(fine)
	root.add_child(editor_bar)
	root.move_child(editor_bar, panel_layer.get_index())


# ================================================================ abitanti: interazioni

func open_npc(id: String) -> void:
	var n = main.npc_nodes.get(id)
	if n == null:
		main.end_talk()
		return
	if n.is_sleeping():
		say(Game.name_of(id), [Game.fmt(Game._pick(Game.talk.get("dorme", [])), id)], Callable(main, "end_talk"))
		return
	var st := Game.story_for(id)
	if st != "":
		run_node(st, id, func() -> void:
			_npc_menu(id)
		)
		return
	if not Game.get_rel(id)["conosciuto"]:
		say(Game.name_of(id), Game.talk_lines(id), func() -> void:
			_npc_menu(id)
		)
		return
	_npc_menu(id)


func _npc_menu(id: String) -> void:
	if not Game.npcs.has(id):
		close_panel()
		main.end_talk()
		return
	close_panel()
	var pc := PanelContainer.new()
	_anchor(pc, 1, 0.5, 1, 0.5, -380, -320, -24, 320)
	panel_layer.add_child(pc)
	panel = pc
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 8)
	pc.add_child(vb)
	var r := Game.get_rel(id)
	vb.add_child(_lbl(Game.name_of(id), 28, true))
	vb.add_child(_lbl("%s  ·  amicizia %d  ·  ♥ %d" % [Game.status_label(id), int(r["amicizia"]), int(r["amore"])], 18))
	vb.add_child(_btnw("Parla", 150, func() -> void:
		_do_talk(id)
	))
	vb.add_child(_btn("Chiacchiera libera", func() -> void:
		open_chat(id)
	))
	vb.add_child(_btn("Fai un regalo", func() -> void:
		_gift_menu(id)
	))
	vb.add_child(_btn("Appuntamento", func() -> void:
		_date_menu(id)
	))
	if Game.partner != id and float(r["amicizia"]) >= 30.0:
		vb.add_child(_btn("Dichiarati ♥", func() -> void:
			_confess(id)
		))
	vb.add_child(_btn("Profilo", func() -> void:
		open_profile(id, func() -> void:
			_npc_menu(id)
		)
	))
	vb.add_child(_btn("Ciao!", _end_npc))


func _end_npc() -> void:
	close_panel()
	main.end_talk()


func _npc_icon(id: String, kind: String) -> void:
	var n = main.npc_nodes.get(id)
	if n != null:
		n.show_icon(kind, 2.5)


func _do_talk(id: String) -> void:
	close_panel()
	var nm := Game.name_of(id)
	var lines := Game.talk_lines(id)
	var r := Game.get_rel(id)
	var q := {}
	if not r["domanda_oggi"] and randf() < 0.55 and str(Game.status.get(id, "")) != "malato":
		q = Game.random_question()
	if q.is_empty():
		say(nm, lines, func() -> void:
			_npc_menu(id)
		)
		return
	var entries: Array = []
	for l in lines:
		entries.append({"chi": nm, "testo": str(l)})
	var answers: Array = q["risposte"]
	var labels: Array = []
	for a in answers:
		labels.append(str(a["testo"]))
	var cb := func(i: int) -> void:
		var res := Game.eval_answer(id, answers[i])
		_npc_icon(id, REACT_ICON["bene" if res > 0 else ("male" if res < 0 else "neutro")])
		say(nm, [Game.answer_reaction(id, answers[i])], func() -> void:
			_npc_menu(id)
		)
	entries.append({"chi": nm, "testo": str(q["domanda"]), "scelte": labels, "cb": cb})
	_push(entries)


func _gift_menu(id: String) -> void:
	if Game.inventory.is_empty():
		toast("Lo zaino è vuoto! Raccogli qualcosa in giro.")
		return
	var vb := _open_panel("Cosa regali a %s?" % Game.name_of(id), "small")
	_panel_top.add_child(_btn("Indietro", func() -> void:
		_npc_menu(id)
	))
	var list := _scroll(vb)
	for k in Game.inventory:
		var it: Dictionary = Game.items.get(k, {})
		var item_id: String = k
		var hb := HBoxContainer.new()
		hb.add_child(_icon(it, 52))
		var b := _btnw("%s  x%d" % [str(it.get("nome", k)), int(Game.inventory[k])], 150, func() -> void:
			_give(id, item_id)
		)
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		hb.add_child(b)
		list.add_child(hb)


func _give(id: String, item_id: String) -> void:
	close_panel()
	var before := float(Game.get_rel(id)["amicizia"])
	var txt := Game.give_gift(id, item_id)
	var after := float(Game.get_rel(id)["amicizia"])
	_npc_icon(id, "cuore" if after - before >= 8.0 else ("rabbia" if after < before else "nota"))
	say(Game.name_of(id), [txt], func() -> void:
		_npc_menu(id)
	)


func _confess(id: String) -> void:
	close_panel()
	var txt := Game.confess_to(id)
	_npc_icon(id, "cuore" if Game.partner == id else "puntini")
	var back := func(_i: int) -> void:
		_npc_menu(id)
	var entries: Array = [
		{"chi": Game.name_of("player"), "testo": Game.fmt("Ehm... {npc}, devo dirti una cosa. Mi piaci. Vuoi stare con me?", id)},
		{"chi": Game.name_of(id), "testo": txt, "cb": back},
	]
	_push(entries)


func _date_menu(id: String) -> void:
	var reason := Game.can_date(id)
	if reason != "":
		say("", [reason], func() -> void:
			_npc_menu(id)
		)
		close_panel()
		return
	var vb := _open_panel("Dove porti %s?" % Game.name_of(id), "small")
	_panel_top.add_child(_btn("Indietro", func() -> void:
		_npc_menu(id)
	))
	var places: Array = Game.talk.get("appuntamenti", {}).get("luoghi", [])
	for p in places:
		var pl: Dictionary = p
		vb.add_child(_btnw(str(pl["nome"]), 200, func() -> void:
			_start_date(id, pl)
		))


func _start_date(id: String, place: Dictionary) -> void:
	close_panel()
	_date_score = 0
	var nm := Game.name_of(id)
	var ap: Dictionary = Game.talk.get("appuntamenti", {})
	fade(func() -> void:
		main.start_date(id, place)
	)
	get_tree().create_timer(0.8).timeout.connect(func() -> void:
		say(nm, [Game.fmt(Game._pick(ap.get("inizio", [])), id)], func() -> void:
			_date_q(id, place, 0)
		)
	)


func _date_q(id: String, place: Dictionary, k: int) -> void:
	var nm := Game.name_of(id)
	if k >= 3:
		var txt := Game.finish_date(id, _date_score, str(place["nome"]))
		_npc_icon(id, "cuore" if _date_score >= 2 else ("nota" if _date_score >= 0 else "puntini"))
		say(nm, [txt], _end_npc)
		return
	var q := Game.random_question()
	var answers: Array = q.get("risposte", [])
	var labels: Array = []
	for a in answers:
		labels.append(str(a["testo"]))
	var cb := func(i: int) -> void:
		var res := Game.eval_answer(id, answers[i])
		_date_score += res
		var key := "bene" if res > 0 else ("male" if res < 0 else "neutro")
		_npc_icon(id, REACT_ICON[key])
		var rr: Dictionary = Game.talk.get("reazioni_domanda", {})
		say(nm, [Game.fmt(Game._pick(rr.get(key, [])), id)], func() -> void:
			_date_q(id, place, k + 1)
		)
	_push([{"chi": nm, "testo": str(q.get("domanda", "...")), "scelte": labels, "cb": cb}])


# ================================================================ chat libera (IA)

func open_chat(id: String) -> void:
	_chat_id = id
	_chat_msgs = []
	_chat_count = 0
	var vb := _open_panel("Chiacchiera con " + Game.name_of(id))
	_panel_top.add_child(_btn("Fine", _close_chat, 150))
	var hb := HBoxContainer.new()
	_chat_input = LineEdit.new()
	_chat_input.placeholder_text = "Scrivi qualcosa a %s..." % Game.name_of(id)
	_chat_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_chat_input.custom_minimum_size.y = 58
	_chat_input.max_length = 300
	_chat_input.text_submitted.connect(func(_t: String) -> void:
		_send_chat()
	)
	hb.add_child(_chat_input)
	_chat_send = _btn("Invia", _send_chat, 140)
	hb.add_child(_chat_send)
	vb.add_child(hb)
	if not Ai.is_configured():
		vb.add_child(_lbl("IA non attiva: le risposte saranno semplici. Attivala gratis da Menu > Intelligenza artificiale.", 18))
	_chat_log = RichTextLabel.new()
	_chat_log.bbcode_enabled = true
	_chat_log.scroll_following = true
	_chat_log.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_chat_log.add_theme_font_size_override("normal_font_size", 23)
	_chat_log.add_theme_font_size_override("bold_font_size", 23)
	vb.add_child(_chat_log)
	var greet: Array = Game.talk.get("saluti", {}).get("amico" if float(Game.get_rel(id)["amicizia"]) >= 30.0 else "conoscente", [])
	_chat_line(Game.name_of(id), Game.fmt(Game._pick(greet), id))


func _esc(t: String) -> String:
	return t.replace("[", "[lb]")


func _chat_line(who: String, text: String, is_player: bool = false, system: bool = false) -> void:
	if _chat_log == null or not is_instance_valid(_chat_log):
		return
	var col := "#3a6ad0" if is_player else ("#909090" if system else "#c03838")
	var body := _esc(text)
	var re_i := RegEx.new()
	re_i.compile("\\*([^*]+)\\*")
	body = re_i.sub(body, "[i][color=#7a7a90]$1[/color][/i]", true)
	_chat_log.append_text("[color=%s][b]%s:[/b][/color] %s\n\n" % [col, _esc(who), body])


func _send_chat() -> void:
	if _chat_input == null or not is_instance_valid(_chat_input):
		return
	var t := _chat_input.text.strip_edges()
	if t == "" or Ai.busy:
		return
	_chat_input.text = ""
	_chat_line(Game.name_of("player"), t, true)
	_chat_msgs.append({"role": "user", "content": t})
	_chat_count += 1
	var id := _chat_id
	_chat_send.disabled = true
	_chat_send.text = "..."
	if Ai.is_configured():
		var msgs: Array = [{"role": "system", "content": Game.build_prompt(id, main.situation_for(id))}]
		msgs.append_array(_chat_msgs.slice(maxi(0, _chat_msgs.size() - 12)))
		Ai.ask(msgs, func(ok: bool, txt: String) -> void:
			_on_chat_reply(id, ok, txt, false)
		)
	else:
		get_tree().create_timer(0.6).timeout.connect(func() -> void:
			_on_chat_reply(id, true, Game.offline_reply(id, t), true)
		)


func _on_chat_reply(id: String, ok: bool, txt: String, offline: bool) -> void:
	if _chat_id != id or _chat_log == null or not is_instance_valid(_chat_log):
		return
	if _chat_send != null and is_instance_valid(_chat_send):
		_chat_send.disabled = false
		_chat_send.text = "Invia"
	if not ok:
		_chat_line("Sistema", txt, false, true)
		_chat_msgs.pop_back()
		return
	var re := RegEx.new()
	re.compile("\\[\\s*UMORE\\s*:\\s*([+-]?\\d+)\\s*\\]")
	var m := re.search(txt)
	var delta := 0
	if m != null:
		delta = clampi(m.get_string(1).to_int(), -3, 3)
	txt = re.sub(txt, "", true)
	var re_e := RegEx.new()
	re_e.compile("\\[\\s*ESPRESSIONE\\s*:\\s*([a-zA-Z]+)\\s*\\]")
	var me := re_e.search(txt)
	var npc_node = main.npc_nodes.get(id)
	if me != null and npc_node != null:
		var ex := me.get_string(1).to_lower()
		if ex in ["felice", "triste", "arrabbiato", "sorpreso", "normale"]:
			if ex == "normale":
				npc_node.clear_expression()
			else:
				npc_node.show_expression(ex, 8.0)
	txt = re_e.sub(txt, "", true)
	var re_any := RegEx.new()
	re_any.compile("\\[[A-Z]+\\s*:[^\\]]*\\]")
	txt = re_any.sub(txt, "", true).strip_edges()
	if txt == "":
		txt = "..."
	_chat_msgs.append({"role": "assistant", "content": txt})
	_chat_line(Game.name_of(id), txt)
	var r := Game.get_rel(id)
	if not offline and int(r["chat_oggi"]) < 10:
		r["chat_oggi"] = int(r["chat_oggi"]) + 1
		Game.change_rel(id, float(delta), maxf(0.0, float(delta) * 0.5))
		Game.moods[id] = clampf(float(Game.moods.get(id, 60)) + delta * 2.0, 0.0, 100.0)
	if delta >= 2:
		_npc_icon(id, "cuore")
	elif delta <= -2:
		_npc_icon(id, "rabbia")


func _close_chat() -> void:
	var id := _chat_id
	if _chat_count > 0:
		var last := ""
		for msg in _chat_msgs:
			if str(msg["role"]) == "user":
				last = str(msg["content"])
		Game.add_memory(id, "Giorno %d: ho chiacchierato con {player}, che mi ha detto: \"%s\"" % [Game.day, last.left(70)])
	_chat_id = ""
	_chat_log = null
	_chat_input = null
	_chat_send = null
	_npc_menu(id)


# ================================================================ impostazioni IA

func open_ai_settings() -> void:
	var vb := _open_panel("Intelligenza artificiale (gratis)")
	_add_close()
	var body := _scroll(vb)
	body.add_child(_lbl("Per parlare liberamente con gli abitanti serve una chiave gratuita di un servizio IA online. Consigliato: Google Gemini (gratis, non serve la carta di credito). La chiave resta salvata solo sul tuo telefono.", 20))
	body.add_child(_lbl("1. Scegli il servizio  2. Tocca \"Ottieni chiave\" e accedi  3. Crea la chiave, copiala e incollala qui sotto.", 20, true))
	var ids: Array = Ai.provider_ids()
	var cur := str(Game.ai.get("provider", "gemini"))
	var opt := OptionButton.new()
	opt.custom_minimum_size.y = 58
	for i in ids.size():
		opt.add_item(str(Ai.provider_info(ids[i])["nome"]), i)
		if ids[i] == cur:
			opt.select(i)
	body.add_child(opt)
	var get_key := _btn("Ottieni chiave (si apre il browser)", func() -> void:
		OS.shell_open(str(Ai.provider_info(ids[opt.selected])["sito"]))
	)
	body.add_child(get_key)
	body.add_child(_lbl("Chiave API", 20, true))
	var key_edit := LineEdit.new()
	key_edit.secret = true
	key_edit.text = str(Game.ai.get("key", ""))
	key_edit.placeholder_text = "Incolla qui la chiave"
	key_edit.custom_minimum_size.y = 58
	body.add_child(key_edit)
	body.add_child(_lbl("Modello (lascia vuoto per quello consigliato)", 20, true))
	var model_edit := LineEdit.new()
	model_edit.text = str(Game.ai.get("model", ""))
	model_edit.placeholder_text = str(Ai.provider_info(ids[opt.selected])["model"])
	model_edit.custom_minimum_size.y = 58
	body.add_child(model_edit)
	opt.item_selected.connect(func(i: int) -> void:
		model_edit.placeholder_text = str(Ai.provider_info(ids[i])["model"])
	)
	var status := _lbl("", 20)
	var apply := func() -> void:
		Game.ai = {"provider": str(ids[opt.selected]), "key": key_edit.text.strip_edges(), "model": model_edit.text.strip_edges()}
		Game.save_game()
	var hb := HBoxContainer.new()
	hb.add_child(_btn("Salva", func() -> void:
		apply.call()
		status.text = "Impostazioni salvate."
	))
	hb.add_child(_btnw("Prova connessione", 300, func() -> void:
		apply.call()
		status.text = "Provo a contattare il servizio..."
		Ai.ask([{"role": "user", "content": "Rispondi solo con: Ciao da Borgo Lanterna!"}], func(ok: bool, txt: String) -> void:
			if is_instance_valid(status):
				status.text = ("Funziona! Risposta: " + txt.left(80)) if ok else txt
		)
	))
	body.add_child(hb)
	body.add_child(status)
	body.add_child(_lbl("Nota: i servizi gratuiti hanno un limite di messaggi al giorno. Se lo raggiungi, gli abitanti risponderanno di nuovo il giorno dopo.", 18))


# ================================================================ editor personaggi

func _random_npc() -> Dictionary:
	var trait_map := {}
	for t in Game.traits():
		trait_map[t] = randi_range(15, 85)
	return {
		"id": "", "nome": "", "genere": GENDERS.pick_random(), "lavoro": "", "intercalare": "", "storia": "",
		"ama": ["fiori"], "odia": [], "attrazione": [], "luogo": null, "tratti": trait_map,
		"parlata": "",
		"aspetto": {"pelle": SKIN.pick_random(), "capelli": HAIR.pick_random(), "stile": ["corti", "lunghi", "codini", "ricci"].pick_random(), "maglia": CLOTH.pick_random(), "pantaloni": CLOTH.pick_random(), "vestito": "pantaloni", "accessorio": "nessuno", "occhi": ["tondi", "dolci", "vivaci"].pick_random(), "colore_occhi": EYES.pick_random(), "pixel": {}},
	}


func open_editor(mode: String, first: bool, keep: bool = false) -> void:
	_ed_mode = mode
	_ed_first = first
	if keep and not _ed.is_empty():
		pass
	elif mode == "player":
		_ed = Game.player.duplicate(true)
	elif mode == "nuovo":
		if Game.free_house() == "":
			toast("Non ci sono case libere! Fai traslocare qualcuno per fare spazio.")
			return
		_ed = _random_npc()
	elif Game.npcs.has(mode):
		_ed = Game.npcs[mode].duplicate(true)
	else:
		return
	if not _ed.has("aspetto"):
		_ed["aspetto"] = {}
	var look: Dictionary = _ed["aspetto"]
	if not look.has("occhi"):
		look["occhi"] = "tondi"
	if not look.has("colore_occhi"):
		look["colore_occhi"] = "#5a3c8c"
	if not look.has("pixel"):
		look["pixel"] = {}
	if mode != "player" and not _ed.has("tratti"):
		_ed["tratti"] = {}
	var title := "Modifica " + Game.name_of(mode)
	if first:
		title = "Crea il tuo personaggio"
	elif mode == "player":
		title = "Il tuo personaggio"
	elif mode == "nuovo":
		title = "Nuovo abitante"
	var vb := _open_panel(title)
	if not first:
		_panel_top.add_child(_btn("Annulla", close_panel, 150))
	_panel_top.add_child(_btn("Salva", _editor_save, 150))
	var hb := HBoxContainer.new()
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)
	var left := VBoxContainer.new()
	left.add_child(_make_preview(look, Vector2(280, 380)))
	left.add_child(_btnw("Disegna sul viso", 280, func() -> void:
		_open_face_editor()
	))
	hb.add_child(left)
	var body := _scroll(hb)
	body.add_child(_lbl("Nome", 20, true))
	var name_edit := LineEdit.new()
	name_edit.text = str(_ed.get("nome", ""))
	name_edit.placeholder_text = "Scrivi un nome"
	name_edit.max_length = 18
	name_edit.custom_minimum_size.y = 58
	name_edit.text_changed.connect(func(t: String) -> void:
		_ed["nome"] = t
	)
	body.add_child(name_edit)
	_choice_row(body, "Genere", GENDERS, GENDER_LABELS, str(_ed.get("genere", "altro")), func(v: String) -> void:
		_ed["genere"] = v
	)
	_preset_row(body, "Occhi", "occhi", "occhi", "tondi")
	_swatch_row(body, "Colore occhi", EYES, "colore_occhi")
	_preset_row(body, "Capelli", "capelli", "stile", "corti")
	_swatch_row(body, "Colore capelli", HAIR, "capelli")
	_swatch_row(body, "Pelle", SKIN, "pelle")
	_preset_row(body, "Vestiti", "vestiti", "vestito", "pantaloni")
	_swatch_row(body, "Colore maglia", CLOTH, "maglia")
	_swatch_row(body, "Colore pantaloni / gonna", CLOTH, "pantaloni")
	_preset_row(body, "Accessorio", "accessori", "accessorio", "nessuno")
	if mode == "player":
		return
	_text_field(body, "Lavoro o passione (es. \"il pescatore\")", "lavoro")
	_text_field(body, "Intercalare (es. \"Fantastico!\")", "intercalare")
	_text_field(body, "Modo di parlare (es. \"usa proverbi e chiama tutti tesoro\")", "parlata", 160)
	body.add_child(_lbl("Carattere", 22, true))
	for t in Game.traits():
		_trait_slider(body, t)
	var tags := {}
	for k in Game.items:
		for tg in Game.items[k].get("tag", []):
			tags[tg] = true
	body.add_child(_lbl("Gusti (separati da virgola). Possibili: " + ", ".join(tags.keys()), 18))
	_tags_field(body, "Cosa ama", "ama")
	_tags_field(body, "Cosa odia", "odia")
	var att: Array = _ed.get("attrazione", [])
	body.add_child(_lbl("Può innamorarsi di (nessuna scelta = chiunque)", 20, true))
	var flow := HFlowContainer.new()
	for i in GENDERS.size():
		var gv: String = GENDERS[i]
		var b := Button.new()
		b.text = GENDER_LABELS[i]
		b.toggle_mode = true
		b.button_pressed = att.has(gv)
		b.custom_minimum_size = Vector2(0, 52)
		b.toggled.connect(func(on: bool) -> void:
			var arr: Array = _ed.get("attrazione", [])
			if on and not arr.has(gv):
				arr.append(gv)
			elif not on:
				arr.erase(gv)
			_ed["attrazione"] = arr
		)
		flow.add_child(b)
	body.add_child(flow)
	body.add_child(_lbl("Storia", 20, true))
	var story := TextEdit.new()
	story.text = str(_ed.get("storia", ""))
	story.wrap_mode = TextEdit.LINE_WRAPPING_BOUNDARY
	story.custom_minimum_size = Vector2(0, 130)
	story.text_changed.connect(func() -> void:
		_ed["storia"] = story.text
	)
	body.add_child(story)


func _preset_row(parent: Control, title: String, kind: String, key: String, fallback: String) -> void:
	var ids: Array = []
	var labels: Array = []
	for p in Chibi.available(Game.models, kind):
		ids.append(str(p.get("id", "")))
		labels.append(str(p.get("nome", p.get("id", ""))))
	if ids.is_empty():
		return
	_choice_row(parent, title, ids, labels, str(_ed["aspetto"].get(key, fallback)), func(v: String) -> void:
		_set_look(key, v)
	)


func _open_face_editor() -> void:
	var look: Dictionary = _ed["aspetto"]
	var vb := _open_panel("Disegna sul viso")
	_panel_top.add_child(_btnw("Fine", 150, func() -> void:
		open_editor(_ed_mode, _ed_first, true)
	))
	var hb := HBoxContainer.new()
	hb.size_flags_vertical = Control.SIZE_EXPAND_FILL
	vb.add_child(hb)
	var canvas = FaceCanvasScript.new()
	canvas.app = look
	canvas.size_flags_vertical = Control.SIZE_SHRINK_BEGIN
	hb.add_child(canvas)
	var side := _scroll(hb)
	var current := ColorRect.new()
	current.custom_minimum_size = Vector2(60, 40)
	current.color = canvas.color
	var prev_box := _make_preview(look, Vector2(200, 260))
	canvas.changed.connect(func() -> void:
		current.color = canvas.color
		if preview != null and is_instance_valid(preview):
			preview._refresh_face()
	)
	_choice_row(side, "Strumento", ["matita", "gomma", "nascondi", "contagocce"], ["Matita", "Gomma", "Nascondi pixel", "Contagocce"], "matita", func(v: String) -> void:
		canvas.brush = v
	)
	side.add_child(_lbl("Colore", 20, true))
	var row := HBoxContainer.new()
	row.add_child(current)
	var picker := ColorPickerButton.new()
	picker.text = "Altro colore"
	picker.custom_minimum_size = Vector2(200, 52)
	picker.color = canvas.color
	picker.color_changed.connect(func(c: Color) -> void:
		canvas.color = c
		current.color = c
		canvas.brush = "matita"
	)
	row.add_child(picker)
	side.add_child(row)
	var flow := HFlowContainer.new()
	var pal: Array = PALETTE.duplicate()
	pal.append(str(look.get("pelle", "#f8d8b8")))
	pal.append(str(look.get("capelli", "#503020")))
	pal.append(str(look.get("colore_occhi", "#5a3c8c")))
	for hex in pal:
		var col := Color.html(str(hex))
		var b := Button.new()
		b.custom_minimum_size = Vector2(46, 46)
		b.add_theme_stylebox_override("normal", _sb(col, Color.html("#707888"), 2, 8, 0))
		b.add_theme_stylebox_override("hover", _sb(col, Color.html("#303848"), 3, 8, 0))
		b.add_theme_stylebox_override("pressed", _sb(col, Color.html("#101018"), 5, 8, 0))
		b.pressed.connect(func() -> void:
			canvas.color = col
			current.color = col
		)
		flow.add_child(b)
	side.add_child(flow)
	_choice_row(side, "Espressione da vedere", Face.EXPRESSIONS, Face.EXPR_LABELS, "normale", func(v: String) -> void:
		canvas.expr = v
		canvas.queue_redraw()
		if preview != null and is_instance_valid(preview):
			if v == "normale":
				preview.clear_expression()
			else:
				preview.show_expression(v, -1.0)
	)
	side.add_child(prev_box)
	side.add_child(_lbl("Matita: disegna. Gomma: toglie i tuoi pixel. Nascondi pixel: cancella anche pezzi di occhi o bocca. Contagocce: prende un colore dal viso. Il bordo esterno resta sempre vuoto. I disegni valgono per tutte le espressioni.", 18))
	side.add_child(_btnw("Cancella tutti i miei disegni", 0, func() -> void:
		canvas.clear_all()
	))


func _set_look(key: String, v: String) -> void:
	_ed["aspetto"][key] = v
	if preview != null and is_instance_valid(preview):
		preview.build(_ed["aspetto"])


func _choice_row(parent: Control, title: String, values: Array, labels: Array, current: String, on_pick: Callable) -> void:
	parent.add_child(_lbl(title, 20, true))
	var flow := HFlowContainer.new()
	var grp := ButtonGroup.new()
	for i in values.size():
		var v: String = str(values[i])
		var b := Button.new()
		b.text = str(labels[i])
		b.toggle_mode = true
		b.button_group = grp
		b.button_pressed = v == current
		b.custom_minimum_size = Vector2(0, 52)
		b.pressed.connect(func() -> void:
			on_pick.call(v)
		)
		flow.add_child(b)
	parent.add_child(flow)


func _swatch_row(parent: Control, title: String, colors: Array, key: String) -> void:
	parent.add_child(_lbl(title, 20, true))
	var flow := HFlowContainer.new()
	var grp := ButtonGroup.new()
	var cur := str(_ed["aspetto"].get(key, "")).to_lower()
	for hex in colors:
		var hx: String = hex
		var col := Color.html(hx)
		var b := Button.new()
		b.toggle_mode = true
		b.button_group = grp
		b.custom_minimum_size = Vector2(54, 54)
		b.add_theme_stylebox_override("normal", _sb(col, Color.html("#707888"), 2, 10, 0))
		b.add_theme_stylebox_override("hover", _sb(col, Color.html("#505868"), 3, 10, 0))
		b.add_theme_stylebox_override("pressed", _sb(col, Color.html("#101018"), 6, 10, 0))
		b.add_theme_stylebox_override("hover_pressed", _sb(col, Color.html("#101018"), 6, 10, 0))
		b.button_pressed = hx.to_lower() == cur
		b.pressed.connect(func() -> void:
			_set_look(key, hx)
		)
		flow.add_child(b)
	parent.add_child(flow)


func _text_field(parent: Control, title: String, key: String, max_len: int = 60) -> void:
	parent.add_child(_lbl(title, 20, true))
	var le := LineEdit.new()
	le.text = str(_ed.get(key, ""))
	le.custom_minimum_size.y = 56
	le.max_length = max_len
	le.text_changed.connect(func(t: String) -> void:
		_ed[key] = t
	)
	parent.add_child(le)


func _tags_field(parent: Control, title: String, key: String) -> void:
	parent.add_child(_lbl(title, 20, true))
	var le := LineEdit.new()
	le.text = ", ".join(_ed.get(key, []))
	le.custom_minimum_size.y = 56
	le.text_changed.connect(func(t: String) -> void:
		var out: Array = []
		for p in t.split(","):
			var s: String = str(p).strip_edges().to_lower()
			if s != "":
				out.append(s)
		_ed[key] = out
	)
	parent.add_child(le)


func _trait_slider(parent: Control, t: String) -> void:
	var hb := HBoxContainer.new()
	var l := _lbl(str(TRAIT_NAMES.get(t, t)), 20)
	l.custom_minimum_size.x = 150
	l.autowrap_mode = TextServer.AUTOWRAP_OFF
	hb.add_child(l)
	var s := HSlider.new()
	s.min_value = 0
	s.max_value = 100
	s.step = 1
	s.value = float(_ed["tratti"].get(t, 50))
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	s.custom_minimum_size.y = 44
	hb.add_child(s)
	var vl := _lbl(str(int(s.value)), 20)
	vl.custom_minimum_size.x = 50
	vl.autowrap_mode = TextServer.AUTOWRAP_OFF
	hb.add_child(vl)
	s.value_changed.connect(func(v: float) -> void:
		_ed["tratti"][t] = int(v)
		vl.text = str(int(v))
	)
	parent.add_child(hb)


func _editor_save() -> void:
	var nm := str(_ed.get("nome", "")).strip_edges()
	if nm == "":
		toast("Scrivi un nome!")
		return
	_ed["nome"] = nm
	var first := _ed_first
	if _ed_mode == "player":
		Game.player = _ed
		main.rebuild_player()
	elif _ed_mode == "nuovo":
		var id := Game.add_npc(_ed)
		if id == "":
			toast("Non ci sono case libere!")
			return
		main.spawn_npc(id)
		main.refresh_house_labels()
	else:
		Game.npcs[_ed_mode] = _ed
		if main.npc_nodes.has(_ed_mode):
			main.npc_nodes[_ed_mode].build(_ed["aspetto"])
		main.refresh_house_labels()
	_ed_first = false
	close_panel()
	Game.save_game()
	if first:
		run_node("intro", "", Callable())
	else:
		toast("Salvato!")
