extends Control
## Joystick virtuale multitouch (funziona anche col mouse su PC).

const RADIUS := 90.0
var output: Vector2 = Vector2.ZERO
var knob: Vector2 = Vector2.ZERO
var touch_index: int = -1


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_STOP


func _input(event) -> void:
	if not is_visible_in_tree():
		if touch_index != -1:
			_release()
		return
	if event is InputEventScreenTouch:
		if event.pressed and touch_index == -1 and get_global_rect().has_point(event.position):
			touch_index = event.index
			_update(event.position)
		elif not event.pressed and event.index == touch_index:
			_release()
	elif event is InputEventScreenDrag:
		if event.index == touch_index:
			_update(event.position)


func _update(p: Vector2) -> void:
	var local := p - global_position - size / 2.0
	if local.length() > RADIUS:
		local = local.normalized() * RADIUS
	knob = local
	output = local / RADIUS
	if output.length() < 0.15:
		output = Vector2.ZERO
	queue_redraw()


func _release() -> void:
	touch_index = -1
	output = Vector2.ZERO
	knob = Vector2.ZERO
	queue_redraw()


func _draw() -> void:
	var c := size / 2.0
	draw_circle(c, RADIUS, Color(1, 1, 1, 0.16))
	draw_arc(c, RADIUS, 0.0, TAU, 48, Color(1, 1, 1, 0.55), 4.0)
	draw_circle(c + knob, 40.0, Color(1, 1, 1, 0.6))
	draw_arc(c + knob, 40.0, 0.0, TAU, 32, Color(0.2, 0.25, 0.4, 0.6), 3.0)
