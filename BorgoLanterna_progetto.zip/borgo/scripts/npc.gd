extends "res://scripts/chibi.gd"
## Abitante con una piccola IA: orari, passeggiate, casa, chiacchiere con gli altri abitanti.

var id: String = ""
var main = null
var zone: String = "out"
var path: Array = []
var state: String = "idle"   # idle, busy (parla con te), talk (parla con un altro abitante)
var goal: String = ""
var wait: float = 1.0
var speed: float = 1.7
var social_cd: float = 8.0
var talk_time: float = 0.0
var repath_cd: float = 0.0


func update_npc(delta: float) -> void:
	social_cd -= delta
	repath_cd -= delta
	if state == "busy":
		moving = false
		return
	if state == "talk":
		moving = false
		talk_time -= delta
		if talk_time <= 0.0:
			state = "idle"
			wait = randf_range(1.0, 3.0)
		return
	var want: Dictionary = main.npc_desire(id)
	var tipo: String = want["tipo"]
	if tipo == "casa":
		if zone == "out":
			if goal != "home":
				goal = "home"
				path = main.find_path(position, main.house_front(id))
				if path.is_empty():
					_enter_home()
					return
			_follow_path(delta)
			if path.is_empty():
				_enter_home()
		else:
			moving = false
			if icon and not icon.visible and is_sleeping():
				show_icon("zzz", -1.0)
		return
	if zone != "out":
		_exit_home()
		return
	if goal == "home":
		goal = ""
		path = []
	if tipo == "giocatore":
		if repath_cd <= 0.0:
			repath_cd = 1.2
			path = main.find_path(position, main.tile_near_player())
			goal = "player"
		_follow_path(delta)
		if position.distance_to(main.player.position) < 1.3:
			path = []
			main.start_confession(self)
		return
	if goal == "player":
		goal = ""
		path = []
	if not path.is_empty():
		_follow_path(delta)
		return
	moving = false
	wait -= delta
	if wait <= 0.0:
		var target: Vector2i = main.random_walkable_near(want["centro"], int(want["raggio"]))
		path = main.find_path(position, target)
		goal = "wander"
		wait = randf_range(2.0, 7.0)
	elif social_cd <= 0.0:
		social_cd = 3.0
		main.try_npc_social(self)


func is_sleeping() -> bool:
	var h := Game.hour()
	return zone != "out" and (h >= 21.0 or h < 7.0)


func _follow_path(delta: float) -> void:
	if path.is_empty():
		moving = false
		return
	var tgt: Vector3 = path[0]
	var d := tgt - position
	d.y = 0.0
	var dist := d.length()
	if dist < 0.05:
		position = Vector3(tgt.x, 0.0, tgt.z)
		path.pop_front()
		return
	var step := minf(speed * delta, dist)
	var dir := d / dist
	position += dir * step
	face_dir(dir)
	moving = true


func _enter_home() -> void:
	var hid: String = str(Game.npcs[id].get("casa", ""))
	if not main.house_by_id.has(hid):
		goal = ""
		return
	zone = hid
	path = []
	goal = ""
	position = main.bed_spot(hid)
	face_now(Vector3(0, 0, 1))
	moving = false


func _exit_home() -> void:
	var f: Vector2i = main.house_front(id)
	zone = "out"
	position = Vector3(f.x + 0.5, 0.0, f.y + 0.5)
	face_now(Vector3(0, 0, 1))
	hide_icon()
	path = []
	goal = ""
	wait = 0.5
