extends Node3D
## Personaggio chibi 3D costruito con forme semplici, colorato in base all'aspetto scelto.

const PixelTex = preload("res://scripts/pixel_tex.gd")

static var _mat_cache: Dictionary = {}

var appearance: Dictionary = {}
var moving: bool = false
var body_root: Node3D
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var icon: Sprite3D
var icon_timer: float = 0.0
var walk_t: float = 0.0
var _target_yaw: float = 0.0


static func mat(col: Color) -> StandardMaterial3D:
	var key := col.to_html()
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 1.0
	_mat_cache[key] = m
	return m


func _part(parent: Node3D, mesh: Mesh, pos: Vector3, col: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat(col)
	parent.add_child(mi)
	return mi


func _box(parent: Node3D, size: Vector3, pos: Vector3, col: Color) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return _part(parent, b, pos, col)


func _sphere(parent: Node3D, r: float, pos: Vector3, col: Color, seg: int = 12) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = seg
	s.rings = maxi(4, seg / 2)
	return _part(parent, s, pos, col)


func _cyl(parent: Node3D, top: float, bottom: float, h: float, pos: Vector3, col: Color) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = top
	cm.bottom_radius = bottom
	cm.height = h
	cm.radial_segments = 12
	cm.rings = 1
	return _part(parent, cm, pos, col)


func _col(key: String, fallback: String) -> Color:
	return Color.html(str(appearance.get(key, fallback)))


func build(app: Dictionary) -> void:
	appearance = app
	for ch in get_children():
		remove_child(ch)
		ch.queue_free()
	var skin := _col("pelle", "#f8d8b8")
	var hair := _col("capelli", "#503020")
	var shirt := _col("maglia", "#e04848")
	var pants := _col("pantaloni", "#3048a0")
	var style := str(appearance.get("stile", "corti"))
	var dress := str(appearance.get("vestito", "pantaloni")) == "gonna"
	var acc := str(appearance.get("accessorio", "nessuno"))

	# ombra
	var sh := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(0.55, 0.55)
	sh.mesh = pm
	var sm := StandardMaterial3D.new()
	sm.albedo_texture = PixelTex.shadow()
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	sh.material_override = sm
	sh.position.y = 0.015
	add_child(sh)

	body_root = Node3D.new()
	add_child(body_root)

	# gambe
	leg_l = Node3D.new()
	leg_l.position = Vector3(-0.07, 0.2, 0)
	body_root.add_child(leg_l)
	_box(leg_l, Vector3(0.1, 0.2, 0.1), Vector3(0, -0.1, 0), pants if not dress else skin)
	_box(leg_l, Vector3(0.11, 0.05, 0.13), Vector3(0, -0.18, 0.01), Color.html("#5a3a2a"))
	leg_r = Node3D.new()
	leg_r.position = Vector3(0.07, 0.2, 0)
	body_root.add_child(leg_r)
	_box(leg_r, Vector3(0.1, 0.2, 0.1), Vector3(0, -0.1, 0), pants if not dress else skin)
	_box(leg_r, Vector3(0.11, 0.05, 0.13), Vector3(0, -0.18, 0.01), Color.html("#5a3a2a"))

	# corpo
	if dress:
		_cyl(body_root, 0.12, 0.22, 0.3, Vector3(0, 0.33, 0), shirt)
		_cyl(body_root, 0.2, 0.24, 0.08, Vector3(0, 0.21, 0), pants)
	else:
		_cyl(body_root, 0.12, 0.16, 0.18, Vector3(0, 0.39, 0), shirt)
		_cyl(body_root, 0.16, 0.16, 0.1, Vector3(0, 0.26, 0), pants)

	# braccia
	arm_l = Node3D.new()
	arm_l.position = Vector3(-0.16, 0.46, 0)
	body_root.add_child(arm_l)
	_box(arm_l, Vector3(0.07, 0.18, 0.07), Vector3(0, -0.08, 0), shirt)
	_sphere(arm_l, 0.045, Vector3(0, -0.19, 0), skin, 8)
	arm_r = Node3D.new()
	arm_r.position = Vector3(0.16, 0.46, 0)
	body_root.add_child(arm_r)
	_box(arm_r, Vector3(0.07, 0.18, 0.07), Vector3(0, -0.08, 0), shirt)
	_sphere(arm_r, 0.045, Vector3(0, -0.19, 0), skin, 8)

	# testa
	var head := Node3D.new()
	head.position = Vector3(0, 0.74, 0)
	body_root.add_child(head)
	_sphere(head, 0.26, Vector3.ZERO, skin, 16)
	var eye := Color.html("#262030")
	_box(head, Vector3(0.05, 0.09, 0.02), Vector3(-0.09, -0.01, 0.24), eye)
	_box(head, Vector3(0.05, 0.09, 0.02), Vector3(0.09, -0.01, 0.24), eye)
	_box(head, Vector3(0.02, 0.025, 0.01), Vector3(-0.08, 0.02, 0.252), Color.WHITE)
	_box(head, Vector3(0.02, 0.025, 0.01), Vector3(0.1, 0.02, 0.252), Color.WHITE)
	_box(head, Vector3(0.06, 0.025, 0.02), Vector3(-0.15, -0.08, 0.2), Color.html("#f8a0a0"))
	_box(head, Vector3(0.06, 0.025, 0.02), Vector3(0.15, -0.08, 0.2), Color.html("#f8a0a0"))
	_box(head, Vector3(0.06, 0.015, 0.02), Vector3(0, -0.1, 0.235), Color.html("#a04040"))

	# capelli
	var cap := _sphere(head, 0.28, Vector3(0, 0.06, -0.05), hair, 16)
	cap.scale = Vector3(1.0, 0.95, 1.0)
	_box(head, Vector3(0.44, 0.1, 0.12), Vector3(0, 0.16, 0.17), hair)
	match style:
		"lunghi":
			_box(head, Vector3(0.5, 0.42, 0.16), Vector3(0, -0.12, -0.17), hair)
			_box(head, Vector3(0.08, 0.3, 0.12), Vector3(-0.24, -0.08, 0.04), hair)
			_box(head, Vector3(0.08, 0.3, 0.12), Vector3(0.24, -0.08, 0.04), hair)
		"codini":
			_sphere(head, 0.1, Vector3(-0.3, -0.02, -0.06), hair, 10)
			_sphere(head, 0.1, Vector3(0.3, -0.02, -0.06), hair, 10)
		"punk":
			_cyl(head, 0.0, 0.12, 0.26, Vector3(0, 0.38, -0.03), hair)
		"chignon":
			_sphere(head, 0.12, Vector3(0, 0.3, -0.12), hair, 10)
		"ricci":
			for a in 8:
				var ang := TAU * a / 8.0
				_sphere(head, 0.1, Vector3(cos(ang) * 0.24, 0.12 + sin(ang * 2.0) * 0.04, sin(ang) * 0.2 - 0.05), hair, 8)

	# accessori
	match acc:
		"occhiali":
			var fr := Color.html("#383848")
			_box(head, Vector3(0.12, 0.1, 0.015), Vector3(-0.09, -0.01, 0.262), fr)
			_box(head, Vector3(0.12, 0.1, 0.015), Vector3(0.09, -0.01, 0.262), fr)
			_box(head, Vector3(0.08, 0.07, 0.016), Vector3(-0.09, -0.01, 0.266), Color.html("#d8e8f8"))
			_box(head, Vector3(0.08, 0.07, 0.016), Vector3(0.09, -0.01, 0.266), Color.html("#d8e8f8"))
		"fiocco":
			var bow := Color.html("#f04870")
			_box(head, Vector3(0.1, 0.1, 0.05), Vector3(0.12, 0.27, 0.08), bow)
			_box(head, Vector3(0.1, 0.1, 0.05), Vector3(0.24, 0.27, 0.08), bow)
		"cappello":
			_cyl(head, 0.3, 0.3, 0.03, Vector3(0, 0.22, 0), Color.html("#e8d088"))
			_cyl(head, 0.18, 0.2, 0.16, Vector3(0, 0.3, 0), Color.html("#e8d088"))
			_cyl(head, 0.205, 0.205, 0.04, Vector3(0, 0.25, 0), Color.html("#c84848"))

	icon = Sprite3D.new()
	icon.pixel_size = 0.04
	icon.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	icon.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	icon.no_depth_test = true
	icon.position = Vector3(0, 1.32, 0)
	icon.visible = false
	add_child(icon)


func show_icon(kind: String, secs: float = 2.5) -> void:
	if icon == null:
		return
	icon.texture = PixelTex.status_icon(kind)
	icon.visible = true
	icon_timer = secs


func hide_icon() -> void:
	if icon:
		icon.visible = false
	icon_timer = 0.0


func face_dir(d: Vector3) -> void:
	if Vector2(d.x, d.z).length() < 0.01:
		return
	_target_yaw = atan2(d.x, d.z)


func face_now(d: Vector3) -> void:
	face_dir(d)
	rotation.y = _target_yaw


func _process(delta: float) -> void:
	rotation.y = lerp_angle(rotation.y, _target_yaw, minf(1.0, delta * 14.0))
	if body_root == null:
		return
	if moving:
		walk_t += delta * 11.0
		var s := sin(walk_t)
		leg_l.rotation.x = s * 0.6
		leg_r.rotation.x = -s * 0.6
		arm_l.rotation.x = -s * 0.5
		arm_r.rotation.x = s * 0.5
		body_root.position.y = absf(s) * 0.035
	else:
		walk_t = 0.0
		leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, delta * 10.0)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, delta * 10.0)
		arm_l.rotation.x = lerpf(arm_l.rotation.x, 0.0, delta * 10.0)
		arm_r.rotation.x = lerpf(arm_r.rotation.x, 0.0, delta * 10.0)
		body_root.position.y = absf(sin(Time.get_ticks_msec() / 400.0)) * 0.008
	if icon and icon.visible:
		icon.position.y = 1.32 + sin(Time.get_ticks_msec() / 200.0) * 0.03
		if icon_timer > 0.0:
			icon_timer -= delta
			if icon_timer <= 0.0:
				icon.visible = false
