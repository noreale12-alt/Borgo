extends Node3D
## Personaggio stile Nendoroid.
## - Corpo: res://models/corpo.glb (NomadSculpt) se esiste, altrimenti un corpo provvisorio fatto di forme semplici.
## - Capelli, vestiti, accessori: preset da data/modelli.json (file .glb oppure forme del gioco).
## - Viso: pixel art 32x32 con espressioni (scripts/face.gd), modificabile nell'editor a pixel.

const PixelTex = preload("res://scripts/pixel_tex.gd")
const Face = preload("res://scripts/face.gd")
const R0 := 0.32
const PARTS := ["testa", "busto", "braccio_sx", "braccio_dx", "gamba_sx", "gamba_dx"]
const ICON_EXPR := {"cuore": "felice", "nota": "felice", "stella": "felice", "rabbia": "arrabbiato", "puntini": "triste", "esclamazione": "sorpreso", "zzz": "chiusi"}

static var _mat_cache: Dictionary = {}
static var _scene_cache: Dictionary = {}

var appearance: Dictionary = {}
var moving: bool = false
var body_root: Node3D
var model_root: Node3D
var head_node: Node3D
var pivots: Dictionary = {}
var pivot_pos: Dictionary = {}
var using_model: bool = false
var leg_l: Node3D
var leg_r: Node3D
var arm_l: Node3D
var arm_r: Node3D
var face_mat: StandardMaterial3D
var base_expr: String = "normale"
var temp_expr: String = ""
var temp_timer: float = 0.0
var icon: Sprite3D
var icon_timer: float = 0.0
var walk_t: float = 0.0
var _target_yaw: float = 0.0


# ================================================================ utilità statiche

static func mat(col: Color) -> StandardMaterial3D:
	var key := col.to_html()
	if _mat_cache.has(key):
		return _mat_cache[key]
	var m := StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = 0.9
	_mat_cache[key] = m
	return m


static func load_scene(path: String) -> PackedScene:
	if _scene_cache.has(path):
		return _scene_cache[path]
	var ps: PackedScene = null
	if path != "" and ResourceLoader.exists(path):
		var r: Resource = load(path)
		if r is PackedScene:
			ps = r
	_scene_cache[path] = ps
	return ps


static func body_model_available(models: Dictionary) -> bool:
	var cfg: Dictionary = models.get("corpo", {})
	return load_scene(str(cfg.get("file", ""))) != null


## Preset disponibili per un tipo (capelli, vestiti, accessori, occhi).
static func available(models: Dictionary, kind: String) -> Array:
	var out: Array = []
	var has_body := body_model_available(models)
	for p in models.get(kind, []):
		var f := str(p.get("file", ""))
		if f == "":
			out.append(p)
		elif has_body and load_scene(f) != null:
			out.append(p)
	return out


func _preset(kind: String, id: String) -> Dictionary:
	for p in Game.models.get(kind, []):
		if str(p.get("id", "")) == id:
			return p
	return {}


static func _part_of(n: String, fallback: String) -> String:
	var s := n.to_lower().replace(" ", "_").replace("-", "_").replace(".", "_")
	for p in ["faccia", "braccio_sx", "braccio_dx", "gamba_sx", "gamba_dx", "testa", "busto"]:
		if s.contains(p):
			return p
	if s.contains("corpo") or s.contains("torso"):
		return "busto"
	return fallback


static func _rel_xform(n: Node, root: Node) -> Transform3D:
	var t := Transform3D()
	var cur: Node = n
	while cur != null and cur != root:
		if cur is Node3D:
			t = (cur as Node3D).transform * t
		cur = cur.get_parent()
	return t


func _col(key: String, fallback: String) -> Color:
	return Color.html(str(appearance.get(key, fallback)))


func _part(parent: Node3D, mesh: Mesh, pos: Vector3, col: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	mi.position = pos
	mi.material_override = mat(col)
	parent.add_child(mi)
	return mi


func _box(parent: Node3D, size: Vector3, pos: Vector3, col: Color) -> MeshInstance3D:
	var b := BoxMesh.new()
	b.size = size
	return _part(parent, b, pos, col)


func _sphere(parent: Node3D, r: float, pos: Vector3, col: Color, seg: int = 14) -> MeshInstance3D:
	var s := SphereMesh.new()
	s.radius = r
	s.height = r * 2.0
	s.radial_segments = seg
	s.rings = maxi(4, seg / 2)
	return _part(parent, s, pos, col)


func _cyl(parent: Node3D, top: float, bottom: float, h: float, pos: Vector3, col: Color) -> MeshInstance3D:
	var cm := CylinderMesh.new()
	cm.top_radius = top
	cm.bottom_radius = bottom
	cm.height = h
	cm.radial_segments = 14
	cm.rings = 1
	return _part(parent, cm, pos, col)


## Colore di una parte del corpo in base al vestito scelto.
func part_color(part: String) -> Color:
	var skin := _col("pelle", "#f8d8b8")
	var shirt := _col("maglia", "#e04848")
	var pants := _col("pantaloni", "#3048a0")
	var vest := str(appearance.get("vestito", "pantaloni"))
	if part == "testa":
		return skin
	if str(_preset("vestiti", vest).get("file", "")) != "" and using_model:
		return skin
	match part:
		"busto", "braccio_sx", "braccio_dx":
			return shirt
		"gamba_sx", "gamba_dx":
			return skin if vest == "gonna" else pants
	return skin


# ================================================================ costruzione

func build(app: Dictionary) -> void:
	appearance = app
	for ch in get_children():
		remove_child(ch)
		ch.queue_free()
	pivots = {}
	pivot_pos = {}
	face_mat = null

	var sh := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(0.6, 0.6)
	sh.mesh = pm
	var sm := StandardMaterial3D.new()
	sm.albedo_texture = PixelTex.shadow()
	sm.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	sm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	sm.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	sh.material_override = sm
	sh.position.y = 0.015
	add_child(sh)

	body_root = Node3D.new()
	add_child(body_root)
	using_model = false
	var cfg: Dictionary = Game.models.get("corpo", {})
	var path := str(cfg.get("file", ""))
	if load_scene(path) != null:
		using_model = _build_model_body(path, float(cfg.get("ruota_y", 0)))
	if not using_model:
		for ch in body_root.get_children():
			body_root.remove_child(ch)
			ch.queue_free()
		_build_proc_body()
	for p in PARTS:
		if not pivots.has(p):
			_make_pivot(p, Vector3.ZERO)
	leg_l = pivots["gamba_sx"]
	leg_r = pivots["gamba_dx"]
	arm_l = pivots["braccio_sx"]
	arm_r = pivots["braccio_dx"]
	if face_mat == null:
		_add_face_shell()
	_add_hair()
	_add_clothes()
	_add_accessory()
	_refresh_face()

	icon = Sprite3D.new()
	icon.pixel_size = 0.04
	icon.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	icon.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	icon.no_depth_test = true
	icon.position = Vector3(0, 1.3, 0)
	icon.visible = false
	add_child(icon)


func _make_pivot(part: String, pos: Vector3) -> Node3D:
	var n := Node3D.new()
	n.position = pos
	model_root.add_child(n)
	pivots[part] = n
	pivot_pos[part] = pos
	return n


func _build_proc_body() -> void:
	model_root = Node3D.new()
	body_root.add_child(model_root)
	var skin := _col("pelle", "#f8d8b8")
	var shoe := Color.html("#5a3a2a")
	for side in [["gamba_sx", 0.065], ["gamba_dx", -0.065]]:
		var leg := _make_pivot(str(side[0]), Vector3(float(side[1]), 0.17, 0))
		_box(leg, Vector3(0.09, 0.15, 0.09), Vector3(0, -0.08, 0), part_color(str(side[0])))
		_box(leg, Vector3(0.1, 0.05, 0.13), Vector3(0, -0.15, 0.015), shoe)
	var torso := _make_pivot("busto", Vector3(0, 0.17, 0))
	_cyl(torso, 0.1, 0.135, 0.2, Vector3(0, 0.1, 0), part_color("busto"))
	if str(appearance.get("vestito", "pantaloni")) == "gonna":
		_cyl(torso, 0.11, 0.2, 0.15, Vector3(0, 0.02, 0), part_color("busto"))
	else:
		_cyl(torso, 0.137, 0.137, 0.05, Vector3(0, 0.02, 0), _col("pantaloni", "#3048a0"))
	for side in [["braccio_sx", 0.125], ["braccio_dx", -0.125]]:
		var arm := _make_pivot(str(side[0]), Vector3(float(side[1]), 0.345, 0))
		_box(arm, Vector3(0.055, 0.14, 0.055), Vector3(0, -0.065, 0), part_color(str(side[0])))
		_sphere(arm, 0.036, Vector3(0, -0.15, 0), skin, 8)
	var head := _make_pivot("testa", Vector3(0, 0.37, 0))
	head_node = Node3D.new()
	head_node.position = Vector3(0, 0.3, 0)
	head.add_child(head_node)
	_sphere(head_node, R0, Vector3.ZERO, skin, 20)


func _build_model_body(path: String, rot_deg: float) -> bool:
	var scene := load_scene(path)
	var inst := scene.instantiate()
	var entries: Array = []
	var total := AABB()
	var first := true
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m3 := mi as MeshInstance3D
		var xf := _rel_xform(m3, inst)
		var ab: AABB = xf * m3.get_aabb()
		entries.append([m3, xf, _part_of(str(m3.name), "busto"), ab])
		if first:
			total = ab
			first = false
		else:
			total = total.merge(ab)
	if entries.is_empty() or total.size.y <= 0.0001:
		inst.free()
		return false
	using_model = true
	var s := 1.0 / total.size.y
	model_root = Node3D.new()
	body_root.add_child(model_root)
	var rad := deg_to_rad(rot_deg)
	model_root.rotation.y = rad
	model_root.scale = Vector3(s, s, s)
	var c := total.get_center()
	model_root.position = Basis(Vector3.UP, rad) * (Vector3(-c.x, -total.position.y, -c.z) * s)
	# riquadro di ogni parte
	var part_box: Dictionary = {}
	for e in entries:
		var part: String = e[2]
		if part == "faccia":
			part = "testa"
		var eb: AABB = e[3]
		if part_box.has(part):
			var old: AABB = part_box[part]
			part_box[part] = old.merge(eb)
		else:
			part_box[part] = eb
	# perni calcolati in automatico: spalle, anche, collo
	for part in part_box:
		var ab: AABB = part_box[part]
		var ctr := ab.get_center()
		var piv := ctr
		match part:
			"braccio_sx", "braccio_dx", "gamba_sx", "gamba_dx":
				piv = Vector3(ctr.x, ab.end.y, ctr.z)
			"testa":
				piv = Vector3(ctr.x, ab.position.y, ctr.z)
		_make_pivot(part, piv)
	for p in PARTS:
		if not pivots.has(p):
			_make_pivot(p, c)
	for e in entries:
		var m3: MeshInstance3D = e[0]
		var part: String = e[2]
		var target := "testa" if part == "faccia" else part
		var P: Vector3 = pivot_pos[target]
		m3.get_parent().remove_child(m3)
		var exf: Transform3D = e[1]
		m3.transform = Transform3D(Basis(), -P) * exf
		(pivots[target] as Node3D).add_child(m3)
		var nm := str(m3.name).to_lower()
		if part == "faccia":
			face_mat = _new_face_mat(false)
			m3.material_override = face_mat
		elif not nm.contains("fisso"):
			m3.material_override = mat(part_color(part))
	inst.free()
	var hb: AABB = part_box.get("testa", AABB(c, Vector3(0.3, 0.3, 0.3)))
	head_node = Node3D.new()
	head_node.position = hb.get_center() - (pivot_pos["testa"] as Vector3)
	head_node.scale = hb.size / (2.0 * R0)
	(pivots["testa"] as Node3D).add_child(head_node)
	return true


## Collega un .glb (capelli, vestito, accessorio) modellato sopra il corpo base.
func _attach_glb(path: String, default_part: String, color_for: Callable) -> bool:
	var scene := load_scene(path)
	if scene == null or not using_model:
		return false
	var inst := scene.instantiate()
	for mi in inst.find_children("*", "MeshInstance3D", true, false):
		var m3 := mi as MeshInstance3D
		var xf := _rel_xform(m3, inst)
		var nm := str(m3.name)
		var part := _part_of(nm, default_part)
		if part == "faccia":
			part = "testa"
		var P: Vector3 = pivot_pos.get(part, Vector3.ZERO)
		m3.get_parent().remove_child(m3)
		m3.transform = Transform3D(Basis(), -P) * xf
		(pivots.get(part, pivots["busto"]) as Node3D).add_child(m3)
		var col: Variant = color_for.call(nm.to_lower(), part)
		if col is Color:
			m3.material_override = mat(col)
	inst.free()
	return true


func _new_face_mat(shell: bool) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	m.alpha_scissor_threshold = 0.5
	m.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	m.texture_repeat = false
	m.roughness = 0.9
	if shell:
		# la texture copre ±55° in orizzontale e la fascia centrale del viso
		m.uv1_scale = Vector3(3.2727, 2.0, 1.0)
		m.uv1_offset = Vector3(-1.1364, -0.6, 0.0)
	return m


func _add_face_shell() -> void:
	var s := SphereMesh.new()
	s.radius = R0 * 1.025
	s.height = R0 * 2.05
	s.radial_segments = 28
	s.rings = 16
	face_mat = _new_face_mat(true)
	var mi := MeshInstance3D.new()
	mi.mesh = s
	mi.material_override = face_mat
	mi.rotation.y = PI
	head_node.add_child(mi)


func _add_hair() -> void:
	var style := str(appearance.get("stile", "corti"))
	var hair := _col("capelli", "#503020")
	var f := str(_preset("capelli", style).get("file", ""))
	if f != "":
		var ok := _attach_glb(f, "testa", func(nm: String, _p: String) -> Variant:
			return null if nm.contains("fisso") else hair
		)
		if ok:
			return
		style = "corti"
	if style == "calvo":
		return
	var h := head_node
	var cap := _sphere(h, R0 * 1.08, Vector3(0, 0.055, -0.045), hair, 20)
	cap.scale = Vector3(1.0, 0.95, 1.0)
	_box(h, Vector3(0.5, 0.13, 0.15), Vector3(0, 0.2, 0.2), hair)
	match style:
		"lunghi":
			_box(h, Vector3(0.62, 0.52, 0.2), Vector3(0, -0.15, -0.2), hair)
			_box(h, Vector3(0.1, 0.38, 0.15), Vector3(0.3, -0.09, 0.06), hair)
			_box(h, Vector3(0.1, 0.38, 0.15), Vector3(-0.3, -0.09, 0.06), hair)
		"codini":
			_sphere(h, 0.12, Vector3(0.38, -0.02, -0.07), hair, 12)
			_sphere(h, 0.12, Vector3(-0.38, -0.02, -0.07), hair, 12)
		"punk":
			_cyl(h, 0.0, 0.15, 0.32, Vector3(0, 0.46, -0.03), hair)
		"chignon":
			_sphere(h, 0.15, Vector3(0, 0.37, -0.15), hair, 12)
		"ricci":
			for a in 9:
				var ang := TAU * a / 9.0
				_sphere(h, 0.12, Vector3(cos(ang) * 0.3, 0.15 + sin(ang * 2.0) * 0.05, sin(ang) * 0.25 - 0.06), hair, 10)


func _add_clothes() -> void:
	var vest := str(appearance.get("vestito", "pantaloni"))
	var f := str(_preset("vestiti", vest).get("file", ""))
	if f == "" or not using_model:
		return
	var shirt := _col("maglia", "#e04848")
	var pants := _col("pantaloni", "#3048a0")
	_attach_glb(f, "busto", func(nm: String, part: String) -> Variant:
		if nm.contains("fisso"):
			return null
		if nm.contains("pantaloni") or nm.contains("gonna") or part.begins_with("gamba"):
			return pants
		return shirt
	)


func _add_accessory() -> void:
	var acc := str(appearance.get("accessorio", "nessuno"))
	var f := str(_preset("accessori", acc).get("file", ""))
	if f != "":
		var shirt := _col("maglia", "#e04848")
		var hair := _col("capelli", "#503020")
		_attach_glb(f, "testa", func(nm: String, _p: String) -> Variant:
			if nm.contains("colore"):
				return shirt
			if nm.contains("capelli"):
				return hair
			return null
		)
		return
	var h := head_node
	match acc:
		"occhiali":
			var fr := Color.html("#383848")
			for sxv in [0.105, -0.105]:
				var sx := float(sxv)
				_box(h, Vector3(0.15, 0.12, 0.015), Vector3(sx, -0.045, 0.33), fr)
				_box(h, Vector3(0.11, 0.08, 0.016), Vector3(sx, -0.045, 0.335), Color(0.85, 0.92, 1.0))
			_box(h, Vector3(0.06, 0.02, 0.015), Vector3(0, -0.03, 0.335), fr)
		"fiocco":
			var bow := Color.html("#f04870")
			_box(h, Vector3(0.12, 0.12, 0.06), Vector3(0.14, 0.33, 0.1), bow)
			_box(h, Vector3(0.12, 0.12, 0.06), Vector3(0.28, 0.33, 0.1), bow)
			_box(h, Vector3(0.05, 0.05, 0.07), Vector3(0.21, 0.33, 0.1), bow.darkened(0.2))
		"cappello":
			_cyl(h, 0.39, 0.39, 0.03, Vector3(0, 0.25, 0), Color.html("#e8d088"))
			_cyl(h, 0.23, 0.25, 0.2, Vector3(0, 0.36, 0), Color.html("#e8d088"))
			_cyl(h, 0.255, 0.255, 0.05, Vector3(0, 0.29, 0), Color.html("#c84848"))


# ================================================================ espressioni

func _refresh_face() -> void:
	if face_mat == null:
		return
	var e := temp_expr if temp_expr != "" else base_expr
	face_mat.albedo_texture = Face.compose(appearance, e)


func set_base_expression(e: String) -> void:
	if e == base_expr:
		return
	base_expr = e
	_refresh_face()


## Espressione temporanea (secs < 0 = finché non viene tolta).
func show_expression(e: String, secs: float = 3.0) -> void:
	temp_expr = e
	temp_timer = secs
	_refresh_face()


func clear_expression() -> void:
	temp_expr = ""
	temp_timer = 0.0
	_refresh_face()


func show_icon(kind: String, secs: float = 2.5) -> void:
	if icon == null:
		return
	icon.texture = PixelTex.status_icon(kind)
	icon.visible = true
	icon_timer = secs
	if ICON_EXPR.has(kind):
		show_expression(ICON_EXPR[kind], secs)


func hide_icon() -> void:
	if icon:
		icon.visible = false
	icon_timer = 0.0
	if temp_expr == "chiusi":
		clear_expression()


func face_dir(d: Vector3) -> void:
	if Vector2(d.x, d.z).length() < 0.01:
		return
	_target_yaw = atan2(d.x, d.z)


func face_now(d: Vector3) -> void:
	face_dir(d)
	rotation.y = _target_yaw


func _process(delta: float) -> void:
	rotation.y = lerp_angle(rotation.y, _target_yaw, minf(1.0, delta * 14.0))
	if body_root == null or leg_l == null:
		return
	if moving:
		walk_t += delta * 11.0
		var s := sin(walk_t)
		leg_l.rotation.x = s * 0.6
		leg_r.rotation.x = -s * 0.6
		arm_l.rotation.x = -s * 0.5
		arm_r.rotation.x = s * 0.5
		body_root.position.y = absf(s) * 0.03
	else:
		walk_t = 0.0
		leg_l.rotation.x = lerpf(leg_l.rotation.x, 0.0, delta * 10.0)
		leg_r.rotation.x = lerpf(leg_r.rotation.x, 0.0, delta * 10.0)
		arm_l.rotation.x = lerpf(arm_l.rotation.x, 0.0, delta * 10.0)
		arm_r.rotation.x = lerpf(arm_r.rotation.x, 0.0, delta * 10.0)
		body_root.position.y = absf(sin(Time.get_ticks_msec() / 400.0)) * 0.008
	if temp_timer > 0.0:
		temp_timer -= delta
		if temp_timer <= 0.0:
			clear_expression()
	if icon and icon.visible:
		icon.position.y = 1.3 + sin(Time.get_ticks_msec() / 200.0) * 0.03
		if icon_timer > 0.0:
			icon_timer -= delta
			if icon_timer <= 0.0:
				icon.visible = false
