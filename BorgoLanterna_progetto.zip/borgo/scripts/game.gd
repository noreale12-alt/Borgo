extends Node
## Stato globale del gioco (autoload "Game"): abitanti, relazioni, tempo, eventi, salvataggi.
## Tutto è guidato dai file JSON in res://data, così si può espandere senza toccare il codice.

signal news_added(text: String)
signal day_changed(day: int)

const SAVE_PATH := "user://salvataggio.json"
const TRAITS := ["socievole", "gentile", "romantico", "energico", "creativo", "serio"]
const GIFT_NOTE := {"ama": "lo adoro", "piace": "carino", "neutro": "ok", "odia": "non mi piace"}

var day: int = 1
var minutes: float = 480.0
var time_paused: bool = false
var player: Dictionary = {}
var npcs: Dictionary = {}
var npc_order: Array = []
var rel: Dictionary = {}
var npc_rel: Dictionary = {}
var flags: Dictionary = {}
var inventory: Dictionary = {}
var news: Array = []
var memories: Dictionary = {}
var moods: Dictionary = {}
var status: Dictionary = {}
var quests: Array = []
var weather: String = "sole"
var partner: String = ""
var pending_confession: String = ""
var map_data: Dictionary = {}
var ai: Dictionary = {"provider": "gemini", "key": "", "model": ""}

var items: Dictionary = {}
var talk: Dictionary = {}
var story: Dictionary = {}
var events_def: Array = []
var default_npcs: Array = []
var default_map: Dictionary = {}
var _autosave_t: float = 0.0


func _ready() -> void:
	randomize()
	items = _load_json("res://data/items.json", {})
	talk = _load_json("res://data/talk.json", {})
	story = _load_json("res://data/story.json", {})
	events_def = _load_json("res://data/events.json", [])
	default_npcs = _load_json("res://data/npcs.json", [])
	default_map = _load_json("res://data/map.json", {})
	var loaded := false
	if FileAccess.file_exists(SAVE_PATH):
		loaded = load_game()
	if not loaded:
		new_game()


func _load_json(path: String, fallback: Variant) -> Variant:
	if not FileAccess.file_exists(path):
		push_error("File mancante: " + path)
		return fallback
	var f := FileAccess.open(path, FileAccess.READ)
	var data: Variant = JSON.parse_string(f.get_as_text())
	if data == null:
		push_error("JSON non valido: " + path)
		return fallback
	return data


func _process(delta: float) -> void:
	_autosave_t += delta
	if _autosave_t > 90.0:
		_autosave_t = 0.0
		if is_started():
			save_game()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		if is_started():
			save_game()


func traits() -> Array:
	return TRAITS


func is_started() -> bool:
	return str(player.get("nome", "")) != ""


# ---------------------------------------------------------------- partita

func new_game() -> void:
	day = 1
	minutes = 480.0
	player = {"nome": "", "genere": "ragazza", "aspetto": {"pelle": "#f8d8b8", "capelli": "#503020", "stile": "corti", "maglia": "#e04848", "pantaloni": "#3048a0", "vestito": "pantaloni", "accessorio": "nessuno"}}
	npcs = {}
	npc_order = []
	rel = {}
	npc_rel = {}
	moods = {}
	status = {}
	memories = {}
	for n in default_npcs:
		var d: Dictionary = n.duplicate(true)
		var id: String = str(d["id"])
		npcs[id] = d
		npc_order.append(id)
		rel[id] = _new_rel()
		moods[id] = 60.0
		status[id] = ""
		memories[id] = []
	for i in npc_order.size():
		for j in range(i + 1, npc_order.size()):
			var a: String = npc_order[i]
			var b: String = npc_order[j]
			var p := get_pair(a, b)
			p["amicizia"] = roundf((compatibility(a, b) - 0.5) * 50.0 + randf_range(-5.0, 15.0))
	flags = {}
	inventory = {"mela": 2, "fiore": 1, "te": 1}
	news = []
	quests = []
	partner = ""
	pending_confession = ""
	weather = "sole"
	map_data = default_map.duplicate(true)


func save_game() -> void:
	var d := {
		"versione": 1, "day": day, "minutes": minutes, "player": player, "npcs": npcs,
		"npc_order": npc_order, "rel": rel, "npc_rel": npc_rel, "flags": flags,
		"inventory": inventory, "news": news, "memories": memories, "moods": moods,
		"status": status, "quests": quests, "weather": weather, "partner": partner,
		"pending_confession": pending_confession, "map": map_data, "ai": ai,
	}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))


func load_game() -> bool:
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return false
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return false
	day = int(d.get("day", 1))
	minutes = float(d.get("minutes", 480.0))
	player = d.get("player", {})
	npcs = d.get("npcs", {})
	npc_order = d.get("npc_order", [])
	rel = d.get("rel", {})
	npc_rel = d.get("npc_rel", {})
	flags = d.get("flags", {})
	inventory = d.get("inventory", {})
	news = d.get("news", [])
	memories = d.get("memories", {})
	moods = d.get("moods", {})
	status = d.get("status", {})
	quests = d.get("quests", [])
	weather = str(d.get("weather", "sole"))
	partner = str(d.get("partner", ""))
	pending_confession = str(d.get("pending_confession", ""))
	map_data = d.get("map", default_map.duplicate(true))
	var saved_ai: Variant = d.get("ai", null)
	if typeof(saved_ai) == TYPE_DICTIONARY:
		ai = saved_ai
	for id in npc_order:
		get_rel(id)
		if not moods.has(id):
			moods[id] = 60.0
		if not status.has(id):
			status[id] = ""
		if not memories.has(id):
			memories[id] = []
	return true


# ---------------------------------------------------------------- tempo

func advance_time(delta: float) -> void:
	if time_paused:
		return
	var h := minutes / 60.0
	var speed := 1.0
	if h >= 22.0 or h < 6.0:
		speed = 3.0
	minutes += delta * speed
	if minutes >= 1440.0:
		minutes -= 1440.0
		start_new_day()


func hour() -> float:
	return minutes / 60.0


func clock_text() -> String:
	var m := int(minutes)
	return "%02d:%02d" % [m / 60, m % 60]


func sleep_until_morning() -> void:
	if minutes >= 420.0:
		start_new_day()
	minutes = 420.0


func start_new_day() -> void:
	day += 1
	for id in rel:
		var r: Dictionary = rel[id]
		r["parlato_oggi"] = false
		r["regalo_oggi"] = false
		r["chat_oggi"] = 0
		r["appuntamento_oggi"] = false
		r["domanda_oggi"] = false
	for id in npc_order:
		var m: float = float(moods.get(id, 60.0))
		moods[id] = clampf(m + randf_range(-15.0, 15.0) + (60.0 - m) * 0.3, 0.0, 100.0)
		if str(status.get(id, "")) == "malato" and randf() < 0.6:
			status[id] = ""
	weather = "pioggia" if randf() < 0.22 else "sole"
	if weather == "pioggia":
		add_news("Giorno %d: oggi piove su Borgo Lanterna." % day)
	else:
		add_news("Giorno %d: splende il sole su Borgo Lanterna." % day)
	_random_events()
	if flags.get("festival_pronto", false) and not flags.get("festival_fatto", false) and not flags.get("festival_oggi", false):
		flags["festival_oggi"] = true
		add_news("Oggi è il giorno del Festival delle Lanterne! Appuntamento in piazza dalle 19.")
	day_changed.emit(day)
	save_game()


# ---------------------------------------------------------------- utilità testo

func name_of(id: String) -> String:
	if id == "player":
		return str(player.get("nome", "Tu"))
	if npcs.has(id):
		return str(npcs[id].get("nome", id))
	return id


func gender_of(id: String) -> String:
	if id == "player":
		return str(player.get("genere", "altro"))
	if npcs.has(id):
		return str(npcs[id].get("genere", "altro"))
	return "altro"


## Desinenza in base al genere: o / a / ə
func g(id: String) -> String:
	match gender_of(id):
		"ragazzo":
			return "o"
		"ragazza":
			return "a"
	return "ə"


func fmt(text: String, npc_id: String = "") -> String:
	var t := text.replace("{player}", name_of("player")).replace("{po}", g("player"))
	if npc_id != "":
		t = t.replace("{npc}", name_of(npc_id)).replace("{o}", g(npc_id)).replace("{id}", npc_id)
	return t


func _pick(arr: Variant) -> String:
	if arr is Array and arr.size() > 0:
		return str(arr.pick_random())
	return ""


func _fmt_all(arr: Array, id: String) -> Array:
	var o: Array = []
	for s in arr:
		if str(s) != "":
			o.append(fmt(str(s), id))
	return o


func add_news(text: String) -> void:
	news.append({"giorno": day, "testo": text})
	while news.size() > 60:
		news.pop_front()
	news_added.emit(text)


func add_memory(id: String, text: String) -> void:
	if not memories.has(id):
		memories[id] = []
	var arr: Array = memories[id]
	arr.append(fmt(text, id))
	while arr.size() > 15:
		arr.pop_front()


func add_item(item_id: String, n: int = 1) -> void:
	var c := int(inventory.get(item_id, 0)) + n
	if c <= 0:
		inventory.erase(item_id)
	else:
		inventory[item_id] = c


func item_name(item_id: String) -> String:
	return str(items.get(item_id, {}).get("nome", item_id))


# ---------------------------------------------------------------- relazioni

func _new_rel() -> Dictionary:
	return {"amicizia": 0.0, "amore": 0.0, "conosciuto": false, "parlato_oggi": false, "regalo_oggi": false, "chat_oggi": 0, "appuntamento_oggi": false, "domanda_oggi": false}


func get_rel(id: String) -> Dictionary:
	if not rel.has(id):
		rel[id] = _new_rel()
	return rel[id]


func pair_key(a: String, b: String) -> String:
	if a < b:
		return a + "|" + b
	return b + "|" + a


func get_pair(a: String, b: String) -> Dictionary:
	var k := pair_key(a, b)
	if not npc_rel.has(k):
		npc_rel[k] = {"amicizia": 0.0, "amore": 0.0, "coppia": false}
	return npc_rel[k]


func traits_of(id: String) -> Dictionary:
	if npcs.has(id):
		return npcs[id].get("tratti", {})
	return {}


func trait_val(id: String, t: String) -> float:
	return float(traits_of(id).get(t, 50))


func compatibility(a: String, b: String) -> float:
	var diff := 0.0
	for t in TRAITS:
		diff += absf(trait_val(a, t) - trait_val(b, t))
	var c := 1.0 - diff / (100.0 * TRAITS.size())
	c += (trait_val(a, "gentile") + trait_val(b, "gentile")) / 1000.0 - 0.1
	return clampf(c, 0.0, 1.0)


func attracted(a: String, b: String) -> bool:
	if not npcs.has(a):
		return true
	var att: Variant = npcs[a].get("attrazione", [])
	if not (att is Array) or att.is_empty():
		return true
	return att.has(gender_of(b))


func rel_status(id: String) -> String:
	var r := get_rel(id)
	if partner == id:
		return "partner"
	if not r["conosciuto"]:
		return "sconosciuto"
	var f := float(r["amicizia"])
	if f >= 60.0:
		return "migliore amico"
	if f >= 30.0:
		return "amico"
	if f <= -30.0:
		return "rivale"
	return "conoscente"


func status_label(id: String) -> String:
	match rel_status(id):
		"partner":
			return "Partner ♥"
		"sconosciuto":
			return "Sconosciut" + g(id)
		"migliore amico":
			return "Miglior amic" + g(id)
		"amico":
			return "Amic" + g(id)
		"rivale":
			return "Rivale"
	return "Conoscente"


func change_rel(id: String, f: float, l: float = 0.0) -> void:
	if not npcs.has(id):
		return
	var r := get_rel(id)
	var old_status := rel_status(id)
	r["amicizia"] = clampf(float(r["amicizia"]) + f, -100.0, 100.0)
	if l != 0.0:
		if l > 0.0 and not attracted(id, "player"):
			l *= 0.2
		r["amore"] = clampf(float(r["amore"]) + l, 0.0, 100.0)
	var ns := rel_status(id)
	if ns != old_status and old_status != "sconosciuto" and ns != "partner":
		add_news("%s ora ti considera: %s." % [name_of(id), status_label(id)])
	if partner == "" and pending_confession == "" and float(r["amore"]) >= 70.0 and not flags.get("rifiuto_" + id, false) and attracted(id, "player"):
		pending_confession = id


## Due abitanti chiacchierano da soli. Ritorna "bene", "male", "amore" o "neutro".
func npc_interact(a: String, b: String) -> String:
	var p := get_pair(a, b)
	var c := compatibility(a, b)
	var roll := randf() * 0.6 + c * 0.6 + (float(moods.get(a, 60)) + float(moods.get(b, 60))) / 1000.0
	var outcome := "neutro"
	var old_f := float(p["amicizia"])
	if roll > 0.78:
		p["amicizia"] = clampf(old_f + 4.0, -100.0, 100.0)
		outcome = "bene"
	elif roll < 0.42:
		p["amicizia"] = clampf(old_f - 4.0, -100.0, 100.0)
		outcome = "male"
	else:
		p["amicizia"] = clampf(old_f + 1.0, -100.0, 100.0)
	var rom := (trait_val(a, "romantico") + trait_val(b, "romantico")) / 200.0
	if outcome == "bene" and float(p["amicizia"]) > 40.0 and a != partner and b != partner and attracted(a, b) and attracted(b, a) and randf() < rom * 0.5:
		p["amore"] = clampf(float(p["amore"]) + 6.0, 0.0, 100.0)
		outcome = "amore"
	var nf := float(p["amicizia"])
	if old_f < 30.0 and nf >= 30.0:
		add_news("%s e %s sono diventati amici." % [name_of(a), name_of(b)])
	elif old_f > -20.0 and nf <= -20.0:
		add_news("%s e %s non si sopportano più..." % [name_of(a), name_of(b)])
	if float(p["amore"]) >= 50.0 and not p.get("coppia", false):
		p["coppia"] = true
		add_news("Pettegolezzo: %s e %s si sono messi insieme!" % [name_of(a), name_of(b)])
	return outcome


# ---------------------------------------------------------------- dialoghi

func talk_lines(id: String) -> Array:
	var r := get_rel(id)
	var d: Dictionary = npcs[id]
	var out: Array = []
	if str(status.get(id, "")) == "malato":
		out.append(_pick(talk.get("malato", [])))
		return _fmt_all(out, id)
	if not r["conosciuto"]:
		r["conosciuto"] = true
		r["parlato_oggi"] = true
		var job := str(d.get("lavoro", ""))
		out.append("Oh, ciao! Non credo di conoscerti. Io sono {npc}" + ((", " + job) if job != "" else "") + ".")
		if str(d.get("storia", "")) != "":
			out.append(str(d["storia"]))
		out.append("Benvenut{po} a Borgo Lanterna, {player}!")
		change_rel(id, 3.0)
		return _fmt_all(out, id)
	var sal: Dictionary = talk.get("saluti", {})
	var sk := "conoscente"
	match rel_status(id):
		"partner":
			sk = "partner"
		"migliore amico":
			sk = "migliore"
		"amico":
			sk = "amico"
		"rivale":
			sk = "rivale"
	out.append(_pick(sal.get(sk, [])))
	var extra: Array = []
	var mood := float(moods.get(id, 60))
	var umore: Dictionary = talk.get("umore", {})
	if mood > 70.0:
		extra.append(_pick(umore.get("felice", [])))
	elif mood < 35.0:
		extra.append(_pick(umore.get("triste", [])))
	else:
		extra.append(_pick(umore.get("normale", [])))
	if weather == "pioggia":
		extra.append(_pick(talk.get("pioggia", [])))
	var tmap: Dictionary = talk.get("tratti", {})
	var best := ""
	var bv := -1.0
	for k in TRAITS:
		var v := trait_val(id, k)
		if v > bv:
			bv = v
			best = k
	extra.append(_pick(tmap.get(best, [])))
	if trait_val(id, "energico") < 30.0:
		extra.append(_pick(tmap.get("pigro", [])))
	var g_line := _gossip_line(id)
	if g_line != "":
		extra.append(g_line)
	for q in quests:
		if str(q["npc"]) == id and not q["done"]:
			extra.insert(0, _pick(talk.get("cerca_oggetto", [])))
	extra = extra.filter(func(s): return str(s) != "")
	var first_two: Array = []
	if extra.size() > 0 and str(extra[0]).contains("portafortuna"):
		first_two.append(extra.pop_front())
	extra.shuffle()
	while first_two.size() < 2 and extra.size() > 0:
		first_two.append(extra.pop_front())
	out.append_array(first_two)
	var inter := str(d.get("intercalare", ""))
	if inter != "" and randf() < 0.5:
		out[out.size() - 1] = str(out[out.size() - 1]) + " " + inter
	if not r["parlato_oggi"]:
		r["parlato_oggi"] = true
		change_rel(id, 2.0)
		moods[id] = clampf(mood + 3.0, 0.0, 100.0)
	return _fmt_all(out, id)


func _gossip_line(id: String) -> String:
	var best_id := ""
	var best_v := -999.0
	var worst_id := ""
	var worst_v := 999.0
	var love_id := ""
	for o in npc_order:
		if o == id:
			continue
		var p := get_pair(id, o)
		var f := float(p["amicizia"])
		if p.get("coppia", false):
			love_id = o
		if f > best_v:
			best_v = f
			best_id = o
		if f < worst_v:
			worst_v = f
			worst_id = o
	var line := ""
	var other := ""
	if love_id != "" and randf() < 0.6:
		line = _pick(talk.get("gossip_cotta", []))
		other = love_id
	elif worst_v < -15.0 and randf() < 0.5:
		line = _pick(talk.get("gossip_lite", []))
		other = worst_id
	elif best_v > 35.0:
		line = _pick(talk.get("gossip_amici", []))
		other = best_id
	if line == "" or other == "":
		return ""
	return line.replace("{altro}", name_of(other)).replace("{ao}", g(other))


func random_question() -> Dictionary:
	var qs: Array = talk.get("domande", [])
	if qs.is_empty():
		return {}
	return qs.pick_random()


func eval_answer(id: String, ans: Dictionary) -> int:
	var s := 0.0
	var tmap: Dictionary = ans.get("tratti", {})
	for k in tmap:
		s += (trait_val(id, str(k)) - 50.0) / 50.0 * float(tmap[k])
	if s > 0.2:
		return 1
	if s < -0.2:
		return -1
	return 0


func answer_reaction(id: String, ans: Dictionary) -> String:
	var res := eval_answer(id, ans)
	var rr: Dictionary = talk.get("reazioni_domanda", {})
	get_rel(id)["domanda_oggi"] = true
	if res > 0:
		change_rel(id, 4.0, 1.5)
		return fmt(_pick(rr.get("bene", [])), id)
	if res < 0:
		change_rel(id, -1.0)
		return fmt(_pick(rr.get("male", [])), id)
	change_rel(id, 1.0)
	return fmt(_pick(rr.get("neutro", [])), id)


func give_gift(id: String, item_id: String) -> String:
	if int(inventory.get(item_id, 0)) <= 0:
		return ""
	add_item(item_id, -1)
	var r := get_rel(id)
	var mult := 1.0
	if r["regalo_oggi"]:
		mult = 0.3
	r["regalo_oggi"] = true
	var it: Dictionary = items.get(item_id, {})
	var nome_it := str(it.get("nome", item_id))
	var rg: Dictionary = talk.get("regali", {})
	for q in quests:
		if str(q["npc"]) == id and str(q["item"]) == item_id and not q["done"]:
			q["done"] = true
			change_rel(id, 15.0, 3.0)
			moods[id] = 95.0
			add_memory(id, "Giorno %d: {player} ha ritrovato il mio portafortuna!" % day)
			add_news(fmt("{player} ha ritrovato il portafortuna di {npc}!", id))
			return fmt(_pick(rg.get("ritrovato", [])), id)
	if item_id == "te" and str(status.get(id, "")) == "malato":
		status[id] = ""
		change_rel(id, 8.0)
		add_memory(id, "Giorno %d: ero malat{o} e {player} mi ha portato un tè." % day)
		return fmt(_pick(rg.get("guarito", [])), id)
	var tags: Array = it.get("tag", [])
	var d: Dictionary = npcs[id]
	var ama: Array = d.get("ama", [])
	var odia: Array = d.get("odia", [])
	var kind := "neutro"
	for tg in tags:
		if odia.has(tg):
			kind = "odia"
	if kind != "odia":
		if ama.has(item_id):
			kind = "ama"
		for tg in tags:
			if ama.has(tg):
				kind = "ama"
		if kind == "neutro" and (tags.has("cibo") or tags.has("fiori") or tags.has("dolci")):
			kind = "piace"
	var mood_delta := 4.0
	match kind:
		"ama":
			change_rel(id, 10.0 * mult, 4.0 * mult)
			mood_delta = 12.0
		"piace":
			change_rel(id, 5.0 * mult, 1.0 * mult)
		"neutro":
			change_rel(id, 2.0 * mult)
			mood_delta = 1.0
		"odia":
			change_rel(id, -6.0)
			mood_delta = -10.0
	moods[id] = clampf(float(moods.get(id, 60)) + mood_delta, 0.0, 100.0)
	add_memory(id, "Giorno %d: {player} mi ha regalato: %s (%s)." % [day, nome_it, GIFT_NOTE[kind]])
	return fmt(_pick(rg.get(kind, [])), id).replace("{item}", nome_it)


func can_date(id: String) -> String:
	var r := get_rel(id)
	var h := hour()
	if r["appuntamento_oggi"]:
		return fmt("Oggi tu e {npc} siete già uscit{o} insieme.", id)
	if h < 9.0 or h >= 21.0:
		return "Gli appuntamenti si fanno tra le 9 e le 21."
	if str(status.get(id, "")) == "malato":
		return fmt("{npc} è malat{o}.", id)
	if float(r["amicizia"]) < 35.0 and float(r["amore"]) < 20.0 and partner != id:
		return fmt("{npc} non ti conosce ancora abbastanza (serve più amicizia).", id)
	return ""


func finish_date(id: String, score: int, place_name: String) -> String:
	var r := get_rel(id)
	r["appuntamento_oggi"] = true
	var ap: Dictionary = talk.get("appuntamenti", {})
	var res := ""
	if score >= 2:
		change_rel(id, 6.0, 9.0)
		res = _pick(ap.get("fine_bene", []))
		add_memory(id, "Giorno %d: appuntamento bellissimo con {player} (%s)." % [day, place_name])
		add_news(fmt("Avvistati {player} e {npc} insieme: %s." % place_name, id))
	elif score >= 0:
		change_rel(id, 3.0, 3.0)
		res = _pick(ap.get("fine_ok", []))
		add_memory(id, "Giorno %d: sono uscit{o} con {player} (%s). Carino." % [day, place_name])
	else:
		change_rel(id, -2.0, -2.0)
		res = _pick(ap.get("fine_male", []))
		add_memory(id, "Giorno %d: appuntamento un po' imbarazzante con {player}." % day)
	return fmt(res, id)


func confess_to(id: String) -> String:
	var r := get_rel(id)
	var dc: Dictionary = talk.get("dichiarazione", {})
	if partner == id:
		return fmt(_pick(dc.get("gia", [])), id)
	if float(r["amore"]) >= 55.0 and attracted(id, "player"):
		_set_partner(id)
		return fmt(_pick(dc.get("si", [])), id)
	if float(r["amore"]) >= 30.0:
		change_rel(id, 0.0, 2.0)
		return fmt(_pick(dc.get("forse", [])), id)
	change_rel(id, -3.0)
	return fmt(_pick(dc.get("no", [])), id)


func _set_partner(id: String) -> void:
	if partner != "" and partner != id and npcs.has(partner):
		var prev := partner
		partner = ""
		change_rel(prev, -20.0, -40.0)
		add_news("%s ha il cuore spezzato..." % name_of(prev))
	partner = id
	pending_confession = ""
	change_rel(id, 5.0, 10.0)
	add_news(fmt("{player} e {npc} si sono fidanzati! ♥", id))
	add_memory(id, "Giorno %d: io e {player} ci siamo messi insieme!" % day)


# ---------------------------------------------------------------- trama

func story_for(npc_id: String) -> String:
	for t in story.get("trigger", []):
		if str(t.get("npc", "")) != npc_id:
			continue
		if _cond_ok(t.get("se", {})):
			return str(t["nodo"])
	return ""


func _cond_ok(c: Dictionary) -> bool:
	for f in c.get("flag", []):
		if not flags.get(f, false):
			return false
	for f in c.get("non_flag", []):
		if flags.get(f, false):
			return false
	if day < int(c.get("giorno_min", 0)):
		return false
	if hour() < float(c.get("ora_min", 0)):
		return false
	return true


func apply_effects(effs: Array, npc_id: String) -> void:
	for e in effs:
		var tgt := str(e.get("npc", npc_id))
		var v := float(e.get("valore", 0)) if typeof(e.get("valore", 0)) != TYPE_BOOL else 0.0
		match str(e.get("tipo", "")):
			"amicizia":
				change_rel(tgt, v)
			"amore":
				change_rel(tgt, 0.0, v)
			"umore":
				if npcs.has(tgt):
					moods[tgt] = clampf(float(moods.get(tgt, 60)) + v, 0.0, 100.0)
			"flag":
				flags[fmt(str(e["nome"]), tgt)] = e.get("valore", true)
			"item":
				add_item(str(e["id"]), int(e.get("n", 1)))
				add_news("Hai ricevuto: %s." % item_name(str(e["id"])))
			"notizia":
				add_news(fmt(str(e["testo"]), tgt))
			"memoria":
				add_memory(tgt, str(e["testo"]))
			"conosciuto":
				get_rel(tgt)["conosciuto"] = true
			"fidanzati":
				_set_partner(tgt)
			"fine_confessione":
				pending_confession = ""
			"lanterne":
				flags["lanterne_giorno"] = day


# ---------------------------------------------------------------- eventi casuali

func _ev_text(tipo: String) -> String:
	var opts: Array = []
	for e in events_def:
		if str(e.get("tipo", "")) == tipo:
			opts.append(str(e.get("testo", "")))
	return _pick(opts)


func _random_events() -> void:
	if npc_order.size() < 2:
		return
	var tipi := ["lite", "pace", "pace", "malato", "oggetto_perso", "regalo_trovato", "umore", "umore", "festa"]
	var n := 1 + (1 if randf() < 0.5 else 0)
	for i in n:
		var tipo: String = tipi.pick_random()
		var a: String = npc_order.pick_random()
		var b: String = a
		while b == a:
			b = npc_order.pick_random()
		var txt := _ev_text(tipo)
		var p := get_pair(a, b)
		var ok := true
		match tipo:
			"lite":
				p["amicizia"] = clampf(float(p["amicizia"]) - 12.0, -100.0, 100.0)
				moods[a] = clampf(float(moods.get(a, 60)) - 15.0, 0.0, 100.0)
				moods[b] = clampf(float(moods.get(b, 60)) - 15.0, 0.0, 100.0)
			"pace":
				p["amicizia"] = clampf(float(p["amicizia"]) + 10.0, -100.0, 100.0)
			"malato":
				if str(status.get(a, "")) == "malato":
					ok = false
				else:
					status[a] = "malato"
			"oggetto_perso":
				for q in quests:
					if not q["done"]:
						ok = false
				if ok:
					quests.append({"npc": a, "item": "portafortuna", "done": false})
			"regalo_trovato":
				var pool: Array = []
				for k in items:
					if items[k].get("spawn", false):
						pool.append(k)
				if pool.is_empty():
					ok = false
				else:
					var it: String = pool.pick_random()
					add_item(it, 1)
					txt = txt.replace("{item}", item_name(it))
			"umore":
				moods[a] = 95.0
			"festa":
				flags["festa_giorno"] = day
		if ok and txt != "":
			add_news(txt.replace("{a}", name_of(a)).replace("{b}", name_of(b)).replace("{o}", g(a)))


# ---------------------------------------------------------------- abitanti nuovi

func free_house() -> String:
	for h in map_data.get("case", []):
		if str(h.get("owner", "")) == "":
			return str(h["id"])
	return ""


func add_npc(d: Dictionary) -> String:
	var hid := free_house()
	if hid == "":
		return ""
	var base := str(d.get("nome", "abitante")).to_lower().strip_edges().replace(" ", "_")
	if base == "":
		base = "abitante"
	var id := base
	var k := 2
	while npcs.has(id) or id == "player":
		id = base + str(k)
		k += 1
	d["id"] = id
	d["casa"] = hid
	for h in map_data["case"]:
		if str(h["id"]) == hid:
			h["owner"] = id
	npcs[id] = d
	npc_order.append(id)
	rel[id] = _new_rel()
	moods[id] = 70.0
	status[id] = ""
	memories[id] = []
	for o in npc_order:
		if o != id:
			get_pair(id, o)["amicizia"] = roundf((compatibility(id, o) - 0.5) * 40.0)
	add_news(fmt("{npc} si è trasferit{o} a Borgo Lanterna!", id))
	return id


func remove_npc(id: String) -> void:
	var nm := name_of(id)
	var gg := g(id)
	for h in map_data.get("case", []):
		if str(h.get("owner", "")) == id:
			h["owner"] = ""
	npcs.erase(id)
	npc_order.erase(id)
	rel.erase(id)
	moods.erase(id)
	status.erase(id)
	memories.erase(id)
	for k in npc_rel.keys():
		var ks := str(k)
		if ks.begins_with(id + "|") or ks.ends_with("|" + id):
			npc_rel.erase(k)
	if partner == id:
		partner = ""
	if pending_confession == id:
		pending_confession = ""
	quests = quests.filter(func(q): return str(q["npc"]) != id)
	add_news("%s si è trasferit%s lontano da Borgo Lanterna." % [nm, gg])


# ---------------------------------------------------------------- IA

func build_prompt(id: String) -> String:
	var d: Dictionary = npcs[id]
	var desc: Array = []
	for k in TRAITS:
		desc.append("%s %d/100" % [k, int(trait_val(id, k))])
	var r := get_rel(id)
	var others: Array = []
	for o in npc_order:
		if o == id:
			continue
		var p := get_pair(id, o)
		others.append("%s (amicizia %d%s)" % [name_of(o), int(p["amicizia"]), ", siete fidanzati" if p.get("coppia", false) else ""])
	var mem: Array = memories.get(id, [])
	var recent: Array = []
	for i in range(maxi(0, news.size() - 5), news.size()):
		recent.append(str(news[i]["testo"]))
	var mood := float(moods.get(id, 60))
	var mood_txt := "felice" if mood > 70.0 else ("triste" if mood < 35.0 else "normale")
	if str(status.get(id, "")) == "malato":
		mood_txt += ", hai il raffreddore"
	var s := "Sei %s, un personaggio del videogioco 'Borgo Lanterna', un piccolo villaggio sul mare dallo stile tenero e colorato. " % name_of(id)
	s += "Genere: %s. Ruolo: %s. La tua storia: %s\n" % [gender_of(id), str(d.get("lavoro", "abitante")), str(d.get("storia", ""))]
	s += "Personalità (0-100): %s.\n" % ", ".join(desc)
	s += "Ti piace: %s. Non ti piace: %s. Intercalare tipico: \"%s\".\n" % [", ".join(d.get("ama", [])), ", ".join(d.get("odia", [])), str(d.get("intercalare", ""))]
	s += "Parli con %s (genere: %s), che vive al villaggio. Per te è: %s. Amicizia %d/100, attrazione %d/100.\n" % [name_of("player"), gender_of("player"), status_label(id), int(r["amicizia"]), int(r["amore"])]
	s += "Umore di oggi: %s. Tempo: %s. Ore %s del giorno %d.\n" % [mood_txt, weather, clock_text(), day]
	s += "Rapporti con gli altri abitanti: %s.\n" % ", ".join(others)
	if mem.size() > 0:
		s += "Ricordi: %s\n" % " | ".join(mem.slice(maxi(0, mem.size() - 8)))
	if recent.size() > 0:
		s += "Notizie recenti del villaggio: %s\n" % " | ".join(recent)
	s += "REGOLE: rispondi sempre in italiano, restando nel personaggio, con 1-3 frasi brevi e naturali, adatte a tutte le età. "
	s += "Coerenza col tuo carattere e con il rapporto attuale (se l'amicizia è bassa sii più distaccat%s). Non dire mai di essere un'IA. Non usare emoji. " % g(id)
	s += "Alla fine aggiungi su una riga a parte il tag [UMORE:n] con n intero da -3 a 3 che indica quanto ti è piaciuto il messaggio del giocatore."
	return s


func gazette_prompt() -> String:
	var lines: Array = []
	for i in range(maxi(0, news.size() - 8), news.size()):
		lines.append(str(news[i]["testo"]))
	var names: Array = []
	for id in npc_order:
		names.append("%s (%s)" % [name_of(id), str(npcs[id].get("lavoro", ""))])
	return "Scrivi UNA breve notizia buffa e tenera (massimo 25 parole, in italiano, senza emoji) per il giornalino del villaggio Borgo Lanterna. Abitanti: %s. Fatti recenti: %s. Inventa un piccolo evento nuovo coerente con questi fatti." % [", ".join(names), " | ".join(lines)]


func offline_reply(id: String, msg: String) -> String:
	var m := msg.to_lower()
	var d: Dictionary = npcs[id]
	var mood := float(moods.get(id, 60))
	var inter := str(d.get("intercalare", ""))
	for o in npc_order:
		if o != id and m.contains(name_of(o).to_lower()):
			var f := float(get_pair(id, o)["amicizia"])
			if f > 30.0:
				return fmt("%s? Le voglio un gran bene, sai." % name_of(o), id) if gender_of(o) == "ragazza" else fmt("%s? Gli voglio un gran bene, sai." % name_of(o), id)
			if f < -15.0:
				return "Preferisco non parlare di %s..." % name_of(o)
			return "%s? Ci conosciamo, ma non benissimo." % name_of(o)
	if m.contains("ciao") or m.contains("salve") or m.contains("buongiorno") or m.contains("hey"):
		return fmt("Ciao {player}! " + inter, id)
	if m.contains("come stai") or m.contains("come va"):
		if mood > 70.0:
			return "Benissimo! Oggi è una giornata speciale."
		if mood < 35.0:
			return "Così così... ma grazie per averlo chiesto."
		return "Tutto bene, dai. E tu?"
	if m.contains("piace") or m.contains("ami") or m.contains("preferit"):
		return "Adoro " + ", ".join(d.get("ama", [])) + "! Non sopporto invece " + ", ".join(d.get("odia", ["niente"])) + "."
	if m.contains("lavoro") or m.contains("fai"):
		return "Io? Sono " + str(d.get("lavoro", "un abitante del villaggio")) + "."
	if m.contains("festival") or m.contains("lanterne"):
		return "Il Festival delle Lanterne è la notte più bella dell'anno! Chiedi a Nonna Rosa."
	var generic := ["Davvero? Raccontami di più!", "Ahah, sei proprio simpatic{po}!", "Mh, ci devo pensare...", "Non ci avevo mai pensato!", inter]
	return fmt(str(generic.pick_random()), id)
