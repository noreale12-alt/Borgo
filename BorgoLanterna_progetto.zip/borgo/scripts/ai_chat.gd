extends Node
## Autoload "Ai": chiacchiere libere con gli abitanti tramite un servizio IA online gratuito.
## Ogni giocatore usa la propria chiave gratuita (Gemini, Groq o OpenRouter): l'app resta a costo zero.

const PROVIDERS := {
	"gemini": {"nome": "Google Gemini", "url": "https://generativelanguage.googleapis.com/v1beta/openai/chat/completions", "model": "gemini-2.5-flash-lite", "sito": "https://aistudio.google.com/apikey"},
	"groq": {"nome": "Groq", "url": "https://api.groq.com/openai/v1/chat/completions", "model": "llama-3.3-70b-versatile", "sito": "https://console.groq.com/keys"},
	"openrouter": {"nome": "OpenRouter", "url": "https://openrouter.ai/api/v1/chat/completions", "model": "meta-llama/llama-3.3-70b-instruct:free", "sito": "https://openrouter.ai/keys"},
}

var http: HTTPRequest
var busy: bool = false
var _cb: Callable


func _ready() -> void:
	http = HTTPRequest.new()
	http.timeout = 40.0
	add_child(http)
	http.request_completed.connect(_on_done)


func is_configured() -> bool:
	return str(Game.ai.get("key", "")).strip_edges() != ""


func provider_ids() -> Array:
	return ["gemini", "groq", "openrouter"]


func provider_info(pid: String) -> Dictionary:
	return PROVIDERS.get(pid, PROVIDERS["gemini"])


func provider() -> Dictionary:
	return PROVIDERS.get(str(Game.ai.get("provider", "gemini")), PROVIDERS["gemini"])


func model_name() -> String:
	var m := str(Game.ai.get("model", "")).strip_edges()
	if m == "":
		m = str(provider()["model"])
	return m


## cb riceve (ok: bool, testo: String)
func ask(messages: Array, cb: Callable) -> void:
	if busy:
		cb.call(false, "Un attimo, sto ancora pensando...")
		return
	if not is_configured():
		cb.call(false, "IA non configurata.")
		return
	var body := JSON.stringify({"model": model_name(), "messages": messages, "temperature": 0.9, "max_tokens": 500})
	var headers := PackedStringArray(["Content-Type: application/json", "Authorization: Bearer " + str(Game.ai["key"]).strip_edges()])
	_cb = cb
	busy = true
	var err := http.request(str(provider()["url"]), headers, HTTPClient.METHOD_POST, body)
	if err != OK:
		busy = false
		cb.call(false, "Errore di rete (%d)." % err)


func _on_done(result: int, code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	busy = false
	var cb := _cb
	if result != HTTPRequest.RESULT_SUCCESS:
		cb.call(false, "Connessione non riuscita: controlla internet.")
		return
	var data: Variant = JSON.parse_string(body.get_string_from_utf8())
	if typeof(data) == TYPE_ARRAY and data.size() > 0:
		data = data[0]
	if code != 200 or typeof(data) != TYPE_DICTIONARY or not data.has("choices"):
		var msg := "Errore dal servizio IA (codice %d)." % code
		if typeof(data) == TYPE_DICTIONARY and data.has("error"):
			var e: Variant = data["error"]
			if typeof(e) == TYPE_DICTIONARY and e.has("message"):
				msg += " " + str(e["message"]).left(160)
		if code == 401 or code == 403:
			msg += " Controlla la chiave nelle impostazioni IA."
		elif code == 429:
			msg += " Limite gratuito raggiunto: riprova tra un po'."
		cb.call(false, msg)
		return
	var choices: Array = data["choices"]
	if choices.is_empty():
		cb.call(false, "Risposta vuota.")
		return
	var content: Variant = choices[0].get("message", {}).get("content", "")
	if content == null:
		content = ""
	cb.call(true, str(content).strip_edges())


func gazette() -> void:
	ask([{"role": "user", "content": Game.gazette_prompt()}], func(ok: bool, txt: String):
		if ok and txt != "":
			Game.add_news("Gazzetta del Borgo: " + txt.replace("\n", " ").left(200))
	)
